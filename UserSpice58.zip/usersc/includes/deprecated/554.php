<?php
//the following functions were deprecated in v5.5.4. If you do not need these, you can delete them.
