<?php 
//this file is automatically called when a userspice version update fails.  Please note that we step through the versions one at a time, so you can do things like update the database one version at a time, etc. This also means that running heavy tasks here can slow down the update process.  If you need to do something heavy, consider doing it in the update file.
