<?php
//Please don't load functions system-wide if you don't need them system-wide.
