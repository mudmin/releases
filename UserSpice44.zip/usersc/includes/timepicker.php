<?php
//if you don't like our timepicker, use your own!
?>
<link rel="stylesheet" href="<?=$us_url_root?>users/css/jquery-ui.min.css">
<link rel="stylesheet" href="<?=$us_url_root?>users/css/timepicker.css">
<script src="<?=$us_url_root?>users/js/jquery-ui.min.js"></script>
<script src="<?=$us_url_root?>users/js/timepicker.js"></script>
