<!-- <a href="<?php //echo $us_url_root?>index.php"><i class="menu-icon fa fa-home"></i>Visit Homepage</a> -->
