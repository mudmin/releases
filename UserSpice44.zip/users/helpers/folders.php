<?php $path=['','users/','usersc/']; ?>
