<h2>Bootstrap Class Examples</h2>
<hr />
<button type="button" name="button" class="btn btn-primary">primary</button>
<button type="button" name="button" class="btn btn-info">info</button>
<button type="button" name="button" class="btn btn-warning">warning</button>
<button type="button" name="button" class="btn btn-danger">danger</button>
<button type="button" name="button" class="btn btn-success">success</button>
<button type="button" name="button" class="btn btn-default">default</button>
<hr />

<h1>This is H1</h1>
<h2>This is H2</h2>
<h3>This is H3</h3>
<h4>This is H4</h4>
<h5>This is H5</h5>
<h6>This is H6</h6>
<p>This is paragraph</p>
<a href="#">This is a link</a><br><br>
<div class="jumbotron"><h1>Jumbotron</h1></div>
<div class="well"><p>well</p></div>
