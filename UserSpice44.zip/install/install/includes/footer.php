<footer>
  <p align="center">&copy; Company 2015</p>
</footer>
</div> <!-- /container -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="install/js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

  <script src="install/js/vendor/bootstrap.min.js"></script>

  <script src="install/js/main.js"></script>

</body>
</html>
