<?php
/*
UserSpice
An Open Source PHP User Management System
by the UserSpice Team at http://UserSpice.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
class User
{
    private $_db;
    private $_data;
    private $_sessionName;
    private $_isLoggedIn;
    private $_cookieName;
    public $tableName = 'users';

    public function __construct($user = null, $loginHandler = null)
    {
        $this->_db = DB::getInstance();
        $this->_sessionName = Config::get('session/session_name');
        $this->_cookieName = Config::get('remember/cookie_name');

        if (!$user) {
            if (Session::exists($this->_sessionName)) {
                $user = Session::get($this->_sessionName);

                if ($this->find($user, $loginHandler)) {
                    $this->_isLoggedIn = true;
                } else {
                    //process Logout
                }
            }
        } else {
            $this->find($user, $loginHandler);
        }
    }

    public function create($fields = [])
    {
        // Hard requirement: email must be provided. Everything else can
        // be defaulted, but a user with no email is unusable.
        if (!array_key_exists('email', $fields) || $fields['email'] === null || $fields['email'] === '') {
            throw new Exception('Email is required to create a user.');
        }

        // Default username to email if the caller didn't supply one.
        if (!array_key_exists('username', $fields) || $fields['username'] === null || $fields['username'] === '') {
            $fields['username'] = $fields['email'];
        }

        // Default password: generate a strong random secret and bcrypt it.
        // Hash::unique() is bin2hex(random_bytes(32)) so it should always
        // be 64 chars; if something goes sideways and it comes back short,
        // fall back to randomString(20) so we never bcrypt a weak value.
        if (!array_key_exists('password', $fields) || $fields['password'] === null || $fields['password'] === '') {
            $secret = Hash::unique();
            if (!is_string($secret) || strlen($secret) < 32) {
                $secret = randomString(20);
            }
            $fields['password'] = password_hash($secret, PASSWORD_BCRYPT, ['cost' => 14]);
        }

        // Sanity checks: refuse to create a user whose username or email
        // collides with anyone else's username OR email. Callers like
        // join.php already validate this, but every other entry point
        // (OAuth, custom code, plugins) gets the same protection here.
        $u = $fields['username'];
        $check = $this->_db->query('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', [$u, $u]);
        if ($check->count() > 0) {
            throw new Exception('Username is already in use.');
        }
        $e = $fields['email'];
        $check = $this->_db->query('SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1', [$e, $e]);
        if ($check->count() > 0) {
            throw new Exception('Email is already in use.');
        }

        if (!$this->_db->insert('users', $fields)) {
            throw new Exception($this->_db->errorString());
        } else {
            $user_id = $this->_db->lastId();
        }
        $query = $this->_db->insert('user_permission_matches', ['user_id' => $user_id, 'permission_id' => 1]);

        return $user_id;
    }

    public function find($user = null, $loginHandler = null)
    {
        // Cloaking: when an admin is cloaked into another user, load that user
        // instead. Prefer the instance-namespaced key; fall back to the legacy
        // un-namespaced key so older sessions / custom code keep working.
        // (Uses $this->_sessionName because find() runs during init.php, before
        // loader.php defines the INSTANCE constant.)
        if (isset($_SESSION[$this->_sessionName . '_cloak_to'])) {
            $user = $_SESSION[$this->_sessionName . '_cloak_to'];
        } elseif (isset($_SESSION['cloak_to'])) {
            $user = $_SESSION['cloak_to'];
        }

        if ($user) {
            if ($loginHandler !== null) {
                if ($loginHandler == "forceEmail") {

                    $field = 'email';
                } elseif (!filter_var($user, FILTER_VALIDATE_EMAIL) === false) {
                    $field = 'email';
                } else {
                    $field = 'username';
                }
            } else {
                if (is_numeric($user)) {
                    $field = 'id';
                } elseif (!filter_var($user, FILTER_VALIDATE_EMAIL) === false) {
                    $field = 'email';
                } else {
                    $field = 'username';
                }
            }
            $data = $this->_db->get('users', [$field, '=', $user]);

            if ($data->count()) {
                $this->_data = $data->first();

                return true;
            }
        }

        return false;
    }

    private function regenerateSession()
    {
        if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
            session_regenerate_id(true);
        }
    }

    /**
     * Start a session for this user. With $username and $password it also checks
     * the password, but it skips what users/login.php adds: rate limits and TOTP.
     * Don't call it to check credentials; use verifyLoginCredentials().
     */
    public function login($username = null, $password = null, $remember = false)
    {
        if (!$username && !$password && $this->exists()) {
            $this->regenerateSession();
            Session::put($this->_sessionName, $this->data()->id);
            $date = date('Y-m-d H:i:s');
            $this->_db->query('UPDATE users SET last_login = ?, logins = logins + 1 WHERE id = ?', [$date, $this->data()->id]);
            reauthMarkConfirmed();
        } else {
            $user = $this->find($username);
            if ($user) {
                if (password_verify($password, $this->data()->password)) {
                    $this->regenerateSession();
                    Session::put($this->_sessionName, $this->data()->id);
                    if ($remember) {
                        $hash = Hash::unique();
                        $hashCheck = $this->_db->get('users_session', ['user_id', '=', $this->data()->id]);

                        $this->_db->insert('users_session', [
                            'user_id' => $this->data()->id,
                            'hash' => $hash,
                            'uagent' => Session::uagent_no_version(),
                        ]);

                        Cookie::put($this->_cookieName, $hash, Config::get('remember/cookie_expiry'));
                    }
                    $date = date('Y-m-d H:i:s');
                    $this->_db->query('UPDATE users SET last_login = ?, logins = logins + 1 WHERE id = ?', [$date, $this->data()->id]);
                    reauthMarkConfirmed();
                    $this->_db->insert('logs', ['logdate' => $date, 'user_id' => $this->data()->id, 'logtype' => 'Login', 'lognote' => 'User logged in.', 'ip' => ipCheck()]);
                    $ip = ipCheck();
                    $q = $this->_db->query('SELECT id FROM us_ip_list WHERE ip = ?', [$ip]);
                    $c = $q->count();
                    if ($c < 1) {
                        $this->_db->insert('us_ip_list', [
                            'user_id' => $this->data()->id,
                            'ip' => $ip,
                            'timestamp' => date('Y-m-d H:i:s'),
                        ]);
                    } else {
                        $f = $q->first();
                        $this->_db->update('us_ip_list', $f->id, [
                            'user_id' => $this->data()->id,
                            'ip' => $ip,
                            'timestamp' => date('Y-m-d H:i:s'),
                        ]);
                    }

                    return true;
                }
            }
        }

        return false;
    }

    public function loginEmail($email = null, $password = null, $remember = false, $rawpassword = null, $recordLogin = true)
    {
        $success = false;
        if (!$email && !$password && $this->exists()) {
            $this->regenerateSession();
            Session::put($this->_sessionName, $this->data()->id);
        } else {
            $user = $this->find($email, 1);

            if (!$user || $this->data()->password === null) {
                // Same bcrypt cost as a real check, so response time doesn't reveal whether the account exists
                password_verify((string)$password, '$2y$13$WQJPF12kdq/UCcdF5MUHh.jwnqpaMU.Fh76ulGmVQ3UxQ1Na0v0.G');
            }

            if ($user && $this->data()->password !== null) {
                $strength = substr($this->data()->password, 4, 2);
                if (!is_numeric($strength)) {
                    $strength = 999;
                }

                // login.php passes $password already run through Input::sanitize()
                // (htmlspecialchars) and $rawpassword straight from $_POST. Over the
                // years hashes have been built from three different renderings of the
                // same secret, so try each one that is actually distinct:
                //   1. the sanitized form - what every current UserSpice page hashes.
                //   2. the htmlentities form - legacy, from when Input::sanitize()
                //      used htmlentities. Only ever applied to pre-cost-13 hashes.
                //   3. the raw, unsanitized string - anything that called
                //      password_hash() on a secret it never put through Input, such
                //      as generated passwords, plugins, or seeding scripts. Without
                //      this a secret containing & < > " ' could never be verified,
                //      because login always sanitizes before checking.
                // Duplicates are dropped, so a password with no HTML-special
                // characters (the overwhelming majority) still costs exactly one
                // bcrypt on both success and failure.
                //UserSpice passwords were hashed with a cost of 10, then 12, so we're going to use this to update both the hash strength and deal with passwords that were corrupted because of the Input::sanitize function.
                $matched = $this->matchingPasswordCandidate($this->data()->password, $password, $rawpassword);
                $success = $matched !== null;

                if ($success) {
                    // Rehash when the stored hash is weak, and also when it turned out
                    // to be built from a rendering other than the sanitized one, so the
                    // account converges on a single canonical hash and later logins
                    // match on the first candidate.
                    if ($strength < 13 || $matched !== $password) {
                        //deal with custom login forms that do not properly pass the password
                        if ($rawpassword != null && $rawpassword != "") {
                            $this->_db->update('users', $this->data()->id, ['password' => password_hash(Input::sanitize($rawpassword), PASSWORD_BCRYPT, ['cost' => 13])]);
                        }
                    }
                    $this->regenerateSession();
                    Session::put($this->_sessionName, $this->data()->id);

                    if ($remember) {
                        $hash = Hash::unique();
                        $hashCheck = $this->_db->get('users_session', ['user_id', '=', $this->data()->id]);

                        $this->_db->insert('users_session', [
                            'user_id' => $this->data()->id,
                            'hash' => $hash,
                            'uagent' => Session::uagent_no_version(),
                        ]);

                        Cookie::put($this->_cookieName, $hash, Config::get('remember/cookie_expiry'));
                    }
                    reauthMarkConfirmed();
                    if ($recordLogin) {
                        $this->recordLogin();
                    }

                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Which rendering of the password matches the stored hash: the sanitized
     * form, the legacy htmlentities form (pre-cost-13 hashes only) or the raw
     * string. See loginEmail(). Returns the matching candidate, or null.
     */
    private function matchingPasswordCandidate($storedHash, $password, $rawpassword)
    {
        $strength = substr((string)$storedHash, 4, 2);
        if (!is_numeric($strength)) {
            $strength = 999;
        }
        $candidates = [$password];
        if (!is_null($rawpassword) && $rawpassword !== '') {
            if ($strength < 13) {
                $candidates[] = Input::sanitize($rawpassword, true, true);
            }
            $candidates[] = $rawpassword;
        }
        foreach (array_unique($candidates) as $candidate) {
            if (password_verify($candidate, $storedHash)) {
                return $candidate;
            }
        }
        return null;
    }

    /**
     * Check a username (or email) and password without logging in: no session,
     * no remember-me cookie, no rehash and no login record. Returns the user id,
     * or false. Rate limits, banned accounts and TOTP are left to the caller;
     * verifyLoginCredentials() handles them the way users/login.php does.
     */
    public function checkCredentials($username, $password, $rawpassword = null)
    {
        $row = null;
        if (is_string($username) && $username !== '') {
            $row = filter_var($username, FILTER_VALIDATE_EMAIL) !== false
                ? $this->_db->query("SELECT id, password FROM users WHERE email = ? LIMIT 1", [$username])->first()
                : $this->_db->query("SELECT id, password FROM users WHERE username = ? LIMIT 1", [$username])->first();
        }
        if (!$row || $row->password === null) {
            // Same bcrypt cost as a real check, so response time doesn't reveal whether the account exists
            password_verify((string)$password, '$2y$13$WQJPF12kdq/UCcdF5MUHh.jwnqpaMU.Fh76ulGmVQ3UxQ1Na0v0.G');
            return false;
        }
        return $this->matchingPasswordCandidate($row->password, (string)$password, $rawpassword) !== null ? (int)$row->id : false;
    }

    // Records a completed login: last_login/logins, the login log row and us_ip_list.
    // login.php passes $recordLogin = false to loginEmail() and calls this once TOTP (if any) has passed.
    public function recordLogin($userId = null)
    {
        $userId = $userId ?? $this->data()->id;
        $date = date('Y-m-d H:i:s');
        $this->_db->query('UPDATE users SET last_login = ?, logins = logins + 1 WHERE id = ?', [$date, $userId]);
        $ip = ipCheck();
        $this->_db->insert('logs', ['logdate' => $date, 'user_id' => $userId, 'logtype' => 'login', 'lognote' => 'User logged in.', 'ip' => $ip]);

        $q = $this->_db->query('SELECT id FROM us_ip_list WHERE ip = ?', [$ip]);
        $c = $q->count();
        if ($c < 1) {
            $this->_db->insert('us_ip_list', [
                'user_id' => $userId,
                'ip' => $ip,
                'timestamp' => $date,
            ]);
        } else {
            $f = $q->first();
            $this->_db->update('us_ip_list', $f->id, [
                'user_id' => $userId,
                'ip' => $ip,
                'timestamp' => $date,
            ]);
        }
    }

    //Google oAuth Login Stuff
    //
    // Used by the legacy google_login plugin (usplugins/src/google_login_legacy).
    // Returns a user row with `->id` and `->isNewAccount`, or null if the
    // lookup/insert ultimately produced nothing.
    //
    // $gender and $locale are part of the historical signature and are
    // retained for backward compatibility; they are intentionally unused.
    public function checkUser($oauth_provider, $oauth_uid, $fname, $lname, $email, $gender, $locale, $link, $picture)
    {
        $this->_db = DB::getInstance();
        $this->_sessionName = Config::get('session/session_name');
        $this->_cookieName = Config::get('remember/cookie_name');
        $now = date('Y-m-d H:i:s');

        // Case A: user is already linked to this oauth provider+uid.
        // Refresh only the profile fields the provider legitimately owns —
        // historically this method also clobbered username/email/active/
        // permissions on every login, which was a bug (and was silently
        // suppressed by a typo in the column list).
        $linked = $this->_db->query(
            'SELECT * FROM users WHERE oauth_provider = ? AND oauth_uid = ? LIMIT 1',
            [$oauth_provider, $oauth_uid]
        );
        if ($linked->count() > 0) {
            $existing = $linked->first();
            $this->_db->update('users', $existing->id, [
                'fname'     => $fname,
                'lname'     => $lname,
                'picture'   => $picture,
                'gpluslink' => $link,
                'modified'  => $now,
            ]);
            $result = $this->_db->query('SELECT * FROM users WHERE id = ? LIMIT 1', [$existing->id])->first();
            if ($result) {
                $result->isNewAccount = false;
            }
            return $result;
        }

        // Case B: a local user with this email exists but isn't oauth-linked
        // yet — link them. The legacy plugin links these itself before
        // calling us, so in practice this branch only fires for other
        // callers; previously it was an empty `if` and the trailing lookup
        // returned nothing, which crashed the caller.
        $byEmail = $this->_db->query('SELECT * FROM users WHERE email = ? LIMIT 1', [$email]);
        if ($byEmail->count() > 0) {
            $existing = $byEmail->first();
            $this->_db->update('users', $existing->id, [
                'oauth_provider' => $oauth_provider,
                'oauth_uid'      => $oauth_uid,
                'picture'        => $picture,
                'gpluslink'      => $link,
                'modified'       => $now,
            ]);
            $result = $this->_db->query('SELECT * FROM users WHERE id = ? LIMIT 1', [$existing->id])->first();
            if ($result) {
                $result->isNewAccount = false;
            }
            return $result;
        }

        // Case C: brand new account. Generate a username that doesn't
        // collide with any existing username OR email, then route through
        // create() so it picks up the same sanity checks as every other
        // user creation path.
        $username = $this->_uniqueOauthUsername($email);

        $newId = $this->create([
            'password'       => null,
            'username'       => $username,
            'active'         => 1,
            'oauth_provider' => $oauth_provider,
            'oauth_uid'      => $oauth_uid,
            'permissions'    => 1,
            'email_verified' => 1,
            'fname'          => $fname,
            'lname'          => $lname,
            'email'          => $email,
            'picture'        => $picture,
            'gpluslink'      => $link,
            'join_date'      => $now,
            'created'        => $now,
            'modified'       => $now,
        ]);

        $result = $this->_db->query('SELECT * FROM users WHERE id = ? LIMIT 1', [$newId])->first();
        if ($result) {
            // NOTE: $result->isNewAccount is a contract consumed by OAuth plugins
            // (e.g. usplugins/src/google_login_legacy/assets/google_oauth.php) to
            // detect first-time accounts. It is set dynamically on the returned
            // record, so static analysers can't see the read. Do not remove.
            $result->isNewAccount = true;
        }
        return $result;
    }

    private function _uniqueOauthUsername($email)
    {
        // Default to email-as-username (legacy behavior) when nothing else
        // is using it as either a username or an email.
        $taken = $this->_db->query(
            'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1',
            [$email, $email]
        )->count();
        if ($taken === 0) {
            return $email;
        }
        $base = strstr((string)$email, '@', true);
        if ($base === false || $base === '') {
            $base = 'user';
        }
        $base = preg_replace('/[^A-Za-z0-9._-]/', '', $base);
        if ($base === '') {
            $base = 'user';
        }
        for ($i = 1; $i <= 1000; $i++) {
            $candidate = $base . $i;
            $hit = $this->_db->query(
                'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1',
                [$candidate, $candidate]
            )->count();
            if ($hit === 0) {
                return $candidate;
            }
        }
        throw new Exception('Unable to generate a unique username for OAuth user.');
    }

    // End of Google Section

    public function exists()
    {
        return (!empty($this->_data)) ? true : false;
    }

    public function data()
    {
        return $this->_data;
    }

    public function isLoggedIn()
    {
        return $this->_isLoggedIn;
    }

    public function notLoggedInRedirect($location)
    {
        if ($this->_isLoggedIn) {
            return true;
        } else {
            Redirect::to($location);
        }
    }

    public function logout()
    {
        if ($this->_isLoggedIn) {
            $this->_db->query('DELETE FROM users_session WHERE user_id = ? AND uagent = ?', [$this->data()->id, Session::uagent_no_version()]);
        }
        Session::delete($this->_sessionName);
        Cookie::delete($this->_cookieName);
        session_unset();
        session_destroy();
    }

    public function update($fields = [], $id = null)
    {
        if (!$id && $this->isLoggedIn()) {
            $id = $this->data()->id;
        }

        if (!$id) {
            throw new Exception('No user id supplied for update.');
        }

        // Sanity checks: only run when the caller is actually changing
        // username or email. Password / pin / vericode / etc. updates
        // (the vast majority of update() callers) skip this entirely.
        if (array_key_exists('username', $fields) && $fields['username'] !== null && $fields['username'] !== '') {
            $u = $fields['username'];
            $check = $this->_db->query(
                'SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ? LIMIT 1',
                [$u, $u, $id]
            );
            if ($check->count() > 0) {
                throw new Exception('Username is already in use.');
            }
        }
        if (array_key_exists('email', $fields) && $fields['email'] !== null && $fields['email'] !== '') {
            $e = $fields['email'];
            $check = $this->_db->query(
                'SELECT id FROM users WHERE (email = ? OR username = ?) AND id != ? LIMIT 1',
                [$e, $e, $id]
            );
            if ($check->count() > 0) {
                throw new Exception('Email is already in use.');
            }
        }

        if (!$this->_db->update('users', $id, $fields)) {
            throw new Exception('There was a problem updating.');
        }
    }
}
