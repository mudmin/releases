<?php
//this file exists to tell userspice that we are using a "modern" template as of v5.5
//so we can prevent loading unnecessary assets
?>
