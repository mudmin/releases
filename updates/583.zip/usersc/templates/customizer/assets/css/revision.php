<?php
// This file is automatically updated by the processor.php script
// Do not edit manually

$css_revision = 'custom-bootstrap-20250325130917.css';
$child_themes = array (
  'dashboard' => 'dashboard-20250325130917.css',
);
