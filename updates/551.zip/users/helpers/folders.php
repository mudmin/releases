<?php $path=['','users/','usersc/']; ?>
