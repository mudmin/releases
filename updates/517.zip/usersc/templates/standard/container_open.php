<div>
  <!-- feel free to change between container or container fluid -->
  <div class="<?=$settings->container_open_class; ?>">
