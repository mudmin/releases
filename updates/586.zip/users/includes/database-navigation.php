<?php
require_once($abs_us_root.$us_url_root.'users/includes/template/database_navigation_prep.php');
require_once($abs_us_root.$us_url_root.'users/includes/template/database_navigation_style.php');
require_once($abs_us_root.$us_url_root.'users/includes/template/database_navigation_content.php');
require_once($abs_us_root.$us_url_root.'users/includes/template/database_navigation_closing.php');
