<?php
//The old functions have been deprecated. They do not exist in any current plugins.  Updaters will see them in the 6.0.1 file in usersc/includes/deprecated/601.php
//they will not be included in new installs.