<?php
//This file parses all the various messages that are stored in
//$_GET and $_SESSION variables and displays them
//note that if you create a usersc/includes/system_messages_footer.php
//your file will be included instead of ours

//Grab all the various session messages and parse them
$usSessionMessages = parseSessionMessages();
//you can create your own $usSessionMessageClasses to choose your own classes
//just include it anywhere before the footer (head_tags is a good choice)
if(!isset($usSessionMessageClasses)){
  $usSessionMessageClasses = array(
    'err'=>"primary",       //err= in the url
    'msg'=>"info",          //msg= in the url
    'genMsg'=>"dark",       //$_SESSION[Config::get('session/session_name')."genMsg"]
    'valSuc'=>"success",    //validation class success message
    'valErr'=>"danger",     //validation class error message
  );
}
//Grab GET variables and display anything you have
?>
<script type="text/javascript">
$(document).ready(function() {
<?php
  //look for the old school ?err=Whatever in the url
  if (Input::get('err') != '') { ?>
    userSpiceMessages("<?php echo htmlspecialchars_decode(htmlspecialchars(Input::get('err'))); ?>","errUserSpiceMessage","<?php echo $usSessionMessageClasses['err']; ?>");
<?php
  }

  //look for the old school ?msg=Whatever in the url
  if (Input::get('msg') != '') { ?>
    userSpiceMessages("<?php echo htmlspecialchars_decode(htmlspecialchars(Input::get('msg'))); ?>","msgUserSpiceMessage","<?php echo $usSessionMessageClasses['msg']; ?>");

<?php }
    //define the types of messages and what class they get
    $keys = [
      'genMsg' => $usSessionMessageClasses['genMsg'],
      'valSuc' => $usSessionMessageClasses['valSuc'],
      'valErr' => $usSessionMessageClasses['valErr'],
    ];

    //Display any messages that have been set in the $_SESSION variables
    foreach ($keys as $key => $class) {
        if (isset($usSessionMessages[$key]) && $usSessionMessages[$key] != '') { ?>
        userSpiceMessages("<?php echo htmlspecialchars_decode(htmlspecialchars($usSessionMessages[$key])); ?>","<?php echo $key; ?>UserSpiceMessage","<?php echo $class; ?>");
        <?php
      }
    }
    if (isset($settings->err_time)) {
        $usMsgErrorTimeout = $settings->err_time * 1000;
    } else {
        $usMsgErrorTimeout = 10000;
    }
    ?>

    function userSpiceMessages(msg, div, cls = "") {
      createToast(msg, cls);
    }
  });

  // Global UserSpice toast functions
  function usSuccess(messages) {
    showToast(messages, 'success');
  }

  function usError(messages) {
    showToast(messages, 'danger');
  }

  function usWarning(messages) {
    showToast(messages, 'warning');
  }

  function showToast(messages, type) {
    let messageList = [];

    if (typeof messages === 'string') {
      try {
        messageList = JSON.parse(messages);
      } catch(e) {
        messageList = [messages];
      }
    } else if (Array.isArray(messages)) {
      messageList = messages;
    } else {
      messageList = [String(messages)];
    }

    messageList.forEach(msg => {
      createToast(msg, type);
    });
  }

  function createToast(message, type) {
    const typeMap = {
      'primary': 'primary',
      'info': 'info',
      'dark': 'dark',
      'success': 'success',
      'danger': 'danger',
      'warning': 'warning'
    };

    const barClass = typeMap[type] || 'info';
    const container = $('#toast-container');
    const justify = container.data('justify') || 'center';
    const isLeft = justify === 'left';

    const toastClasses = `toast us-toast ${isLeft ? 'us-toast-left' : ''}`;
    const flexDirection = isLeft ? 'flex-row-reverse' : 'flex-row';

    const toastHtml = `
      <div class="${toastClasses}" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="us-toast-bar ${barClass}"></div>
        <div class="d-flex ${flexDirection} align-items-start">
          <div class="us-toast-body flex-grow-1">${escapeHtml(message)}</div>
          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
      </div>`;

    container.append(toastHtml);
    const toastElement = container.find('.toast').last()[0];
    const toast = new bootstrap.Toast(toastElement, {
      delay: <?php echo $usMsgErrorTimeout; ?>
    });
    toast.show();

    toastElement.addEventListener('hidden.bs.toast', function () {
      $(this).remove();
    });
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
</script>
