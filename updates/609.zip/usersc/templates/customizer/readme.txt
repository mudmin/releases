If you distribute/modify this code, it is recommended that you release it without the following files.

usersc/templates/customizer/assets/css/customizations.php
usersc/templates/customizer/assets/css/custom-bootstrap-202xxxxxxxxx.css
usersc/templates/customizer/assets/css/revision.php
usersc/templates/customizer/assets/child_themes/dashboard.php
usersc/templates/customizer/assets/child_themes/dashboard-202xxxxxxxxx.css

You can put defaults for these in usersc/templates/customizer/assets/defaults

By doing this you will not overwrite anyone's existing files. The first time the template loads without finding
usersc/templates/customizer/assets/css/customizations.php
It will create a new set of defaults.  Otherwise, the existing files will be left alone during the update process.


PRESETS
-------
Pre-made child themes ship in:

usersc/templates/customizer/assets/presets/

Each preset is a single .php file that returns an array of `--bs-*` overrides
(keys drop the `--bs-` prefix and use hyphens) plus an optional `custom_css`
string, with a metadata docblock at the top (Preset / Category / Description /
Tags / Mode / Author).

On every customizer load, syncCustomizerPresets() (in initialize.php) copies any
preset from assets/presets/ that is not yet present in assets/child_themes/.
It NEVER overwrites — a preset a user has loaded, edited, or saved over is left
alone. So:

  - Ship new presets by adding .php files to assets/presets/. They appear for
    users automatically on their next customizer visit.
  - Updating the theme never disturbs a user's existing/edited child themes.
  - Removing a preset from assets/presets/ in an update does NOT remove it from
    installs that already have it.

When you distribute the theme, ship assets/presets/ (your preset pack) but you
do NOT need to ship assets/child_themes/ — that directory is per-install and is
seeded from assets/presets/ on first load.
