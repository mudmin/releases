;<?php die();?>
documentation = 1
hooker = 1