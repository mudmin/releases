-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2019 at 10:13 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `us5`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit`
--

CREATE TABLE `audit` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `page` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip` varchar(255) NOT NULL,
  `viewed` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `audit`
--

INSERT INTO `audit` (`id`, `user`, `page`, `timestamp`, `ip`, `viewed`) VALUES
(1, 0, '4', '2019-08-06 09:52:24', '::1', 0),
(2, 0, '4', '2019-09-26 11:02:08', '::1', 0),
(3, 0, '100', '2019-10-02 23:46:44', '::1', 0),
(4, 0, '100', '2019-10-02 23:50:29', '::1', 0),
(5, 0, '99', '2019-10-03 18:19:05', '::1', 0),
(6, 0, '99', '2019-10-03 18:19:08', '::1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `crons`
--

CREATE TABLE `crons` (
  `id` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `sort` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `createdby` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crons`
--

INSERT INTO `crons` (`id`, `active`, `sort`, `name`, `file`, `createdby`, `created`, `modified`) VALUES
(1, 0, 100, 'Auto-Backup', 'backup.php', 1, '2017-09-16 07:49:22', '2017-11-11 20:15:36');

-- --------------------------------------------------------

--
-- Table structure for table `crons_logs`
--

CREATE TABLE `crons_logs` (
  `id` int(11) NOT NULL,
  `cron_id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `documentation`
--

CREATE TABLE `documentation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `example` varchar(255) NOT NULL,
  `type_example` varchar(255) NOT NULL,
  `doc` text NOT NULL,
  `see_also` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documentation`
--

INSERT INTO `documentation` (`id`, `title`, `type`, `file`, `purpose`, `example`, `type_example`, `doc`, `see_also`) VALUES
(1, 'size', 'function', 'users/helpers/helpers.php', 'Returns the size of a file', 'echo size(&#039;z_us_root.php&#039;);', 'echo size(filename);', '<!>Returns the size of a file. Returns a result such as\r\n<@>586 B\r\n<@>1 KB\r\n<@>2 MB', ''),
(2, 'sanitize', 'function', 'users/helpers/helpers.php', 'Runs PHP htmlentities on a string and returns it', '$script = sanitize(&quot;&lt;script&gt;javascripthere&lt;/script&gt;&quot;);', '$script = sanitize(string);', '<!>Performs basic htmlentities sanitization with the options of\r\n<!>php ENT_QUOTES, \'UTF-8\'\r\n<!>This function is old and Input::sanitize from the Input class is preferred.', ''),
(3, 'currentPage', 'function', 'users/helpers/helpers.php', 'Returns the file name of the current page (not including path)', 'echo currentPage();', '', '<!>Note: Most of the time this has already been called in a header and you can simply reference the\r\n<!>th4$currentPage\r\n<!>variable to get the page name', '4'),
(4, 'currentFolder', 'function', 'users/helpers/helpers.php', 'Returns the folder your file is currently in', 'echo currentFolder();', '', '							<!>Very simple function to refer to the current folder of the file it is being called from. If you called this function from users/login.php it would return\r\n<!>th4\"users\"												', '3'),
(5, 'format_date', 'function', 'users/helpers/helpers.php', 'Deprecated. Do Not Use.', '', '', '<!>Use PHP\'s built in date functions instead.', ''),
(6, 'abrev_date', 'function', 'users/helpers/helpers.php', 'Deprecated. Do Not Use.', '', '', '																																																																						<!>Use PHP\'s built in date functions instead.	\r\n\r\n																																			', ''),
(7, 'money', 'function', 'users/helpers/helpers.php', 'Formats numbers to US currency format', 'echo money(20.50);', 'money(float);', '<!>Note: It is not recommended that you store currency symbols in the database along with the amounts.\r\n<!>php <?=money(20.50);?>\r\n<!>prints\r\n<!>$20.50						', ''),
(8, 'name_from_id', 'function', 'users/helpers/helpers.php', 'Returns the username when given a user&#039;s id', 'echo name_from_id(1);', 'name_from_id(int);', '							<!>This is less flexible than the echoUser function, but it may be useful.\r\n<!>It automatically capitalizes the first letter.\r\n<!>php <?php echo name_from_id(1);?>\r\n<!>prints\r\n<!>Admin												', ''),
(9, 'display_errors', 'function', 'users/helpers/helpers.php', 'Deprecated. Do Not Use.', '', '', '<!>This function is available for code that is based on very old versions of UserSpice, but javascript-based solutions are recommended now.					', ''),
(10, 'display_successes', 'function', 'users/helpers/helpers.php', 'Deprecated. Do Not Use.', '', '', '<!>This function is available for code that is based on very old versions of UserSpice, but javascript-based solutions are recommended now.					', ''),
(11, 'email', 'function', 'users/helpers/helpers.php', 'Send an email if properly configured', 'email(&quot;bob@aol.com&quot;,&quot;Hi Bob&quot;,&quot;This is an email&quot;);', 'email(&quot;email_address&quot;,&quot;subject_line&quot;,&quot;', '<!>Note: Email settings must be properly configured and tested in the Email Settings section of the dashboard.\r\n<!>Options:\r\n<!>You can also pass\r\n<!>php$opts = array(<@>\r\n \'email\' => \'from_email@aol.com\',<@>\r\n \'name\'  => \'Bob Smith\'<@>\r\n;<@>\r\n\r\n<!>Which would be formatted as:\r\n<!>phpmail(\"bob@aol.com\",\"Hi Bob\",\"This is an email\",$opts);\r\n<!>Attachments are also possible by doing\r\n<!>php$attachment = \"welcome.pdf\";\r\n<!>phpemail(\"bob@aol.com\",\"Hi Bob\",\"This is an email\",$opts,$attachment);\r\n											', ''),
(12, 'email_body', 'function', 'users/helpers/helpers.php', 'Predefined email templates can be stored in users/views', '$body = email_body(&#039;_email_adminPwReset.php&#039;,$params);', '$body = email_body(&#039;email_view&#039;,$params);', '<!>You can pass variables from your PHP page directly into the email.  It would look something like this.\r\n<!>php $params = array(\r\n<!>php \'username\' => $userdetails->username,\r\n<!>php \'sitename\' => $settings->site_name,\r\n<!>php \'fname\' => $userdetails->fname,\r\n<!>php  \'email\' => rawurlencode($userdetails->email),\r\n<!>php \'vericode\' => $userdetails->vericode,\r\n<!>php \'reset_vericode_expiry\' => $settings->reset_vericode_expiry\r\n<!>php  );\r\n<!>php $to = rawurlencode($userdetails->email);\r\n<!>php  $subject = \'Password Reset\';\r\n<!>php $body = email_body(\'_email_adminPwReset.php\',$params);\r\n<!>php  email($to,$subject,$body);\r\n																	', '11'),
(13, 'dump', 'function', 'users/helpers/helpers.php', 'Provides a formatted var_dump of a variable', 'dump($db-&gt;errorString);', 'Any', '<!>Simply adds pre tags around each item in the var_dump for better formatting and clearer results.', '14'),
(14, 'dnd', 'function', 'users/helpers/helpers.php', 'Provides a formatted var_dump of a variable and kills the page', 'dnd($db-&gt;errorString);', 'Any', '							<!>Simply adds pre tags around each item in the var_dump for better formatting and clearer results.<@>  The best use for this is during debugging or right before a redirect when you want PHP to stop executing.												', '13'),
(15, 'bold', 'function', 'users/helpers/helpers.php', 'Puts a bold message at the top of a page', 'bold(&quot;This message is bold&quot;);', 'bold(string);  bold(float);', '																																										<!>Please note that each template treats this slightly differently.<@>\r\nThere are 2 main uses of this.\r\n<!>1. Calling it directly with\r\n<!>th5<?=bold(\"This message is bold\");?>\r\n<!>2. Adding it to a url like\r\n<!>th5<?php Redirect::to(\'index.php&msg=This+message+is+bold\');?>\r\n<!>Both will produce the same result.																																																																													', '16'),
(16, 'err', 'function', 'users/helpers/helpers.php', 'Puts a red message at the top of a page', 'err(&quot;This message is red&quot;);', 'err(string);', '																					<!>Please note that each template treats this slightly differently.\r\n<!>There are 2 main uses of this.\r\n<!>1. Calling it directly with\r\n<!>php <?=err(\"This message is bold\");?>\r\n<!>2. Adding it to a url like \r\n<!>php <?php Redirect::to(\'index.php&err=This+message+is+bold); ?>\r\n<!>Both will produce the same result.																								', '15'),
(17, 'parse_ini_file', 'function', 'users/helpers/helpers.php', 'Internal use only', '', '', '<!>Do not modify or use this function.<@>Internal use only.', ''),
(18, 'write_php_ini', 'function', 'users/helpers/helpers.php', 'Provides a safe way to turn an array into an ini file', 'write_php_ini([&#039;mode&#039;=&gt;1],&quot;settings.ini.php&quot;);', 'write_php_ini(array,file_name);', '							<!>Note. This will create the file even if it doesn\'t exist. It is also recommended that you call your ini files ini.php so they cannot be read through the browser.\r\n<@>Notice if you do \r\n<!>php <?php  write_php_ini([\'mode\'=>1],\"settings.ini\"); ?>\r\n<!>you can navigate to that file in the browser and read it, but with \r\n<!>php <?php write_php_ini([\'mode\'=>1],\"settings.ini.php\"); ?>\r\n<!>you cannot.						', ''),
(19, 'safefilerewrite', 'function', 'users/helpers/helpers.php', 'Write to a file without conflicts', 'safefilerewrite(&quot;myfile.ini.php&quot;, &quot;Hello world&quot;);', 'safefilerewrite(file_name, contents);', '<!>Note that this function is primarily used for ini files, but if you need a similar function, you can copy the function itself to usersc/includes/custom_functions.php and change\r\n<!>php <?php $security = \';<?php die();?>\'; ?>\r\n<!>to\r\n<!>php <?php $security = \'\'; ?>																														', ''),
(22, 'redirect', 'function', 'users/helpers/helpers.php', 'Redirect to another page', 'redirect($location)', 'redirect(url)', '							<!>This method only uses header location.  It is preferable to use \r\n<!>php <?php Redirect::to(\'url\'); ?>						', ''),
(34, 'userIdExists', 'function', 'users/helpers/users.php', 'Check if user id exists', 'userIdExists(1)', 'userIdExists(int)', '							<!>Returns true or false depending on whether a given user id exists in the database		\r\n<!>php <?php if(userIdExists(1)){\r\n<@>//do something\r\n<@> }?>						', ''),
(35, 'fetchAllUsers', 'function', 'users/helpers/users.php', 'Returns all data from the users table', '$users = fetchAllUsers();', 'fetchAllUsers($orderBy=[], $desc=[], $disabled=true)', '														<!>Older function primarily for compatibility purposes\r\n<@>To fetch all users, simply call\r\n<!>php <?php $users = fetchAllUsers(); ?>\r\n<!>To fetch all users ordered by username, call\r\n<!>php <?php $users = fetchAllUsers(\'username\'); ?>\r\n<!>To fetch all users ordered by username descending, call\r\n<!>php <?php $users = fetchAllUsers(\'username\',true); ?>\r\n<!>To fetch all users ordered by username descending including banned users, call\r\n<!>php <?php $users = fetchAllUsers(\'username\',true,true); ?>												', '36,41'),
(36, 'fetchUserDetails', 'function', 'users/helpers/users.php', 'Retrieves info on a single user', 'fetchUserDetails(null,null,1)', 'fetchUserDetails($username=NULL,$token=NULL, $id=NULL)', '							<!>Returns the data of a single user. \r\n<@>To get a single user\'s data by id call \r\n<!>php <?php $data = fetchUserDetails(null,null,1);?>\r\n<@>To get a single user\'s data by username call \r\n<!>php <?php $data = fetchUserDetails(\'username\',\'admin\');?>\r\n<@>To get a single user\'s data by email call \r\n<!>php <?php $data = fetchUserDetails(\'email\',\'bob@aol.com\');?>						', '35,41'),
(37, 'deleteUsers', 'function', 'users/helpers/users.php', 'Deletes multiple users', 'deleteUsers($users)', 'deleteUsers(array)', '<!>Note this is a very old function that does not have a lot of practical uses.\r\n<@>													It expects you to pass an array of user ids that need to be deleted.\r\n<!>php    <?php deleteUsers([5,17,24]);', ''),
(38, 'echouser', 'function', 'users/helpers/users.php', 'A flexible function to echo out some type of user name', 'echouser($id)', 'echouser(int)', '																																			<!>This function has a setting on the Admin Dashboard it is located on\r\n<@>Dashboard->settings->general->User Settings\r\n<@>You can choose between\r\n<!>th5 Fname, Lname\r\n<!>th5 Username\r\n<!>th5 Username (Fname Lname)\r\n<!>th5 Username (Fname)\r\n<!>The way this function works, if you change that setting on the dashboard,<@> echoUser will change how it displays usernames everywhere that function is called on your site\r\n<!>Example outputs would be\r\n<!>th5 Dan Hoover [Fname Lname]\r\n<!>th5 Admin [Username]\r\n<!>th5 Admin (Dan Hoover) [Username (Fname Lname)]\r\n<!>th5 Admin (Dan) [Username (Fname)]																														', ''),
(39, 'echousername', 'function', 'users/helpers/users.php', 'Returns the username of the user', 'echousername($id)', 'echousername(int)', '<!>Simply returns the username. \r\n<@>This works well when you have echoUser set to something else and you\r\n<@>want to override that setting and always show the username\r\n<@>If the user id you pass does not belong to a valid user, it will return\r\n<!>th5 \"Unknown\"', '38'),
(40, 'updateUser', 'function', 'users/helpers/users.php', 'Updates a single piece of user data', 'updateUser(&#039;email&#039;,1,&#039;bob@aol.com&#039;)', 'updateUser($column, $id, $value)', '<!>Updates  a single column of a single user on the users table\r\n<@>Returns the full database response including errors\r\n<!>php <?php $users = updateUser(\'email\',1,\'bob@aol.com\');?>					', ''),
(41, 'fetchUserName', 'function', 'users/helpers/users.php', 'Returns First and Last Name of user', 'fetchUserName(null,null,1)', 'fetchUserName($username=NULL,$token=NULL, $id=NULL)', '<!>Returns first and last name of the user concatenated together\r\n<!>php <?php fetchUserName(null,null,1); ?>\r\n<!>returns\r\n<!>The Admin\r\n<!>This function is here for compatibility reasons															', '35,36'),
(42, 'isAdmin', 'function', 'users/helpers/users.php', 'Returns whether or not a user has permission level 2', 'isAdmin()', 'isAdmin()', '<!>Always refers to the logged in user.\r\n<@>This is primarily used to figure out if the logged in user is an admin\r\n<@>While they are cloaked into another user.  In other words\r\n<@>If a user is Admin, but they are cloaked into a user with only basic \"user\"\r\n<@>level access, isAdmin will still return true\r\n<!>php <?php if(isAdmin()){\r\n<@>//do something\r\n<@>}else{\r\n<@>//do something else\r\n<@>} ?>', ''),
(43, 'permissionIdExists', 'function', 'users/helpers/permissions.php', 'Tells whether a permission id exists in UserSpice', 'permissionIdExists(2)', 'permissionIdExists(permission_id)', '<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php <?php if(permissionIdExists(2)){echo \'this is a valid UserSpice permission id\'; } ?>							', ''),
(44, 'fetchPermissionDetails', 'function', 'users/helpers/permissions.php', 'Returns the id and permission name of a permission level', 'fetchPermissionDetails(2)', 'fetchPermissionDetails(permission_id)', '<!>This is an internal function not generally used by developers.\r\n<!>php  <?php $info = fetchPermissionDetails(2)?>\r\n<!> returns an object that contains the id and permission name\r\n<@>of permission level 2.  In this case, that\'s 2 and admin					', ''),
(45, 'updatePermissionName', 'function', 'users/helpers/permissions.php', 'Change a permission level&#039;s name', 'updatePermissionName($id, $name)', 'updatePermissionName($id, $name)', '<!>This should only be done through the User Interface.', ''),
(46, 'fetchUserPermissions', 'function', 'users/helpers/permissions.php', 'Retrieve a list of permission levels that a user has', 'fetchUserPermissions(2)', 'fetchUserPermissions(user_id)', '<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php <?php $data = fetchUserPermissions(2); ?>\r\n<!>Will return an array of objects. Each object will contain the id in the table user_permission_matches, the permission id, and the user id of the user with that permission level.\r\n<@>So, if you have a user with 10 permission levels, you will get an array of 10 objects.											', ''),
(47, 'fetchPermissionUsers', 'function', 'users/helpers/permissions.php', 'Retrieve a list of users who have a permission level', 'fetchPermissionUsers(2)', 'fetchPermissionUsers(permission_id)', '<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php <?php $data = fetchPermissionUsers(2); ?>\r\n<!>Will return an array of objects. Each object will contain the id in the table user_permission_matches as well as the user id of the user with that permission level.\r\n<@>So, if you have 10 users with that level, you will get an array of 10 objects.', ''),
(48, 'removePermission', 'function', 'users/helpers/permissions.php', 'Removes a permission level from user_permission_matches', 'removePermission($permissions, $members)', 'removePermission($permissions, $members)', '<!>This should only be done through the User Interface', ''),
(49, 'getPathPhpFiles', 'function', 'users/helpers/permissions.php', 'Retrieve a list of all .php files in folder', 'getPathPhpFiles($abs_us_root,$us_url_root,&#039;usersc/plugins/&#039;);', 'getPathPhpFiles($absRoot,$urlRoot,$fullPath)', '<!>The first two arguments are always $abs_us_root $us_url_root  (and probably should have been obtained automatically).  The third argument is the folder that you want to retrieve all the php files from.  It should end with a trailing \'/\'\r\n<!>php <?php $data = getPathPhpFiles($abs_us_root,$us_url_root,\'usersc/scripts/\'); ?>\r\n<!>Will return an array of (usually) 10 files.  Each item of the array will be an\r\n<@>array with the path of the file in it.', ''),
(50, 'deletePages', 'function', 'users/helpers/permissions.php', 'Deletes pages From the database', 'deletePages(2)', 'deletePages(page_id)', '<!>This is an internal UserSpice function that is not generally used by developers.								', ''),
(51, 'fetchAllPages', 'function', 'users/helpers/permissions.php', 'Grabs all pages from the database', 'fetchAllPages()', 'fetchAllPages()', '<!>This is primarily an internal UserSpice function and is not generally used by developers.\r\n<!>php <?php $pages = fetchAllPages();\r\n<@>dump($pages); ?>\r\n<!>dumps an array of page objects containing \r\n<@>id, page, title, private, re_auth for each page', ''),
(52, 'fetchPageDetails', 'function', 'users/helpers/permissions.php', 'Returns information about a page based on id', 'fetchPageDetails(1)', 'fetchPageDetails(page_id)', '<!>This is an internal function that is generally not used by developers.\r\n<!>php 	<?php $deets = fetchPageDetails(1);?>\r\n<!>returns\r\n<@>id, page, title, private, re_auth for index.php', ''),
(53, 'pageIdExists', 'function', 'users/helpers/permissions.php', 'Tells whether a page id is used in UserSpice', 'pageIdExists(1)', 'pageIdExists(page_id)', '														<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php <?php if(pageExists(1)){echo \'this is a valid UserSpice page id\'; } ?>', ''),
(54, 'updatePrivate', 'function', 'users/helpers/permissions.php', 'Toggles the private/public setting of a page', 'updatePrivate($id, $private)', 'updatePrivate($id, $private)', '<!>This should only be done through the User Interface.								', ''),
(55, 'createPages', 'function', 'users/helpers/permissions.php', 'Adds a page to the Database', 'createPages([&#039;page1.php&#039;,&#039;page2.php&#039;);', 'createPages(pages array)', '<!>This is an internal UserSpice Function that is generally not used by developers.									', ''),
(56, 'addPage', 'function', 'users/helpers/permissions.php', 'Add  a permission level to a page', 'addPage(28,2);', 'addPage(page id, permission id)', '<!>Add a permission level to a page in the database. Must be called by the page id.\r\n<@>This is usually done in the UI of UserSpice and this function is not really used by\r\n<@>developers.\r\n<!>php <?php addPage(28,2); ?>', ''),
(57, 'securePage', 'function', 'users/helpers/permissions.php', 'Checks if a user has access to a page', 'if (!securePage($_SERVER[&#039;PHP_SELF&#039;])){die();}', 'securePage($uri)', '																												<!>This is the core UserSpice function that determines if someone is allowed to visit a page.\r\n<@>In order for this to function properly, several things must be true\r\n<@>1. The page should end in a .php extension.\r\n<@>2. The page should have the init file required before securePage is called\r\n<@>3. The page must be in the database.  It should be added automatically assuming that UserSpice is set to monitor that folder.\r\n<@>\r\n<@>If a user is in the $master_account array (defined in init.php) this will always return true.\r\n<@>If a user has been banned, this will always return false.\r\n<@>If a user is an admin and this page is protectable but it is not in the database, you will be redirected to the page security settings.\r\n<@>If a user is not admin and visits a page that isn\'t in the db, they will be told to contact admin. \r\n<@>If a page is public, anyone can visit it.\r\n<@>If it is private and the user is logged out, they will be redirected back to this page after logging in\r\n<@>A person who tries to visit a page for which they do not have permission will be logged in \"security logs\" in the dashboard\r\n<@>\r\n<@>The typical usage for this function is\r\n<!>php <?php if (!securePage($_SERVER[\'PHP_SELF\'])){die();} ?>																								', ''),
(58, 'fetchPagePermissions', 'function', 'users/helpers/permissions.php', 'Returns a list of permission levels that can access a page', 'fetchPagePermissions(1)', 'fetchPagePermissions(page_id)', '<!>This is an internal function not generally used by developers.\r\n<!>php  <?php $perms = fetchPagePermissions(24);?>\r\n<!> returns an object that contains the id and permission_id from\r\n<@>user_permission_matches that can access page 24', ''),
(59, 'fetchPermissionPages', 'function', 'users/helpers/permissions.php', 'Returns a list of pages that a permission level can access', 'fetchPermissionPages(1)', 'fetchPermissionPages(permission_id)', '<!>This is an internal function not generally used by developers.\r\n<!>php  <?php $pages = fetchPermissionPages(1);?>\r\n<!> returns an object that contains the id, page id, page name, and private status\r\n<@>of every page explicitly open to permission level 1	', ''),
(60, 'removePage', 'function', 'users/helpers/permissions.php', 'Removes a page from permission_page_matches', 'removePage($pages, $permissions)', 'removePage($pages, $permissions)', '<!>This should only be done in the User Interface', ''),
(61, 'checkMenu', 'function', 'users/helpers/permissions.php', 'Check if a user has a permission level', 'checkMenu(2)', 'checkMenu(permission_id, optional user id)', '							<!> This poorly named function comes all the way back from the UserCake days.\r\n<@>It was primarily used to see if a user could see a menu item\r\n<@>It has primarily been replaced by hasPerm which accepts an array\r\n<@>This function returns true or false\r\n<!>php <?php if(checkMenu(2)){\r\n<@>//user has permission, do something\r\n<@>} ?>						', '67'),
(62, 'fetchAllPermissions', 'function', 'users/helpers/permissions.php', 'Grabs all permission levels', 'fetchAllPermissions()', 'fetchAllPermissions()', '<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php	<?php $perms = fetchAllPermissions();\r\n<@>dump($perms); ?>\r\n<!>returns an array of objects containing \r\n<@>id, permission name name for each permission level	\r\n<!>img                                plugin.pnghjgf																								', ''),
(63, 'checkPermission', 'function', 'users/helpers/permissions.php', 'Checks if a user has a permission level', 'checkPermission(2)', 'checkPermission(permission_level)', '							<!>This is an old UserCake function that checks if the logged in user \r\n<@>has a certain permission level.\r\n<@>This automatically returns true if the user\'s id is 1\r\n<!>php <?php if(checkPermission(2)){\r\n<@>echo \"The user has permission level 2\";\r\n<@>} ?>						', '61,67'),
(64, 'permissionNameExists', 'function', 'users/helpers/permissions.php', 'Tells whether a permission name exits in UserSpice', 'permissionNameExists(&#039;admin&#039;)', 'permissionNameExists(permission_name)', '<!>This is generally an internal UserSpice function and is not usually used by developers.\r\n<!>php <?php if(permissionNameExists(\'user\')){echo \'this is a valid UserSpice permission name\'; } ?>		', ''),
(65, 'addPermission', 'function', 'users/helpers/permissions.php', 'Adds a permission level to a user', 'addPermission(2, 36)', 'addPermission(permission_id, member_id)', '<!>This is primarily used by the UI and is not generally used by developers.\r\n<!>php <?php addPermission(2, 36); ?>', ''),
(66, 'deletePermission', 'function', 'users/helpers/permissions.php', 'Deletes multiple permission levels', 'deletePermission([3,4,5])', 'deletePermission(permission array)', '<!>This is an internal UserSpice function not generally used by developers.							', ''),
(67, 'hasPerm', 'function', 'users/helpers/permissions.php', 'Allows you to check if a user group has a certain permission level', 'hasPerm([2,3,4])', 'hasPerm(single permission OR [array of permission levels], user_id)', '														<!>This is the preferred way to check a permission level.  \r\n<@>If the user is in the $master_account variable set in init.php, this will always return true.\r\n<@>In most places in the UserSpice code the first argument is looking for an array of permission levels to check\r\n<@>As of version 5.0.5, if you only want to pass one permission level, you don\'t have to put it in [ ]\r\n<@>If no second argument is passed, it will assume you are talking about the logged in user\r\n<@>However most places in the UserSpice code explicitly pass in $user->data()->id anyway.\r\n<!>php <?php $check = hasPerm([1,2]); ?>\r\n<!>will return true if the logged in user has EITHER permission level 1 or 2.\r\n<!>php <?php $check = hasPerm(2); ?>\r\n<!>will return true if the logged in user has permission level 2.\r\n<!>php <?php $check = hasPerm([1,2],234); ?>\r\n<!>will return true if the logged in user #234 has EITHER permission level 1 or 2.												', '61'),
(68, 'echopage', 'function', 'users/helpers/permissions.php', 'Echoes page name when given a page id', 'echopage(1)', 'echopage(page_id)', '<!>Echo a page name from the id\r\n<!>php <?php echoPage(1);?>\r\n<!>echoes\r\n<@>index.php', ''),
(69, 'Config::get', 'method', 'users/classes/Config.php', 'Get configuration info from the init.php file', 'Config::get(&#039;mysql/username&#039;);', 'Config::get(configuration_option)', '<!>This is primarily used internally, but there may be times that you want to return configuration info\r\n<@>such as needing to connect another service to your database.  \r\n<!>php <?=$dbuser = Config::get(\'mysql/username\');?>\r\n<!>will grab your database username from the init.php file.', ''),
(70, 'Hash::make', 'method', 'users/classes/Hash.php', 'Creates an SHA-256 hash (optionally salted hash) from a string', 'Hash::make(&quot;Testing 123&quot;, $salt = &#039;abc&#039;);', 'make($string, $salt = &#039;&#039;)', '							<!>th1 Please note that hashing is not the same as encrypting.\r\n<!>This creates a deterministic hash, which means that whatever you hash will always\r\n<@>have the same result. This makes it a bad idea to use this for passwords.  It is more often\r\n<@>used for making sure things are identical.  In other words, if user 1 hashes a file and gets\r\n<@>the same result as user 2, you are able to determine with confidence that the file did \r\n<@>not change between user 1 and user 2 viewing it. 						', ''),
(71, 'Hash::salt', 'method', 'users/classes/Hash.php', 'Deprecated', 'Hash::salt($length)', 'Hash::salt($length)', '<!>th2 Deprecated. Do not use.\r\n<!>Deprecated in PHP 7.1. Removed in PHP 7.2\r\n<!>Creates an initialization vector (IV) from a random source.', ''),
(72, 'Hash::unique', 'method', 'users/classes/Hash.php', 'Create a unique, time-based hash', '$hash = Hash::unique();', 'Hash::unique();', '														<!>Creates a hash of PHP\'s unique() function. The unique function uses microtime, \r\n<@>so the idea is that no matter how many times you create a hash, it will not be repeated.\r\n<@>This is not great for cryptography but it is great to be part of a key or some sort of unique code.												', ''),
(73, 'Cookie::exists', 'method', 'users/classes/Cookie.php', 'Checks if a given cookie exists', 'Cookie::exists(&#039;pmqesoxiw318374csb&#039;)', 'exists($name)', '<!>Checks if a given cookie exists. \r\n<!>php <?php dump(Cookie::exists(\'cookieName\')); ?>\r\n<!>Returns either true or false.', ''),
(74, 'Cookie::get', 'method', 'users/classes/Cookie.php', 'Get&#039;s the cookie and assigns it to a variable', '$cookie = Cookie::get(&#039;cookieName&#039;);', 'Cookie::get(&#039;cookieName&#039;)', '							<!>Gets cookie by name.  Cookie name is set in init.php\r\n<!>php <?php $cookie = Cookie::get(\'pmqesoxiw318374csbx\'); ?>						', ''),
(75, 'Cookie::put', 'method', 'users/classes/Cookie.php', 'Puts a cookie on the user&#039;s system', 'Cookie::put(&#039;UserSpice&#039;, &#039;thisIsCookieData&#039; , Config::get(&#039;remember/cookie_expiry&#039;));', 'Cookie::put($name, $value, $expiry)', '<!>Puts a cookie on the user\'s system.\r\n<!>php <?php Cookie::put(\'UserSpice\', \'thisIsCookieData\' , Config::get(\'remember/cookie_expiry\')); ?>', ''),
(76, 'Cookie::delete', 'method', 'users/classes/Cookie.php', 'Expires cookie', 'Cookie::delete(&#039;cookieName&#039;)', 'Cookie::delete(&#039;cookieName&#039;)', '<!>Doesn\'t technically delete the cookie. It expires it and the system deletes it.\r\n<@>Cookie name is set in init.php\r\n<!>php <?php Cookie::delete(\'cookieName\'); ?>', ''),
(77, 'Session::exits', 'method', 'users/classes/Session.php', 'Checks for the existence of a session', 'Session::exits(&#039;sessionName);', 'Session::exits(&#039;sessionName);', '<!>Checks if a session exists when provided the session name\r\n<@>Session name can be found in init.php\r\n<!>php <?php if(Session::exists(\'user\')){ echo \"true\"; } ?>										', ''),
(78, 'Session::delete', 'method', 'users/classes/Session.php', 'Deletes the current session', 'Session::delete(&#039;sessionName&#039;)', 'Session::delete(&#039;sessionName&#039;)', '<!>Deletes the session when provided the session name\r\n<@>Session name can be found in init.php\r\n<!>php <?php Session::delete(\'user\'); ?>', ''),
(79, 'Session::get', 'method', 'users/classes/Session.php', 'Gets the value of a session', 'Session::get(sessionName)', 'Session::get(sessionName)', '<!>Gets the value of a session by name\r\n<@>Session name can be found in init.php\r\n<!>php <?php $mySession = Session:get(\'sessionName\');  ?>																									', ''),
(80, 'Session::flash', 'method', 'users/classes/Session.php', 'Refreshes a session', 'Session::flash(&#039;sessionName&#039;, &#039;&#039;);', 'Session::flash(session_name, optional_string)', '<!>Refreshes a session based on the session name.\r\n<@>Session name can be found in init.php\r\n<!>php <?php Session::flash(\'mySession\'); ?>																	', ''),
(81, 'Session::uagent_no_version', 'method', 'users/classes/Session.php', 'Returns some basic info about the visitor&#039;s system', 'Session::uagent_no_version()', 'Session::uagent_no_version()', '<!>This basic info can help you detect what kind of system a user is on.\r\n<!>php <?php $info = Session::uagent_no_version(); ?>\r\n<!>Returns something like \r\n<@>Mozilla (Windows NT 10.0; Win64; x64) AppleWebKit (KHTML, like Gecko) Chrome Safari\r\n<@>on Windows 10 Chrome 64 Bit\r\n<@>Browser types have become more muddled as they share many components.\r\n', ''),
(82, 'Session::put', 'method', 'users/classes/Session.php', 'Adds information to a user&#039;s session', 'Session::put(&#039;newData&#039;,&#039;Signed in with google&#039;);', 'Session::put(name,value)', '<!>Adds to the session variable. The name attribute can be arbitrary\r\n<!>For instance, UserSpice adds a language attribute to tell us what \r\n<@>language a user prefers.  That could look like\r\n<!>php <?php Session::put(\'us_lang\',\'en-US);', ''),
(83, 'Token::generate', 'method', 'users/classes/Token.php', 'Generates a token and saves it to a session variable.', 'Token::generate', 'Token::generate()', '<!>The token system is a type of two factor authentication system for forms. \r\n<@>When a form is generated on screen a token is generated and stored\r\n<@>in a session variable. It is then sent in via post with the rest of the form\r\n<@>Token::check makes sure those 2 tokens match. If they do not, it is assumed\r\n<@>that some sort of manipulation happened with the form.		\r\n<@>Token generate can only be used once per page. If you have multiple forms \r\n<@>create a variable \r\n<!>php <?php $token = Token::generate(); ?>\r\n<!>and put that variable as a hidden form field \r\n<!>php <input type=\"hidden\" name=\"csrf\" value=\"<?=$token?>\">', '84'),
(84, 'Token::check', 'method', 'users/classes/Token.php', 'Checks if the token in the session matches the token posted in the form', 'Token::check($token)', 'Token::check(token)', '<!>The token system is a type of two factor authentication system for forms. \r\n<@>When a form is generated on screen a token is generated and stored\r\n<@>in a session variable. It is then sent in via post with the rest of the form\r\n<@>Token::check makes sure those 2 tokens match. If they do not, it is assumed\r\n<@>that some sort of manipulation happened with the form.\r\n<!>php <?php \r\n<@>$token = Input::get(\'csrf\');\r\n<@>if(!Token::check($token)){\r\n<@>include($abs_us_root.$us_url_root.\'usersc/scripts/token_error.php\');\r\n<@>}', '83'),
(85, 'Input::exists', 'method', 'users/classes/Input.php', 'Checks if $_GET or $_POST form input exists', 'Input::exists()', 'exists(optionally the input type)', '							<!>Checks for the existence of post or get info\r\n<@>If nothing is passed, it checks for $_POST\r\n<@>You can also do\r\n<!>php <?php if(Input::exists(\'get\')){ //do something }\r\n<!>to check for the existence of a $_GET variable						', ''),
(86, 'Input::get', 'method', 'users/classes/Input.php', 'Gets and sanitizes form input for form processing.', 'Input::get(&#039;username&#039;)', 'Input::get(form_field_name)', '<!>Sanitizing your form input is critical to security.  Do not simply pass\r\n<@>$_GET or $_POST into your database.  This method properly escapes \r\n<@>the strings. \r\n<!>php <?php $username = Input::get(\'username\'); ?>\r\n<!>Please note that your data may require other types of security\r\n<@>checks before storing into the database, but this method handles the\r\n<@>basics.  ', '87'),
(87, 'Input::sanitize', 'method', 'users/classes/Input.php', 'Sanitizes non form data for storage in the database', 'Input::sanitize(&#039;aRandomStringOfData&#039;)', 'Input::sanitize(string)', '<!>Sanitizing your form input is critical to security.  Do not simply pass\r\n<@>$_GET or $_POST into your database.  This method properly escapes \r\n<@>the strings and is generally used when your data comes from some\r\n<@>user input other than a form. \r\n<!>php <?php $data = Input::sanitize(\'aRandomStringOfData\'); ?>\r\n<!>Please note that your data may require other types of security\r\n<@>checks before storing into the database, but this method handles the\r\n<@>basics.  															', '86'),
(89, 'user-&gt;create', 'method', 'users/classes/User.php', 'Creates a new UserSpice user and returns the id', 'user-&gt;create($fields = array()) (see below)', 'user-&gt;create($fields = array()', '<!>This is primarily an internal function, but there may be a use case for it in your own development.  \r\n<@>Please note that this does not automatically give the new user permissions, \r\n<@>however it does return the new id, so you can do that separately.  Also note that this does not do any\r\n<@>checking to make sure this email/username does not exist. That should be done first.\r\n<!>php <?php $theNewId = $user->create(array(\r\n<@>\'username\' =>Input::get(\'username\'),\r\n<@>\'fname\' => ucfirst(Input::get(\'fname\')),\r\n<@>\'lname\' => ucfirst(Input::get(\'lname\')),\r\n<@>\'email\' => Input::get(\'email\'),\r\n<@>\'password\' => password_hash(Input::get(\'password\', true), PASSWORD_BCRYPT, array(\'cost\' => 12)),\r\n<@>\'permissions\' => 1,\r\n<@>\'account_owner\' => 1,\r\n<@>\'join_date\' => date(\'Y-m-d H:i:s\'),\r\n<@>\'vericode\' => randomstring(15),\r\n<@>\'vericode_expiry=>date(\"Y-m-d H:i:s\",strtotime(\"+$settings->join_vericode_expiry hours\",strtotime(date(\"Y-m-d H:i:s\")))),\r\n<@>\'oauth_tos_accepted\' => true\r\n<@>));', ''),
(90, 'user-&gt;find', 'method', 'users/classes/User.php', 'Finds if a user exists based on id, username, or email', 'user-&gt;find(2)', 'user-&gt;find($user = null,$loginHandler = null)', '							<!>This method is not used in the UserSpice code, but it is basically checking if\r\n<@>a user exists and can handle 3 types of input.\r\n<@>1. Integer for user id\r\n<@>2. Email\r\n<@>3. String for username\r\n<@>Passing any of those values will return true if a user matching that criteria exists\r\n<!>php <?php $check = $user->find(2); ?>\r\n<!>php <?php $check = $user->find(\'bob@aol.com\'); ?>\r\n<!>and\r\n<!>php <?php $check = $user->find(\'admin\'); ?>\r\n<!>are all valid inputs.						', ''),
(91, 'user-&gt;login', 'method', 'users/classes/User.php', 'Logs in a user', '$user-&gt;login(&#039;admin&#039;,&#039;password&#039;);', 'login($username = null, $password = null, $remember = false)', '							<!>Note that the User class must be instantiated and then you can call user->login\r\n<!>php <?php $user = new User();\r\n<@>$user->login(\'admin\',\'password\');\r\n<@>?>						', '92'),
(92, 'user-&gt;loginEmail', 'method', 'users/classes/User.php', 'Logs in a user with an email address instead of username', '$user-&gt;login(&#039;admin@aol.com&#039;,&#039;password&#039;);', 'user-&gt;loginEmail($email = null, $password = null, $remember = false)', '<!>Note that the User class must be instantiated and then you can call user->login\r\n<!>php <?php $user = new User();\r\n<@>$user->login(\'admin@aol.com\',\'password\');\r\n<@>?>																								', '91'),
(93, 'user-&gt;checkUser', 'method', 'users/classes/User.php', 'Internal use only', '', '', '							<!>This function is for internal use only and will probably be deprecated or moved to the Google Login Plugin.																', ''),
(94, 'user-&gt;exists', 'method', 'users/classes/User.php', 'Checks if a user is logged in and the user class is instantiated', 'if($user-&gt;exists()){//do something }', 'user-&gt;exists()', '<!>This method is not used in UserSpice and the isLoggedIn method is preferable.\r\n<@>However, if a user is logged in and the user class is instantiated\r\n<!>php <?php $check = $user->exists(); ?>\r\n<!>would return true. Otherwise, it would return false. ', '96'),
(95, 'user-&gt;data', 'method', 'users/classes/User.php', 'Provides quick access to a piece of info about a logged in user', 'user-&gt;data()-&gt;username', 'user-&gt;data()-&gt;field_in_users_table', '<!>The logged in User\'s info is always readily available through user->data. \r\n<@>Generally the logged in user\'s info is stored in the $user variable so you\r\n<@>can echo a username with\r\n<!>php <?php echo $user->data()->username;?>\r\n<!>username can be replaced with any column in the users table \r\n<@>including ones you add yourself.', ''),
(96, 'user-&gt;isLoggedIn', 'method', 'users/classes/User.php', 'Checks if a user is logged in', 'if(isset($user) &amp;&amp; $user-&gt;isLoggedIn()){//do something }', 'user-&gt;isLoggedIn()', '<!>This method is generally used with isset($user) to avoid throwing errors.  \r\n<@>The typical usage is \r\n<!>php <?php if(isset($user) && $user->isLoggedIn()){//do something } ?>', ''),
(97, 'user-&gt;notLoggedInRedirect', 'method', 'users/classes/User.php', 'A conditional redirect statement', '$user-&gt;notLoggedInRedirect(&#039;users/login.php&#039;);', 'notLoggedInRedirect(location)', '<!>This method is not used in UserSpice.  It can, however be useful.  It\'s a quick way of saying if \r\n<@>a user is not logged in, they should be redirected to a certain page. Other functions such as\r\n<@>securePage (which will fail on private pages if a user is not logged in) and $user->isLoggedIn\r\n<@>are probably preferable.', ''),
(98, 'user-&gt;logout', 'method', 'users/classes/User.php', 'Logs out a user', '$user-&gt;logout();', 'user-&gt;logout()', '<!>Logs out a user.  Although you can use this method by calling\r\n<!>php <?php if ($user->isLoggedIn()) $user->logout(); ?>\r\n<!>Redirecting someone to users/logout.php is preferable because it also\r\n<!>destroys sessions and runs any logout scripts that you may have\r\n<@>created or decide to create in the future.', ''),
(99, 'user-&gt;update', 'method', 'users/classes/User.php', 'Updates an array of fields in the user table for the logged in user', '$user-&gt;update([&#039;username&#039;=&gt;&#039;bob&#039;]);', 'update($fields = array()', '<!>This is a (slightly) quicker way to update user information.  \r\n<@>You can pass an array of information about the user and update in one step.\r\n<!>php <?php $user->update([\'username\'=>\'bob\']); ?>', ''),
(103, 'Installation Issues', 'external', '', 'Learn how to diagnose common installation issues', '', '', 'https://userspice.com/installation-issues/', ''),
(104, 'Azure', 'external', '', 'Learn how to connect to an Azure database', '', '', 'https://userspice.com/connecting-to-azure/			', ''),
(106, 'Setting up Email', '', '', 'Learn how to configure your email server', '', '', 'https://userspice.com/email-settings/		', ''),
(107, 'Monitoring additional folders', '', '', 'Learn how to control folders with UserSpice', '', '', 'https://userspice.com/monitoring-additional-folders/		', ''),
(108, 'Upgrading from 3.x to 4.0', 'external', '', 'Learn how to make the jump', '', '', 'https://userspice.com/upgrading-from-userspice-3-x-to-4-0/	', ''),
(109, 'Permission Levels', 'external', '', '', 'Understanding UserSpice permission levels', '', 'https://userspice.com/how-permission-levels-work/		', ''),
(110, 'User Management', '', '', 'Learn how to manage your users', '', '', 'https://userspice.com/user-management/', ''),
(111, 'Backups', 'external', '', 'Using UserSpice&#039;s backup system', '', '', 'https://userspice.com/backup-system/		', ''),
(112, 'Form manager basics', 'external', '', 'Understanding the form manager plugin', '', '', 'https://userspice.com/using-the-form-manager/', ''),
(113, 'Form manager advanced features', 'external', '', 'Advanced form processing', '', '', 'https://userspice.com/advanced-form-processing/					', ''),
(114, 'Language and Translation', 'external', '', 'Learn how to translate UserSpice and edit translations', '', '', 'https://userspice.com/language-and-translation/					', ''),
(115, 'Social Logins', 'external', '', 'Setup google and facebook logins (now plugins)', '', '', 'https://userspice.com/social-logins/		', ''),
(116, 'Security Audit - 4.4', 'external', '', 'A 3rd party audited v 4.4.09', '', '', 'https://userspice.com/latest-security-audit/', ''),
(117, 'Using the database', 'external', '', 'Learn how to use the database with video and text tutorials', '', '', 'https://userspice.com/using-the-database/		', ''),
(118, 'Writing a plugin', '', '', 'See an example of how to write your own plugin', '', '', 'https://userspice.com/writing-a-basic-plugin/	', ''),
(119, 'Plugin hooks', 'external', '', 'Learn how to use your plugins to inject code into existing UserSpice pages', '', '', 'https://userspice.com/plugin-hooks/		', '');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `id` int(11) NOT NULL,
  `website_name` varchar(100) NOT NULL,
  `smtp_server` varchar(100) NOT NULL,
  `smtp_port` int(10) NOT NULL,
  `email_login` varchar(150) NOT NULL,
  `email_pass` varchar(100) NOT NULL,
  `from_name` varchar(100) NOT NULL,
  `from_email` varchar(150) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `verify_url` varchar(255) NOT NULL,
  `email_act` int(1) NOT NULL,
  `debug_level` int(1) NOT NULL DEFAULT '0',
  `isSMTP` int(1) NOT NULL DEFAULT '0',
  `isHTML` varchar(5) NOT NULL DEFAULT 'true',
  `useSMTPauth` varchar(6) NOT NULL DEFAULT 'true'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `website_name`, `smtp_server`, `smtp_port`, `email_login`, `email_pass`, `from_name`, `from_email`, `transport`, `verify_url`, `email_act`, `debug_level`, `isSMTP`, `isHTML`, `useSMTPauth`) VALUES
(1, 'User Spice', 'smtp.gmail.com', 587, 'iknowimcorny@gmail.com', '1reprobate', 'User Spice', 'iknowimcorny@gmail.com', 'tls', 'http://localhost/43', 0, 2, 0, 'true', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `groups_menus`
--

CREATE TABLE `groups_menus` (
  `id` int(11) UNSIGNED NOT NULL,
  `group_id` int(11) UNSIGNED NOT NULL,
  `menu_id` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups_menus`
--

INSERT INTO `groups_menus` (`id`, `group_id`, `menu_id`) VALUES
(30, 2, 9),
(29, 0, 8),
(28, 0, 7),
(27, 0, 21),
(5, 0, 3),
(6, 0, 1),
(7, 0, 2),
(8, 0, 51),
(9, 0, 52),
(10, 0, 37),
(11, 0, 38),
(12, 2, 39),
(13, 2, 40),
(14, 2, 41),
(15, 2, 42),
(16, 2, 43),
(17, 2, 44),
(18, 2, 45),
(19, 0, 46),
(20, 0, 47),
(21, 0, 49),
(26, 0, 20),
(25, 0, 18),
(31, 2, 10),
(32, 2, 11),
(33, 2, 12),
(34, 2, 13),
(35, 2, 14),
(36, 2, 15),
(37, 0, 16);

-- --------------------------------------------------------

--
-- Table structure for table `keys`
--

CREATE TABLE `keys` (
  `id` int(11) NOT NULL,
  `stripe_ts` varchar(255) NOT NULL,
  `stripe_tp` varchar(255) NOT NULL,
  `stripe_ls` varchar(255) NOT NULL,
  `stripe_lp` varchar(255) NOT NULL,
  `recap_pub` varchar(100) NOT NULL,
  `recap_pri` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(3) NOT NULL,
  `logdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logtype` varchar(25) NOT NULL,
  `lognote` text NOT NULL,
  `ip` varchar(75) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `logdate`, `logtype`, `lognote`, `ip`) VALUES
(1, 1, '2019-04-28 21:09:59', 'System Updates', 'Inserted ip to logs table', '::1'),
(2, 1, '2019-04-28 21:09:59', 'System Updates', 'Update 2ZB9mg1l0JXe successfully deployed.', '::1'),
(3, 1, '2019-04-28 21:09:59', 'System Updates', 'Update B9t6He7qmFXa successfully deployed.', '::1'),
(4, 1, '2019-04-28 21:09:59', 'System Updates', 'Updated group_menu int columns to 11 and unsigned', '::1'),
(5, 1, '2019-04-28 21:09:59', 'System Updates', 'Updated users int columns to 11 and unsigned', '::1'),
(6, 1, '2019-04-28 21:09:59', 'System Updates', 'Update 86FkFVV4TGRg successfully deployed.', '::1'),
(7, 1, '2019-04-28 21:09:59', 'System Updates', 'Added default language to settings table', '::1'),
(8, 1, '2019-04-28 21:09:59', 'System Updates', 'Added default language to settings table', '::1'),
(9, 1, '2019-04-28 21:09:59', 'System Updates', 'Added language info to settings table', '::1'),
(10, 1, '2019-04-28 21:09:59', 'System Updates', 'Added default language to settings table', '::1'),
(11, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(12, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(13, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(14, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(15, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(16, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(17, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(18, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(19, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(20, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(21, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(22, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(23, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(24, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(25, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(26, 1, '2019-04-28 21:09:59', 'System Updates', 'Update y4A1Y0u9n2Rt successfully deployed.', '::1'),
(27, 1, '2019-04-28 21:09:59', 'System Updates', 'Modified menus for multilanguage', '::1'),
(28, 1, '2019-04-28 21:09:59', 'System Updates', 'Update Tm5xY22MM8eC successfully deployed.', '::1'),
(29, 1, '2019-04-28 21:09:59', 'System Updates', 'Update 0YXdrInkjV86F successfully deployed.', '::1'),
(30, 1, '2019-04-28 21:09:59', 'System Updates', 'Added us_plugin_hooks table', '::1'),
(31, 1, '2019-04-28 21:09:59', 'System Updates', 'Update 99plgnkjV86 successfully deployed.', '::1'),
(32, 1, '2019-04-28 21:09:59', 'System Updates', 'Update 0DaShInkjV86 successfully deployed.', '::1'),
(33, 1, '2019-04-29 00:13:44', 'Email Settings', 'Updated email_login.', '::1'),
(34, 1, '2019-04-29 00:13:44', 'Email Settings', 'Updated email_pass.', '::1'),
(35, 1, '2019-04-29 00:13:44', 'Email Settings', 'Updated from_email from yourEmail@gmail.com to iknowimcorny@gmail.com.', '::1'),
(36, 1, '2019-04-29 00:13:44', 'Email Settings', 'Updated email_act from 0 to 4.', '::1'),
(37, 1, '2019-04-29 00:14:25', 'Email Settings', 'Updated email_pass.', '::1'),
(38, 1, '2019-04-29 00:20:29', 'Email Settings', 'Updated email_pass.', '::1'),
(39, 1, '2019-04-29 00:20:52', 'Email Settings', 'Updated email_act from 4 to 2.', '::1'),
(40, 1, '2019-04-29 00:27:25', 'User Manager', 'Updated email for The from userspicephp@gmail.com to mudmin@gmail.com.', '::1'),
(41, 1, '2019-04-29 00:27:43', 'User', 'Requested password reset.', '::1'),
(42, 1, '2019-04-29 00:31:43', 'User', 'User logged in.', NULL),
(43, 1, '2019-04-29 00:32:15', 'User Manager', 'Updated email for The from mudmin@gmail.com to admin@userspice.com.', '::1'),
(44, 1, '2019-04-29 00:32:30', 'User Manager', 'Updated password for Sample.', '::1'),
(45, 1, '2019-04-29 00:32:32', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(46, 1, '2019-04-29 00:32:51', 'User Manager', 'Updated email for Sample from noreply@userspice.com to mudmin@gmail.com.', '::1'),
(47, 1, '2019-04-29 00:33:01', 'User Manager', 'Updated password for Sample.', '::1'),
(48, 1, '2019-04-29 00:33:15', 'User Manager', 'Updated password for Sample.', '::1'),
(49, 1, '2019-04-29 00:33:18', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(50, 1, '2019-04-29 00:40:23', 'User Manager', 'Updated password for Sample.', '::1'),
(51, 1, '2019-04-29 00:40:26', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(52, 1, '2019-04-29 00:43:57', 'User Manager', 'Updated password for Sample.', '::1'),
(53, 1, '2019-04-29 00:44:09', 'User Manager', 'Updated password for Sample.', '::1'),
(54, 1, '2019-04-29 00:44:41', 'User Manager', 'Updated password for Sample.', '::1'),
(55, 1, '2019-04-29 00:45:09', 'User Manager', 'Updated password for Sample.', '::1'),
(56, 1, '2019-04-29 00:45:12', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(57, 1, '2019-04-29 00:49:36', 'User Manager', 'Updated password for Sample.', '::1'),
(58, 1, '2019-04-29 00:49:44', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(59, 1, '2019-04-29 00:50:34', 'User Manager', 'Updated password for Sample.', '::1'),
(60, 1, '2019-04-29 00:50:37', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(61, 1, '2019-04-29 00:53:39', 'User Manager', 'Updated password for Sample.', '::1'),
(62, 1, '2019-04-29 00:54:23', 'User Manager', 'Updated password for Sample.', '::1'),
(63, 1, '2019-04-29 15:31:54', 'User Manager', 'Updated password for Sample.', '::1'),
(64, 1, '2019-04-29 15:42:06', 'User Manager', 'Updated password for Sample.', '::1'),
(65, 1, '2019-04-29 15:42:08', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(66, 1, '2019-04-29 15:42:54', 'User Manager', 'Updated password for Sample.', '::1'),
(67, 1, '2019-04-29 15:42:56', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(68, 1, '2019-04-29 17:40:33', 'User Manager', 'Updated password for Sample.', '::1'),
(69, 1, '2019-04-29 17:40:36', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(70, 1, '2019-04-29 17:41:25', 'User Manager', 'Updated password for Sample.', '::1'),
(71, 1, '2019-04-29 17:41:27', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(72, 1, '2019-04-29 17:45:11', 'User Manager', 'Updated password for Sample.', '::1'),
(73, 1, '2019-04-29 17:45:13', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(74, 1, '2019-04-29 17:46:36', 'User Manager', 'Updated password for Sample.', '::1'),
(75, 1, '2019-04-29 17:46:38', 'User Manager', 'Sent password reset email to Sample, Vericode expires in 15 minutes.', '::1'),
(76, 1, '2019-04-30 19:27:37', 'User', 'User logged in.', NULL),
(77, 1, '2019-04-30 19:37:58', 'USPlugins', 'demo uninstalled', '::1'),
(78, 1, '2019-05-01 10:59:12', 'USPlugins', 'performancechecker installed', '::1'),
(79, 1, '2019-05-01 10:59:15', 'USPlugins', 'performancechecker Activated', '::1'),
(80, 1, '2019-07-17 14:48:22', 'System Updates', 'Update 0DaShInkjVz1 successfully deployed.', '::1'),
(81, 1, '2019-07-17 14:49:40', 'USPlugins', 'hasher uninstalled', '::1'),
(82, 1, '2019-07-17 14:49:43', 'USPlugins', 'performancechecker uninstalled', '::1'),
(83, 1, '2019-07-21 15:03:19', 'System Updates', 'Added column for spice shaker', '::1'),
(84, 1, '2019-07-21 15:03:19', 'System Updates', 'Update y4A1Y0u9n2SS successfully deployed.', '::1'),
(85, 1, '2019-07-21 15:03:42', 'USPlugins', 'mqtt installed', '::1'),
(86, 1, '2019-07-21 15:03:46', 'USPlugins-MQTT', 'Failed to reactivate Plugin, Error: ERROR #42S22: Unknown column \'server\' in \'field list\'', '::1'),
(87, 1, '2019-07-24 20:09:51', 'User', 'User logged in.', NULL),
(88, 1, '2019-07-24 20:10:33', 'USPlugins', 'mqtt uninstalled', '::1'),
(89, 1, '2019-07-24 20:28:09', 'USPlugins', 'performancechecker installed', '::1'),
(90, 1, '2019-07-24 20:28:13', 'USPlugins', 'performancechecker Activated', '::1'),
(91, 1, '2019-08-05 09:40:09', 'User', 'User logged in.', NULL),
(92, 1, '2019-08-05 09:40:16', 'System Updates', 'Update 0DaShInkjV87 successfully deployed.', '::1'),
(93, 1, '2019-08-05 09:40:16', 'System Updates', 'Update 0DaShInkjV88 successfully deployed.', '::1'),
(94, 1, '2019-08-05 09:40:21', 'Errors', 'Attempted to access disabled apibuilder', '::1'),
(95, 1, '2019-08-05 09:40:25', 'Errors', 'Attempted to access disabled apibuilder', '::1'),
(96, 1, '2019-08-05 10:06:36', 'Errors', 'Attempted to access disabled apibuilder', '::1'),
(97, 1, '2019-08-05 10:06:38', 'Errors', 'Attempted to access disabled apibuilder', '::1'),
(98, 1, '2019-08-05 10:06:41', 'USPlugins', 'apibuilder uninstalled', '::1'),
(99, 1, '2019-08-05 10:06:43', 'USPlugins', 'apibuilder installed', '::1'),
(100, 1, '2019-08-05 10:06:44', 'USPlugins', 'apibuilder Activated', '::1'),
(101, 1, '2019-08-05 10:37:01', 'USPlugins', 'apibuilder uninstalled', '::1'),
(102, 1, '2019-08-05 10:37:02', 'USPlugins', 'apibuilder installed', '::1'),
(103, 1, '2019-08-05 10:37:03', 'USPlugins', 'apibuilder Activated', '::1'),
(104, 1, '2019-08-05 10:39:06', 'USPlugins', 'apibuilder uninstalled', '::1'),
(105, 1, '2019-08-05 10:39:07', 'USPlugins', 'apibuilder installed', '::1'),
(106, 1, '2019-08-05 10:39:08', 'USPlugins', 'apibuilder Activated', '::1'),
(107, 1, '2019-08-05 10:59:24', 'USPlugins', 'apibuilder uninstalled', '::1'),
(108, 1, '2019-08-05 16:46:12', 'USPlugins', 'apibuilder installed', '::1'),
(109, 1, '2019-08-05 16:46:12', 'USPlugins', 'notifications installed', '::1'),
(110, 1, '2019-08-05 16:49:56', 'USPlugins', 'apibuilder Activated', '::1'),
(111, 1, '2019-08-05 18:20:17', 'USPlugins', 'apibuilder uninstalled', '::1'),
(112, 1, '2019-08-05 18:20:20', 'USPlugins', 'apibuilder installed', '::1'),
(113, 1, '2019-08-05 18:20:21', 'USPlugins', 'apibuilder Activated', '::1'),
(114, 1, '2019-08-05 18:20:41', 'USPlugins', 'apibuilder uninstalled', '::1'),
(115, 1, '2019-08-05 18:20:42', 'USPlugins', 'apibuilder installed', '::1'),
(116, 1, '2019-08-05 18:20:43', 'USPlugins', 'apibuilder Activated', '::1'),
(117, 1, '2019-08-05 18:22:08', 'USPlugins', 'apibuilder uninstalled', '::1'),
(118, 1, '2019-08-05 18:22:11', 'USPlugins', 'apibuilder installed', '::1'),
(119, 1, '2019-08-05 18:22:14', 'USPlugins', 'apibuilder Activated', '::1'),
(120, 2, '2019-08-05 18:39:00', 'API Test', 'Hello World from Video!', '::1'),
(121, 1, '2019-08-06 09:52:30', 'User', 'User logged in.', NULL),
(122, 1, '2019-08-06 10:18:36', 'USPlugins', 'comments installed', '::1'),
(123, 1, '2019-08-06 10:18:36', 'USPlugins', 'gdpr installed', '::1'),
(124, 1, '2019-08-06 12:05:52', 'User', 'User logged in.', NULL),
(125, 1, '2019-08-06 12:37:38', 'your_api_bugs', '604', '::1'),
(126, 1, '2019-08-06 13:49:19', 'User', 'User logged in.', NULL),
(127, 1, '2019-08-06 13:53:37', 'your_api_bugs', '605', '::1'),
(128, 1, '2019-08-06 14:10:42', 'User', 'User logged in.', NULL),
(129, 1, '2019-08-06 14:10:51', 'your_api_bugs', '606', '::1'),
(130, 1, '2019-08-07 12:35:29', 'your_api_bugs', '632', '::1'),
(131, 1, '2019-08-08 20:34:34', 'User', 'User logged in.', NULL),
(132, 1, '2019-08-08 20:51:12', 'User', 'User logged in.', NULL),
(133, 2, '2019-08-12 13:04:14', 'User', 'User logged in.', NULL),
(134, 1, '2019-08-12 13:06:18', 'User', 'User logged in.', NULL),
(135, 1, '2019-08-12 13:18:53', 'USPlugins', 'comments Activated', '::1'),
(136, 1, '2019-08-12 13:18:57', 'USPlugins', 'comments uninstalled', '::1'),
(137, 1, '2019-08-12 15:55:28', 'USPlugins', 'forms installed', '::1'),
(138, 1, '2019-08-12 15:55:33', 'USPlugins', 'forms Activated', '::1'),
(139, 1, '2019-08-12 15:55:39', 'USPlugins', 'forms uninstalled', '::1'),
(140, 1, '2019-08-12 16:12:16', 'USPlugins', 'forms installed', '::1'),
(141, 1, '2019-08-12 16:12:19', 'USPlugins', 'forms Activated', '::1'),
(142, 1, '2019-08-12 16:12:51', 'USPlugins', 'forms uninstalled', '::1'),
(143, 1, '2019-08-12 16:13:19', 'USPlugins', 'forms installed', '::1'),
(144, 1, '2019-08-12 16:13:20', 'USPlugins', 'forms Activated', '::1'),
(145, 1, '2019-08-12 16:13:24', 'USPlugins', 'forms uninstalled', '::1'),
(146, 1, '2019-08-12 16:17:54', 'USPlugins', 'forms installed', '::1'),
(147, 1, '2019-08-12 16:17:56', 'USPlugins', 'forms Activated', '::1'),
(148, 1, '2019-08-12 16:18:19', 'USPlugins', 'forms uninstalled', '::1'),
(149, 1, '2019-08-12 16:21:08', 'USPlugins', 'forms installed', '::1'),
(150, 1, '2019-08-12 16:21:12', 'USPlugins', 'forms Activated', '::1'),
(151, 1, '2019-08-12 16:21:36', 'USPlugins', 'forms uninstalled', '::1'),
(152, 1, '2019-08-12 16:21:58', 'USPlugins', 'forms uninstalled', '::1'),
(153, 1, '2019-08-12 16:22:33', 'USPlugins', 'forms uninstalled', '::1'),
(154, 1, '2019-08-12 16:22:59', 'USPlugins', 'forms uninstalled', '::1'),
(155, 1, '2019-08-12 16:23:24', 'USPlugins', 'forms installed', '::1'),
(156, 1, '2019-08-12 16:23:26', 'USPlugins', 'forms Activated', '::1'),
(157, 1, '2019-08-12 16:23:33', 'USPlugins', 'forms uninstalled', '::1'),
(158, 1, '2019-08-12 16:24:09', 'USPlugins', 'forms installed', '::1'),
(159, 1, '2019-08-12 16:24:11', 'USPlugins', 'forms Activated', '::1'),
(160, 1, '2019-08-12 16:29:04', 'USPlugins', 'forms uninstalled', '::1'),
(161, 1, '2019-08-12 16:29:06', 'USPlugins', 'forms installed', '::1'),
(162, 1, '2019-08-12 16:29:08', 'USPlugins', 'forms Activated', '::1'),
(163, 1, '2019-08-12 16:31:17', 'USPlugins', 'forms uninstalled', '::1'),
(164, 1, '2019-08-12 16:31:17', 'USPlugins', 'forms uninstalled', '::1'),
(165, 1, '2019-08-12 16:31:19', 'USPlugins', 'forms installed', '::1'),
(166, 1, '2019-08-12 16:31:20', 'USPlugins', 'forms Activated', '::1'),
(167, 1, '2019-08-12 16:39:03', 'USPlugins', 'forms uninstalled', '::1'),
(168, 1, '2019-08-12 16:39:05', 'USPlugins', 'forms installed', '::1'),
(169, 1, '2019-08-12 16:39:06', 'USPlugins', 'forms Activated', '::1'),
(170, 1, '2019-08-12 16:41:41', 'USPlugins', 'forms uninstalled', '::1'),
(171, 1, '2019-08-12 16:41:42', 'USPlugins', 'forms installed', '::1'),
(172, 1, '2019-08-12 16:41:44', 'USPlugins', 'forms Activated', '::1'),
(173, 1, '2019-08-12 17:22:44', 'USPlugins', 'forms uninstalled', '::1'),
(174, 1, '2019-08-12 17:22:47', 'USPlugins', 'forms installed', '::1'),
(175, 1, '2019-08-12 17:22:48', 'USPlugins', 'forms Activated', '::1'),
(176, 1, '2019-08-12 17:23:23', 'USPlugins', 'forms uninstalled', '::1'),
(177, 1, '2019-08-12 17:23:43', 'USPlugins', 'forms installed', '::1'),
(178, 1, '2019-08-12 17:23:45', 'USPlugins', 'forms Activated', '::1'),
(179, 1, '2019-08-12 17:25:57', 'USPlugins', 'forms uninstalled', '::1'),
(180, 1, '2019-08-12 17:25:59', 'USPlugins', 'forms installed', '::1'),
(181, 1, '2019-08-12 17:26:01', 'USPlugins', 'forms Activated', '::1'),
(182, 1, '2019-08-12 17:44:21', 'USPlugins', 'forms uninstalled', '::1'),
(183, 1, '2019-08-13 13:40:56', 'User', 'User logged in.', NULL),
(184, 1, '2019-08-13 13:41:16', 'USPlugins', 'apibuilder Activated', '::1'),
(185, 1, '2019-08-13 13:53:11', 'USPlugins', 'apibuilder Activated', '::1'),
(186, 1, '2019-08-13 13:53:14', 'USPlugins', 'apibuilder uninstalled', '::1'),
(187, 1, '2019-08-13 13:56:59', 'USPlugins', 'apibuilder installed', '::1'),
(188, 1, '2019-08-13 13:57:04', 'USPlugins', 'apibuilder Activated', '::1'),
(189, 1, '2019-08-13 14:00:56', 'USPlugins', 'apibuilder Activated', '::1'),
(190, 3, '2019-08-13 14:41:39', 'User', 'Registration completed via API.', '::1'),
(191, 4, '2019-08-13 14:43:28', 'User', 'Registration completed via API.', '::1'),
(192, 5, '2019-08-13 14:44:44', 'User', 'Registration completed via API.', '::1'),
(193, 5, '2019-08-13 14:45:12', 'User', 'User logged in.', NULL),
(194, 1, '2019-08-13 14:45:50', 'User', 'User logged in.', NULL),
(195, 6, '2019-08-13 15:05:27', 'User', 'Registration completed via API.', '::1'),
(196, 1, '2019-08-16 11:14:30', 'User', 'User logged in.', NULL),
(197, 1, '2019-08-16 16:27:27', 'User', 'User logged in.', NULL),
(198, 1, '2019-08-16 16:27:58', 'your_api_bugs', '660', '::1'),
(199, 1, '2019-08-19 08:57:05', 'User', 'User logged in.', NULL),
(200, 1, '2019-08-19 09:09:53', 'User', 'User logged in.', NULL),
(201, 1, '2019-08-22 11:05:51', 'User', 'User logged in.', NULL),
(202, 1, '2019-08-22 12:58:44', 'User', 'User logged in.', NULL),
(203, 1, '2019-08-22 13:03:12', 'User', 'User logged in.', NULL),
(204, 1, '2019-08-23 16:43:26', 'USPlugins', 'gdpr Activated', '::1'),
(205, 1, '2019-08-23 17:43:09', 'User', 'User logged in.', NULL),
(206, 1, '2019-08-23 17:46:33', 'USPlugins', 'forms installed', '::1'),
(207, 1, '2019-08-23 17:54:44', 'USPlugins', 'forms Activated', '::1'),
(208, 1, '2019-08-23 18:44:25', 'USPlugins', 'hasher installed', '::1'),
(209, 1, '2019-08-23 18:44:30', 'USPlugins', 'hasher Activated', '::1'),
(210, 1, '2019-08-26 13:23:43', 'User', 'User logged in.', NULL),
(211, 1, '2019-08-26 13:26:39', 'User', 'User logged in.', NULL),
(212, 1, '2019-08-26 14:00:13', 'USPlugins', 'hasher Activated', '::1'),
(213, 1, '2019-08-26 14:49:08', 'USPlugins', 'comments installed', '::1'),
(214, 1, '2019-08-26 14:49:08', 'USPlugins', 'dbman installed', '::1'),
(215, 1, '2019-08-26 14:49:08', 'USPlugins', 'demo installed', '::1'),
(216, 1, '2019-08-26 14:49:08', 'USPlugins', 'facebook_login installed', '::1'),
(217, 1, '2019-08-26 14:49:08', 'USPlugins', 'fileman installed', '::1'),
(218, 1, '2019-08-26 14:49:08', 'USPlugins', 'formbuilder installed', '::1'),
(219, 1, '2019-08-26 14:49:08', 'USPlugins', 'google_login installed', '::1'),
(220, 1, '2019-08-26 14:49:08', 'USPlugins', 'langcheck installed', '::1'),
(221, 1, '2019-08-26 14:49:08', 'USPlugins', 'ldap_login installed', '::1'),
(222, 1, '2019-08-26 14:49:09', 'USPlugins', 'localhostlogin installed', '::1'),
(223, 1, '2019-08-26 14:49:09', 'USPlugins', 'meekro installed', '::1'),
(224, 1, '2019-08-26 14:49:09', 'USPlugins', 'messages installed', '::1'),
(225, 1, '2019-08-26 14:49:09', 'USPlugins', 'mqtt installed', '::1'),
(226, 1, '2019-08-26 14:49:09', 'USPlugins', 'steam_login installed', '::1'),
(227, 1, '2019-08-26 14:49:09', 'USPlugins', 'stripe installed.', '::1'),
(228, 1, '2019-08-26 14:49:09', 'USPlugins', 'sysinfo installed', '::1'),
(229, 1, '2019-08-26 14:49:13', 'USPlugins', 'hasher uninstalled', '::1'),
(230, 1, '2019-08-26 15:59:13', 'USPlugins', 'hasher installed', '::1'),
(231, 1, '2019-08-26 15:59:14', 'USPlugins', 'hasher Activated', '::1'),
(232, 1, '2019-08-26 16:01:14', 'USPlugins', 'hasher uninstalled', '::1'),
(233, 1, '2019-08-26 16:02:16', 'USPlugins', 'forms Activated', '::1'),
(234, 1, '2019-08-26 16:02:20', 'USPlugins', 'forms uninstalled', '::1'),
(235, 1, '2019-08-26 16:11:07', 'USPlugins', 'demo Activated', '::1'),
(236, 1, '2019-08-27 08:31:43', 'Pages Manager', 'Added 1 permission(s) to usersc/templates/standard/preview.php.', '::1'),
(237, 1, '2019-08-27 08:31:43', 'Pages Manager', 'Retitled \'usersc/templates/standard/preview.php\' to \'Preview Template\'.', '::1'),
(238, 1, '2019-09-03 20:33:23', 'User', 'User logged in.', NULL),
(239, 1, '2019-09-03 20:35:02', 'User', 'User logged in.', NULL),
(240, 1, '2019-09-04 09:54:01', 'User', 'User logged in.', NULL),
(241, 1, '2019-09-04 10:14:16', 'USPlugins', 'demo uninstalled', '::1'),
(242, 1, '2019-09-04 10:50:41', 'System Updates', 'Inserted announcements checker to settings table', '::1'),
(243, 1, '2019-09-04 10:50:41', 'System Updates', 'Update 2019-09-04a successfully deployed.', '::1'),
(244, 1, '2019-09-04 10:59:51', 'System Updates', 'Unable to insert announcements checker to settings table, Error: ERROR #42S21: Duplicate column name \'announce\'', '::1'),
(245, 1, '2019-09-04 10:59:51', 'System Updates', 'Update 2019-09-04a unable to be marked complete', '::1'),
(246, 1, '2019-09-04 11:00:12', 'System Updates', 'Unable to insert announcements checker to settings table, Error: ERROR #42S21: Duplicate column name \'announce\'', '::1'),
(247, 1, '2019-09-04 11:00:12', 'System Updates', 'Update 2019-09-04a unable to be marked complete', '::1'),
(248, 1, '2019-09-04 11:00:44', 'System Updates', 'Inserted announcements checker to settings table', '::1'),
(249, 1, '2019-09-04 11:00:44', 'System Updates', 'Update 2019-09-04a successfully deployed.', '::1'),
(250, 1, '2019-09-05 08:38:02', 'User', 'User logged in.', NULL),
(251, 1, '2019-09-05 08:49:38', 'USPlugins', 'membership installed', '::1'),
(252, 1, '2019-09-05 08:50:35', 'USPlugins', 'membership Activated', '::1'),
(253, 1, '2019-09-05 08:55:13', 'USPlugins', 'membership uninstalled', '::1'),
(254, 1, '2019-09-05 08:55:14', 'USPlugins', 'membership installed', '::1'),
(255, 1, '2019-09-05 08:55:15', 'USPlugins', 'membership Activated', '::1'),
(256, 1, '2019-09-05 12:44:33', 'System Updates', 'Changed template to Standard', '::1'),
(257, 1, '2019-09-05 12:44:33', 'System Updates', 'Update 2019-09-05a successfully deployed.', '::1'),
(258, 1, '2019-09-06 18:50:00', 'User', 'User logged in.', NULL),
(259, 1, '2019-09-25 09:23:27', 'User', 'User logged in.', '::1'),
(260, 1, '2019-09-25 10:25:58', 'User', 'User logged in.', '::1'),
(261, 1, '2019-09-25 10:52:11', 'User', 'User logged in.', '::1'),
(262, 7, '2019-09-25 10:53:27', 'User', 'Registration completed.', '::1'),
(263, 1, '2019-09-25 12:46:50', 'User', 'User logged in.', '::1'),
(264, 1, '2019-09-25 12:47:44', 'User', 'User logged in.', '::1'),
(265, 1, '2019-09-25 13:18:54', 'User', 'User logged in.', '::1'),
(266, 8, '2019-09-25 13:30:38', 'User', 'Registration completed.', '::1'),
(267, 9, '2019-09-25 13:32:11', 'User', 'Registration completed.', '::1'),
(268, 10, '2019-09-25 13:32:57', 'User', 'Registration completed.', '::1'),
(269, 10, '2019-09-25 13:33:04', 'User', 'User logged in.', '::1'),
(270, 1, '2019-09-25 13:50:19', 'User', 'User logged in.', '::1'),
(271, 1, '2019-09-25 13:54:33', 'User', 'User logged in.', '::1'),
(272, 1, '2019-09-25 13:55:29', 'User', 'User logged in.', '::1'),
(273, 1, '2019-09-25 23:58:00', 'User', 'User logged in.', '::1'),
(274, 1, '2019-09-26 11:02:12', 'User', 'User logged in.', '::1'),
(275, 1, '2019-09-26 12:10:44', '5.0.5', 'Creating zip file', '::1'),
(276, 1, '2019-09-26 12:10:44', '5.0.5', 'Attempting download', '::1'),
(277, 1, '2019-09-26 12:10:44', '5.0.5', 'Opening zip file and checking hash', '::1'),
(278, 1, '2019-09-26 12:10:44', '5.0.5', 'Hash Matches', '::1'),
(279, 1, '2019-09-26 12:10:44', '5.0.5', 'Extracting zip file', '::1'),
(280, 1, '2019-09-26 12:10:44', '5.0.5', 'You have updated to 5.0.5', '::1'),
(281, 1, '2019-09-26 12:10:44', '5.0.5', 'Running migration script(s)', '::1'),
(282, 1, '2019-09-26 12:10:45', '5.0.6', 'Creating zip file', '::1'),
(283, 1, '2019-09-26 12:10:45', '5.0.6', 'Attempting download', '::1'),
(284, 1, '2019-09-26 12:10:45', '5.0.6', 'Opening zip file and checking hash', '::1'),
(285, 1, '2019-09-26 12:10:45', '5.0.6', 'Hash Matches', '::1'),
(286, 1, '2019-09-26 12:10:45', '5.0.6', 'Extracting zip file', '::1'),
(287, 1, '2019-09-26 12:10:45', '5.0.6', 'You have updated to 5.0.6', '::1'),
(288, 1, '2019-09-26 12:10:45', '5.0.6', 'Running migration script(s)', '::1'),
(289, 1, '2019-09-26 12:10:46', '5.0.7', 'Creating zip file', '::1'),
(290, 1, '2019-09-26 12:10:46', '5.0.7', 'Attempting download', '::1'),
(291, 1, '2019-09-26 12:10:46', '5.0.7', 'Opening zip file and checking hash', '::1'),
(292, 1, '2019-09-26 12:10:46', '5.0.7', 'Hash Matches', '::1'),
(293, 1, '2019-09-26 12:10:46', '5.0.7', 'Extracting zip file', '::1'),
(294, 1, '2019-09-26 12:10:46', '5.0.7', 'You have updated to 5.0.7', '::1'),
(295, 1, '2019-09-26 12:10:46', '5.0.7', 'Deleting zip file', '::1'),
(296, 1, '2019-09-26 12:12:38', '5.0.5', 'Creating zip file', '::1'),
(297, 1, '2019-09-26 12:12:38', '5.0.5', 'Attempting download', '::1'),
(298, 1, '2019-09-26 12:12:38', '5.0.5', 'Opening zip file and checking hash', '::1'),
(299, 1, '2019-09-26 12:12:38', '5.0.5', 'Hash Matches', '::1'),
(300, 1, '2019-09-26 12:12:38', '5.0.5', 'Extracting zip file', '::1'),
(301, 1, '2019-09-26 12:12:38', '5.0.5', 'You have updated to 5.0.5', '::1'),
(302, 1, '2019-09-26 12:12:38', '5.0.5', 'Running migration script(s)', '::1'),
(303, 1, '2019-09-26 12:12:39', '5.0.6', 'Creating zip file', '::1'),
(304, 1, '2019-09-26 12:12:39', '5.0.6', 'Attempting download', '::1'),
(305, 1, '2019-09-26 12:12:39', '5.0.6', 'Opening zip file and checking hash', '::1'),
(306, 1, '2019-09-26 12:12:39', '5.0.6', 'Hash Matches', '::1'),
(307, 1, '2019-09-26 12:12:39', '5.0.6', 'Extracting zip file', '::1'),
(308, 1, '2019-09-26 12:12:39', '5.0.6', 'You have updated to 5.0.6', '::1'),
(309, 1, '2019-09-26 12:12:39', '5.0.6', 'Running migration script(s)', '::1'),
(310, 1, '2019-09-26 12:12:40', '5.0.7', 'Creating zip file', '::1'),
(311, 1, '2019-09-26 12:12:40', '5.0.7', 'Attempting download', '::1'),
(312, 1, '2019-09-26 12:12:40', '5.0.7', 'Opening zip file and checking hash', '::1'),
(313, 1, '2019-09-26 12:12:40', '5.0.7', 'Hash Matches', '::1'),
(314, 1, '2019-09-26 12:12:40', '5.0.7', 'Extracting zip file', '::1'),
(315, 1, '2019-09-26 12:12:40', '5.0.7', 'You have updated to 5.0.7', '::1'),
(316, 1, '2019-09-26 12:12:40', '5.0.7', 'Running migration script(s)', '::1'),
(317, 1, '2019-09-26 12:21:39', '5.0.5', 'Creating zip file', '::1'),
(318, 1, '2019-09-26 12:21:39', '5.0.5', 'Attempting download', '::1'),
(319, 1, '2019-09-26 12:21:39', '5.0.5', 'Opening zip file and checking hash', '::1'),
(320, 1, '2019-09-26 12:21:39', '5.0.5', 'Hash Matches', '::1'),
(321, 1, '2019-09-26 12:21:39', '5.0.5', 'Extracting zip file', '::1'),
(322, 1, '2019-09-26 12:21:39', '5.0.5', 'You have updated to 5.0.5', '::1'),
(323, 1, '2019-09-26 12:21:39', '5.0.5', 'Running migration script(s)', '::1'),
(324, 1, '2019-09-26 12:21:40', '5.0.6', 'Creating zip file', '::1'),
(325, 1, '2019-09-26 12:21:40', '5.0.6', 'Attempting download', '::1'),
(326, 1, '2019-09-26 12:21:40', '5.0.6', 'Opening zip file and checking hash', '::1'),
(327, 1, '2019-09-26 12:21:40', '5.0.6', 'Hash Matches', '::1'),
(328, 1, '2019-09-26 12:21:40', '5.0.6', 'Extracting zip file', '::1'),
(329, 1, '2019-09-26 12:21:40', '5.0.6', 'You have updated to 5.0.6', '::1'),
(330, 1, '2019-09-26 12:21:40', '5.0.6', 'Running migration script(s)', '::1'),
(331, 1, '2019-09-26 12:21:40', '5.0.7', 'Creating zip file', '::1'),
(332, 1, '2019-09-26 12:21:40', '5.0.7', 'Attempting download', '::1'),
(333, 1, '2019-09-26 12:21:40', '5.0.7', 'Opening zip file and checking hash', '::1'),
(334, 1, '2019-09-26 12:21:40', '5.0.7', 'Hash Matches', '::1'),
(335, 1, '2019-09-26 12:21:40', '5.0.7', 'Extracting zip file', '::1'),
(336, 1, '2019-09-26 12:21:40', '5.0.7', 'You have updated to 5.0.7', '::1'),
(337, 1, '2019-09-26 12:21:40', '5.0.7', 'Running migration script(s)', '::1'),
(338, 1, '2019-09-26 12:22:51', '5.0.5', 'Creating zip file', '::1'),
(339, 1, '2019-09-26 12:22:51', '5.0.5', 'Attempting download', '::1'),
(340, 1, '2019-09-26 12:22:51', '5.0.5', 'Opening zip file and checking hash', '::1'),
(341, 1, '2019-09-26 12:22:51', '5.0.5', 'Hash Matches', '::1'),
(342, 1, '2019-09-26 12:22:51', '5.0.5', 'Extracting zip file', '::1'),
(343, 1, '2019-09-26 12:22:51', '5.0.5', 'You have updated to 5.0.5', '::1'),
(344, 1, '2019-09-26 12:22:51', '5.0.5', 'Running migration script(s)', '::1'),
(345, 1, '2019-09-26 12:29:40', 'System Updates', 'Added Bleeding Edge channel to get updates first', '::1'),
(346, 1, '2019-09-26 12:29:40', 'System Updates', 'Update 2019-09-26a successfully deployed.', '::1'),
(347, 1, '2019-09-26 12:33:22', '5.0.5', 'Creating zip file', '::1'),
(348, 1, '2019-09-26 12:33:22', '5.0.5', 'Attempting download', '::1'),
(349, 1, '2019-09-26 12:33:22', '5.0.5', 'Opening zip file and checking hash', '::1'),
(350, 1, '2019-09-26 12:33:22', '5.0.5', 'Hash Matches', '::1'),
(351, 1, '2019-09-26 12:33:22', '5.0.5', 'Extracting zip file', '::1'),
(352, 1, '2019-09-26 12:33:22', '5.0.5', 'You have updated to 5.0.5', '::1'),
(353, 1, '2019-09-26 12:33:22', '5.0.5', 'Running migration script(s)', '::1'),
(354, 1, '2019-09-26 12:33:40', '5.0.6', 'Creating zip file', '::1'),
(355, 1, '2019-09-26 12:33:40', '5.0.6', 'Attempting download', '::1'),
(356, 1, '2019-09-26 12:33:40', '5.0.6', 'Opening zip file and checking hash', '::1'),
(357, 1, '2019-09-26 12:33:40', '5.0.6', 'Hash Matches', '::1'),
(358, 1, '2019-09-26 12:33:40', '5.0.6', 'Extracting zip file', '::1'),
(359, 1, '2019-09-26 12:33:40', '5.0.6', 'You have updated to 5.0.6', '::1'),
(360, 1, '2019-09-26 12:33:40', '5.0.6', 'Running migration script(s)', '::1'),
(361, 1, '2019-09-26 12:34:30', '5.0.7', 'Creating zip file', '::1'),
(362, 1, '2019-09-26 12:34:30', '5.0.7', 'Attempting download', '::1'),
(363, 1, '2019-09-26 12:34:30', '5.0.7', 'Opening zip file and checking hash', '::1'),
(364, 1, '2019-09-26 12:34:30', '5.0.7', 'Hash Matches', '::1'),
(365, 1, '2019-09-26 12:34:30', '5.0.7', 'Extracting zip file', '::1'),
(366, 1, '2019-09-26 12:34:30', '5.0.7', 'You have updated to 5.0.7', '::1'),
(367, 1, '2019-09-26 12:34:30', '5.0.7', 'Running migration script(s)', '::1'),
(368, 1, '2019-09-26 16:38:30', 'User', 'User logged in.', '::1'),
(369, 1, '2019-09-26 17:03:13', '5.0.5', 'Creating zip file', '::1'),
(370, 1, '2019-09-26 17:03:13', '5.0.5', 'Attempting download', '::1'),
(371, 1, '2019-09-26 17:03:13', '5.0.5', 'Unable to open the Zip File', '::1'),
(372, 1, '2019-09-26 17:03:13', '5.0.5', 'Opening zip file and checking hash', '::1'),
(373, 1, '2019-09-26 17:03:13', '5.0.5', 'Hash match failed', '::1'),
(374, 1, '2019-09-26 17:03:13', '5.0.5', 'Deleting zip file', '::1'),
(375, 1, '2019-09-26 17:04:19', '5.0.5', 'Creating zip file', '::1'),
(376, 1, '2019-09-26 17:04:19', '5.0.5', 'Attempting download', '::1'),
(377, 1, '2019-09-26 17:04:20', '5.0.5', 'Opening zip file and checking hash', '::1'),
(378, 1, '2019-09-26 17:04:20', '5.0.5', 'Hash Matches', '::1'),
(379, 1, '2019-09-26 17:04:20', '5.0.5', 'Extracting zip file', '::1'),
(380, 1, '2019-09-26 17:04:20', '5.0.5', 'You have updated to 5.0.5', '::1'),
(381, 1, '2019-09-26 17:04:20', '5.0.5', 'Running migration script(s)', '::1'),
(382, 1, '2019-09-26 17:04:20', '5.0.6', 'Creating zip file', '::1'),
(383, 1, '2019-09-26 17:04:20', '5.0.6', 'Attempting download', '::1'),
(384, 1, '2019-09-26 17:04:21', '5.0.6', 'Opening zip file and checking hash', '::1'),
(385, 1, '2019-09-26 17:04:21', '5.0.6', 'Hash Matches', '::1'),
(386, 1, '2019-09-26 17:04:21', '5.0.6', 'Extracting zip file', '::1'),
(387, 1, '2019-09-26 17:04:21', '5.0.6', 'You have updated to 5.0.6', '::1'),
(388, 1, '2019-09-26 17:04:21', '5.0.6', 'Running migration script(s)', '::1'),
(389, 1, '2019-09-26 17:07:04', '5.0.5', 'Creating zip file', '::1'),
(390, 1, '2019-09-26 17:07:04', '5.0.5', 'Attempting download', '::1'),
(391, 1, '2019-09-26 17:07:04', '5.0.5', 'Opening zip file and checking hash', '::1'),
(392, 1, '2019-09-26 17:07:04', '5.0.5', 'Hash Matches', '::1'),
(393, 1, '2019-09-26 17:07:04', '5.0.5', 'Extracting zip file', '::1'),
(394, 1, '2019-09-26 17:07:04', '5.0.5', 'You have updated to 5.0.5', '::1'),
(395, 1, '2019-09-26 17:07:04', '5.0.5', 'Running migration script(s)', '::1'),
(396, 1, '2019-09-26 17:19:17', '5.0.5', 'Creating zip file', '::1'),
(397, 1, '2019-09-26 17:19:17', '5.0.5', 'Attempting download', '::1'),
(398, 1, '2019-09-26 17:19:17', '5.0.5', 'Opening zip file and checking hash', '::1'),
(399, 1, '2019-09-26 17:19:17', '5.0.5', 'Hash Matches', '::1'),
(400, 1, '2019-09-26 17:19:17', '5.0.5', 'Extracting zip file', '::1'),
(401, 1, '2019-09-26 17:19:17', '5.0.5', 'You have updated to 5.0.5', '::1'),
(402, 1, '2019-09-26 17:19:17', '5.0.5', 'Running migration script(s)', '::1'),
(403, 1, '2019-09-26 17:19:51', '5.0.6', 'Creating zip file', '::1'),
(404, 1, '2019-09-26 17:19:51', '5.0.6', 'Attempting download', '::1'),
(405, 1, '2019-09-26 17:19:52', '5.0.6', 'Opening zip file and checking hash', '::1'),
(406, 1, '2019-09-26 17:19:52', '5.0.6', 'Hash Matches', '::1'),
(407, 1, '2019-09-26 17:19:52', '5.0.6', 'Extracting zip file', '::1'),
(408, 1, '2019-09-26 17:19:52', '5.0.6', 'You have updated to 5.0.6', '::1'),
(409, 1, '2019-09-26 17:19:52', '5.0.6', 'Running migration script(s)', '::1'),
(410, 1, '2019-09-28 10:43:41', 'User', 'User logged in.', '::1'),
(411, 1, '2019-09-28 10:43:56', 'Pages Manager', 'Added 1 permission(s) to usersc/plugins/documentation/files/docs.php.', '::1'),
(412, 1, '2019-09-28 10:44:53', 'Pages Manager', 'Added 1 permission(s) to usersc/plugins/documentation/files/index.php.', '::1'),
(413, 1, '2019-09-28 10:45:14', 'Pages Manager', 'Added 1 permission(s) to usersc/plugins/documentation/files/documentation_details.php.', '::1'),
(414, 1, '2019-09-28 10:45:48', 'USPlugins', 'documentation installed', '::1'),
(415, 1, '2019-09-28 10:45:51', 'USPlugins', 'documentation Activated', '::1'),
(416, 1, '2019-10-02 23:46:54', 'User', 'User logged in.', '::1'),
(417, 1, '2019-10-02 23:50:48', 'User', 'User logged in.', '::1'),
(418, 1, '2019-10-03 18:19:14', 'User', 'User logged in.', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `logs_exempt`
--

CREATE TABLE `logs_exempt` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `createdby` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) NOT NULL,
  `menu_title` varchar(255) NOT NULL,
  `parent` int(10) NOT NULL,
  `dropdown` int(1) NOT NULL,
  `logged_in` int(1) NOT NULL,
  `display_order` int(10) NOT NULL,
  `label` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `icon_class` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `menu_title`, `parent`, `dropdown`, `logged_in`, `display_order`, `label`, `link`, `icon_class`) VALUES
(1, 'main', 2, 0, 1, 1, '{{home}}', '', 'fa fa-fw fa-home'),
(2, 'main', -1, 1, 1, 14, '', '', 'fa fa-fw fa-cogs'),
(3, 'main', -1, 0, 1, 11, '{{username}}', 'users/account.php', 'fa fa-fw fa-user'),
(4, 'main', -1, 1, 0, 3, '{{help}}', '', 'fa fa-fw fa-life-ring'),
(5, 'main', -1, 0, 0, 2, '{{register}}', 'users/join.php', 'fa fa-fw fa-plus-square'),
(6, 'main', -1, 0, 0, 1, '{{login}}', 'users/login.php', 'fa fa-fw fa-sign-in'),
(7, 'main', 2, 0, 1, 2, '{{account}}', 'users/account.php', 'fa fa-fw fa-user'),
(8, 'main', 2, 0, 1, 3, '{{hr}}', '', ''),
(9, 'main', 2, 0, 1, 4, '{{dashboard}}', 'users/admin.php', 'fa fa-fw fa-cogs'),
(10, 'main', 2, 0, 1, 5, '{{users}}', 'users/admin.php?view=users', 'fa fa-fw fa-user'),
(11, 'main', 2, 0, 1, 6, '{{perms}}', 'users/admin.php?view=permissions', 'fa fa-fw fa-lock'),
(12, 'main', 2, 0, 1, 7, '{{pages}}', 'users/admin.php?view=pages', 'fa fa-fw fa-wrench'),
(13, 'main', 2, 0, 1, 8, '{{messages}}', 'users/admin.php?view=messages', 'fa fa-fw fa-envelope'),
(14, 'main', 2, 0, 1, 9, '{{logs}}', 'users/admin.php?view=logs', 'fa fa-fw fa-search'),
(15, 'main', 2, 0, 1, 10, '{{hr}}', '', ''),
(16, 'main', 2, 0, 1, 11, '{{logout}}', 'users/logout.php', 'fa fa-fw fa-sign-out'),
(17, 'main', -1, 0, 0, 0, '{{home}}', '', 'fa fa-fw fa-home'),
(18, 'main', -1, 0, 1, 10, '{{home}}', '', 'fa fa-fw fa-home'),
(19, 'main', 4, 0, 0, 1, '{{forgot}}', 'users/forgot_password.php', 'fa fa-fw fa-wrench'),
(21, 'main', -1, 0, 1, 13, '{{messages}}', '', ''),
(22, 'main', 4, 0, 0, 99999, '{{resend}}', 'users/verify_resend.php', 'fa fa-exclamation-triangle');

-- --------------------------------------------------------

--
-- Table structure for table `menus_form`
--

CREATE TABLE `menus_form` (
  `id` int(11) NOT NULL,
  `ord` int(11) NOT NULL,
  `col` varchar(255) NOT NULL,
  `form_descrip` varchar(255) NOT NULL,
  `table_descrip` varchar(255) NOT NULL,
  `col_type` varchar(255) NOT NULL,
  `field_type` varchar(100) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `validation` text NOT NULL,
  `label_class` varchar(255) NOT NULL,
  `field_class` varchar(255) NOT NULL,
  `input_html` text NOT NULL,
  `select_opts` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus_form`
--

INSERT INTO `menus_form` (`id`, `ord`, `col`, `form_descrip`, `table_descrip`, `col_type`, `field_type`, `required`, `validation`, `label_class`, `field_class`, `input_html`, `select_opts`) VALUES
(1, 10, 'menu_title', 'Menu_title', 'Menu_title', 'varchar', 'text', 0, '', '', 'form-control', '', ''),
(2, 20, 'parent', 'Parent', 'Parent', 'int', 'number', 0, '', '', 'form-control', '', ''),
(3, 30, 'dropdown', 'Dropdown', 'Dropdown', 'int', 'number', 0, '', '', 'form-control', '', ''),
(4, 40, 'logged_in', 'Logged_in', 'Logged_in', 'int', 'number', 0, '', '', 'form-control', '', ''),
(5, 50, 'display_order', 'Display_order', 'Display_order', 'int', 'number', 0, '', '', 'form-control', '', ''),
(6, 60, 'label', 'Label', 'Label', 'varchar', 'text', 0, '', '', 'form-control', '', ''),
(7, 70, 'link', 'Link', 'Link', 'varchar', 'text', 0, '', '', 'form-control', '', ''),
(8, 80, 'icon_class', 'Icon_class', 'Icon_class', 'varchar', 'text', 0, '', '', 'form-control', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `msg_from` int(11) NOT NULL,
  `msg_to` int(11) NOT NULL,
  `msg_body` text NOT NULL,
  `msg_read` int(1) NOT NULL,
  `msg_thread` int(11) NOT NULL,
  `deleted` int(1) NOT NULL,
  `sent_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `msg_from`, `msg_to`, `msg_body`, `msg_read`, `msg_thread`, `deleted`, `sent_on`) VALUES
(1, 1, 2, '&lt;p&gt;fgds&lt;/p&gt;', 0, 1, 0, '2017-08-06 00:13:47'),
(2, 1, 2, '&lt;p&gt;Did it work?&lt;/p&gt;', 0, 2, 0, '2017-09-09 15:10:09');

-- --------------------------------------------------------

--
-- Table structure for table `message_threads`
--

CREATE TABLE `message_threads` (
  `id` int(11) NOT NULL,
  `msg_to` int(11) NOT NULL,
  `msg_from` int(11) NOT NULL,
  `msg_subject` varchar(255) NOT NULL,
  `last_update` datetime NOT NULL,
  `last_update_by` int(11) NOT NULL,
  `archive_from` int(1) NOT NULL DEFAULT '0',
  `archive_to` int(1) NOT NULL DEFAULT '0',
  `hidden_from` int(1) NOT NULL DEFAULT '0',
  `hidden_to` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_threads`
--

INSERT INTO `message_threads` (`id`, `msg_to`, `msg_from`, `msg_subject`, `last_update`, `last_update_by`, `archive_from`, `archive_to`, `hidden_from`, `hidden_to`) VALUES
(1, 2, 1, 'Testiing123', '2017-08-06 00:13:47', 1, 0, 0, 0, 0),
(2, 2, 1, 'Testing Message Badge', '2017-09-09 15:10:09', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` mediumtext NOT NULL,
  `is_read` tinyint(4) NOT NULL,
  `is_archived` tinyint(1) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_read` datetime DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `class` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `page` varchar(100) NOT NULL,
  `title` varchar(50) NOT NULL,
  `private` int(11) NOT NULL DEFAULT '0',
  `re_auth` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `page`, `title`, `private`, `re_auth`) VALUES
(1, 'index.php', 'Home', 0, 0),
(2, 'z_us_root.php', '', 0, 0),
(3, 'users/account.php', 'Account Dashboard', 1, 0),
(4, 'users/admin.php', 'Admin Dashboard', 1, 0),
(14, 'users/forgot_password.php', 'Forgotten Password', 0, 0),
(15, 'users/forgot_password_reset.php', 'Reset Forgotten Password', 0, 0),
(16, 'users/index.php', 'Home', 0, 0),
(17, 'users/init.php', '', 0, 0),
(18, 'users/join.php', 'Join', 0, 0),
(19, 'users/joinThankYou.php', 'Join', 0, 0),
(20, 'users/login.php', 'Login', 0, 0),
(21, 'users/logout.php', 'Logout', 0, 0),
(24, 'users/user_settings.php', 'User Settings', 1, 0),
(25, 'users/verify.php', 'Account Verification', 0, 0),
(26, 'users/verify_resend.php', 'Account Verification', 0, 0),
(45, 'users/maintenance.php', 'Maintenance', 0, 0),
(68, 'users/update.php', 'Update Manager', 1, 0),
(90, 'users/user_agreement_acknowledge.php', '', 1, 0),
(91, 'users/admin_pin.php', '', 1, 0),
(92, 'users/views_admin_notifications.php', '', 1, 0),
(97, 'users/message.php', '', 1, 0),
(98, 'users/messages.php', '', 1, 0),
(99, 'usersc/plugins/documentation/files/docs.php', '', 1, 0),
(100, 'usersc/plugins/documentation/files/index.php', '', 1, 0),
(101, 'usersc/plugins/documentation/files/documentation_details.php', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `permission_page_matches`
--

CREATE TABLE `permission_page_matches` (
  `id` int(11) NOT NULL,
  `permission_id` int(15) NOT NULL,
  `page_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permission_page_matches`
--

INSERT INTO `permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(2, 2, 27),
(3, 1, 24),
(4, 1, 22),
(5, 2, 13),
(6, 2, 12),
(7, 1, 11),
(8, 2, 10),
(9, 2, 9),
(10, 2, 8),
(11, 2, 7),
(12, 2, 6),
(13, 2, 5),
(14, 2, 4),
(15, 1, 3),
(16, 2, 37),
(17, 2, 39),
(19, 2, 40),
(21, 2, 41),
(23, 2, 42),
(27, 1, 42),
(28, 1, 27),
(29, 1, 41),
(30, 1, 40),
(31, 2, 44),
(32, 2, 47),
(33, 2, 51),
(34, 2, 50),
(35, 2, 49),
(36, 2, 53),
(37, 2, 52),
(38, 2, 68),
(39, 2, 55),
(40, 2, 56),
(41, 2, 71),
(42, 2, 58),
(43, 2, 57),
(44, 2, 53),
(45, 2, 74),
(46, 2, 75),
(47, 1, 75),
(48, 1, 76),
(49, 2, 76),
(50, 1, 77),
(51, 2, 77),
(52, 2, 78),
(53, 2, 80),
(54, 1, 81),
(55, 1, 82),
(56, 1, 83),
(57, 2, 84),
(58, 2, 93),
(59, 2, 99),
(60, 2, 100),
(61, 2, 101),
(62, 2, 101),
(63, 3, 101),
(64, 4, 101),
(65, 5, 101);

-- --------------------------------------------------------

--
-- Table structure for table `plg_api_fails`
--

CREATE TABLE `plg_api_fails` (
  `id` int(11) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plg_api_pool`
--

CREATE TABLE `plg_api_pool` (
  `id` int(11) NOT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `descrip` varchar(255) DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT '0',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plg_api_pool`
--

INSERT INTO `plg_api_pool` (`id`, `api_key`, `ip`, `user_id`, `descrip`, `blocked`, `updated`) VALUES
(1, 'O7KWV-VXKF4-NU5D5-2C2D9-DFEF8', '127.0.0.1', 0, NULL, 0, '2019-08-13 14:47:13');

-- --------------------------------------------------------

--
-- Table structure for table `plg_api_settings`
--

CREATE TABLE `plg_api_settings` (
  `id` int(11) NOT NULL,
  `api_auth_type` tinyint(1) DEFAULT '1',
  `api_fails` int(11) DEFAULT '10',
  `force_ssl` tinyint(1) DEFAULT '0',
  `disabled` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plg_api_settings`
--

INSERT INTO `plg_api_settings` (`id`, `api_auth_type`, `api_fails`, `force_ssl`, `disabled`) VALUES
(1, 2, 10, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bio` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `bio`) VALUES
(1, 1, '&lt;h1&gt;This is the Admin&#039;s bio.&lt;/h1&gt;'),
(2, 2, 'This is your bio');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(50) NOT NULL,
  `recaptcha` int(1) NOT NULL DEFAULT '0',
  `force_ssl` int(1) NOT NULL,
  `css_sample` int(1) NOT NULL,
  `us_css1` varchar(255) NOT NULL,
  `us_css2` varchar(255) NOT NULL,
  `us_css3` varchar(255) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `language` varchar(255) NOT NULL,
  `track_guest` int(1) NOT NULL,
  `site_offline` int(1) NOT NULL,
  `force_pr` int(1) NOT NULL,
  `glogin` int(1) NOT NULL DEFAULT '0',
  `fblogin` int(1) NOT NULL,
  `gid` varchar(255) NOT NULL,
  `gsecret` varchar(255) NOT NULL,
  `gredirect` varchar(255) NOT NULL,
  `ghome` varchar(255) NOT NULL,
  `fbid` varchar(255) NOT NULL,
  `fbsecret` varchar(255) NOT NULL,
  `fbcallback` varchar(255) NOT NULL,
  `graph_ver` varchar(255) NOT NULL,
  `finalredir` varchar(255) NOT NULL,
  `req_cap` int(1) NOT NULL,
  `req_num` int(1) NOT NULL,
  `min_pw` int(2) NOT NULL,
  `max_pw` int(3) NOT NULL,
  `min_un` int(2) NOT NULL,
  `max_un` int(3) NOT NULL,
  `messaging` int(1) NOT NULL,
  `snooping` int(1) NOT NULL,
  `echouser` int(11) NOT NULL,
  `wys` int(1) NOT NULL,
  `change_un` int(1) NOT NULL,
  `backup_dest` varchar(255) NOT NULL,
  `backup_source` varchar(255) NOT NULL,
  `backup_table` varchar(255) NOT NULL,
  `msg_notification` int(1) NOT NULL,
  `permission_restriction` int(1) NOT NULL,
  `auto_assign_un` int(1) NOT NULL,
  `page_permission_restriction` int(1) NOT NULL,
  `msg_blocked_users` int(1) NOT NULL,
  `msg_default_to` int(1) NOT NULL,
  `notifications` int(1) NOT NULL,
  `notif_daylimit` int(3) NOT NULL,
  `recap_public` varchar(100) NOT NULL,
  `recap_private` varchar(100) NOT NULL,
  `page_default_private` int(1) NOT NULL,
  `navigation_type` tinyint(1) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  `custom_settings` int(1) NOT NULL,
  `system_announcement` varchar(255) NOT NULL,
  `twofa` int(1) DEFAULT '0',
  `force_notif` tinyint(1) DEFAULT NULL,
  `cron_ip` varchar(255) DEFAULT NULL,
  `registration` tinyint(1) DEFAULT NULL,
  `join_vericode_expiry` int(9) UNSIGNED NOT NULL,
  `reset_vericode_expiry` int(9) UNSIGNED NOT NULL,
  `admin_verify` tinyint(1) NOT NULL,
  `admin_verify_timeout` int(9) NOT NULL,
  `session_manager` tinyint(1) NOT NULL,
  `template` varchar(255) DEFAULT 'default',
  `saas` tinyint(1) DEFAULT NULL,
  `redirect_uri_after_login` text,
  `show_tos` tinyint(1) DEFAULT '1',
  `default_language` varchar(11) DEFAULT NULL,
  `allow_language` tinyint(1) DEFAULT NULL,
  `spice_api` varchar(75) DEFAULT NULL,
  `cmntapprvd` tinyint(1) DEFAULT '1',
  `gdpract` tinyint(1) DEFAULT '0',
  `gdprver` int(11) DEFAULT NULL,
  `cmntpub` tinyint(1) DEFAULT '1',
  `ldap_server` varchar(255) DEFAULT NULL,
  `ldap_admin` varchar(255) DEFAULT NULL,
  `ldap_admin_pw` varchar(255) DEFAULT NULL,
  `ldap_tree` varchar(255) DEFAULT NULL,
  `ldap_port` varchar(255) DEFAULT NULL,
  `ldap_version` varchar(255) DEFAULT NULL,
  `meekro` tinyint(1) DEFAULT NULL,
  `steam_api` varchar(255) DEFAULT NULL,
  `steam_domain` varchar(255) DEFAULT NULL,
  `stripe_private` varchar(255) DEFAULT NULL,
  `stripe_public` varchar(255) DEFAULT NULL,
  `stripe_private_test` varchar(255) DEFAULT NULL,
  `stripe_public_test` varchar(255) DEFAULT NULL,
  `stripe_live` int(1) DEFAULT NULL,
  `announce` datetime DEFAULT NULL,
  `bleeding_edge` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `recaptcha`, `force_ssl`, `css_sample`, `us_css1`, `us_css2`, `us_css3`, `site_name`, `language`, `track_guest`, `site_offline`, `force_pr`, `glogin`, `fblogin`, `gid`, `gsecret`, `gredirect`, `ghome`, `fbid`, `fbsecret`, `fbcallback`, `graph_ver`, `finalredir`, `req_cap`, `req_num`, `min_pw`, `max_pw`, `min_un`, `max_un`, `messaging`, `snooping`, `echouser`, `wys`, `change_un`, `backup_dest`, `backup_source`, `backup_table`, `msg_notification`, `permission_restriction`, `auto_assign_un`, `page_permission_restriction`, `msg_blocked_users`, `msg_default_to`, `notifications`, `notif_daylimit`, `recap_public`, `recap_private`, `page_default_private`, `navigation_type`, `copyright`, `custom_settings`, `system_announcement`, `twofa`, `force_notif`, `cron_ip`, `registration`, `join_vericode_expiry`, `reset_vericode_expiry`, `admin_verify`, `admin_verify_timeout`, `session_manager`, `template`, `saas`, `redirect_uri_after_login`, `show_tos`, `default_language`, `allow_language`, `spice_api`, `cmntapprvd`, `gdpract`, `gdprver`, `cmntpub`, `ldap_server`, `ldap_admin`, `ldap_admin_pw`, `ldap_tree`, `ldap_port`, `ldap_version`, `meekro`, `steam_api`, `steam_domain`, `stripe_private`, `stripe_public`, `stripe_private_test`, `stripe_public_test`, `stripe_live`, `announce`, `bleeding_edge`) VALUES
(1, 1, 0, 0, '../users/css/color_schemes/bootstrap.min.css', '../users/css/sb-admin.css', '../users/css/custom.css', 'UserSpice55', 'en', 1, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', 0, 0, 6, 30, 3, 30, 0, 1, 0, 1, 0, '/', 'everything', '', 0, 0, 0, 0, 0, 1, 1, 7, '6Ld1VboUAAAAAGoISBFyKW2mTvVsJUQ_o1xjmpOA', '6Ld1VboUAAAAAJvbMKFaOMGqDEmGj7Sxqj_0TAoN', 1, 0, 'UserSpice', 1, '', 0, 0, 'off', 1, 24, 15, 1, 120, 0, 'standard', NULL, NULL, 0, 'en-US', 1, 'WBLNI-OYAZT-D95CA-75EC5-D13F3', 1, 1, 9, 1, 'www.zflexldap.com', 'cn=ro_admin,ou=sysadmins,dc=zflexsoftware,dc=com', 'zflexpass', 'dc=zflexsoftware,dc=com', '389', '3', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-02 14:51:13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stripe_transactions`
--

CREATE TABLE `stripe_transactions` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `card_type` varchar(30) NOT NULL,
  `charge_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test1`
--

CREATE TABLE `test1` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test1`
--

INSERT INTO `test1` (`id`, `fname`, `lname`) VALUES
(1, '1', '2'),
(2, '1', '2');

-- --------------------------------------------------------

--
-- Table structure for table `test1_form`
--

CREATE TABLE `test1_form` (
  `id` int(11) NOT NULL,
  `ord` int(11) NOT NULL,
  `col` varchar(255) NOT NULL,
  `form_descrip` varchar(255) NOT NULL,
  `table_descrip` varchar(255) NOT NULL,
  `col_type` varchar(255) NOT NULL,
  `field_type` varchar(100) NOT NULL,
  `length` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `validation` text NOT NULL,
  `label_class` varchar(255) NOT NULL,
  `field_class` varchar(255) NOT NULL,
  `input_html` text NOT NULL,
  `select_opts` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test1_form`
--

INSERT INTO `test1_form` (`id`, `ord`, `col`, `form_descrip`, `table_descrip`, `col_type`, `field_type`, `length`, `required`, `validation`, `label_class`, `field_class`, `input_html`, `select_opts`) VALUES
(1, 10, 'fname', 'First Name', 'FNaMe', 'varchar', 'text', 0, 1, '{\"min\":\"1\",\"max\":\"100\"}', '', 'form-control', '', 'null'),
(2, 20, 'lname', 'Last Name', 'LastName', 'varchar', 'text', 0, 1, '', '', 'form-control', '', '{\"\":\"\"}');

-- --------------------------------------------------------

--
-- Table structure for table `test2`
--

CREATE TABLE `test2` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test2_form`
--

CREATE TABLE `test2_form` (
  `id` int(11) NOT NULL,
  `ord` int(11) NOT NULL,
  `col` varchar(255) NOT NULL,
  `form_descrip` varchar(255) NOT NULL,
  `table_descrip` varchar(255) NOT NULL,
  `col_type` varchar(255) NOT NULL,
  `field_type` varchar(100) NOT NULL,
  `length` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `validation` text NOT NULL,
  `label_class` varchar(255) NOT NULL,
  `field_class` varchar(255) NOT NULL,
  `input_html` text NOT NULL,
  `select_opts` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test2_form`
--

INSERT INTO `test2_form` (`id`, `ord`, `col`, `form_descrip`, `table_descrip`, `col_type`, `field_type`, `length`, `required`, `validation`, `label_class`, `field_class`, `input_html`, `select_opts`) VALUES
(1, 10, 'fname', 'First Name', 'FNaMe', 'varchar', 'text', 0, 1, '{\"min\":\"1\",\"max\":\"100\"}', '', 'form-control', '', 'null'),
(2, 20, 'lname', 'Last Name', 'LastName', 'varchar', 'text', 0, 1, '', '', 'form-control', '', '{\"\":\"\"}');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `migration` varchar(15) NOT NULL,
  `applied_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_skipped` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `updates`
--

INSERT INTO `updates` (`id`, `migration`, `applied_on`, `update_skipped`) VALUES
(15, '1XdrInkjV86F', '2018-02-18 22:33:24', NULL),
(16, '3GJYaKcqUtw7', '2018-04-25 16:51:08', NULL),
(17, '3GJYaKcqUtz8', '2018-04-25 16:51:08', NULL),
(18, '69qa8h6E1bzG', '2018-04-25 16:51:08', NULL),
(19, '2XQjsKYJAfn1', '2018-04-25 16:51:08', NULL),
(20, '549DLFeHMNw7', '2018-04-25 16:51:08', NULL),
(21, '4Dgt2XVjgz2x', '2018-04-25 16:51:08', NULL),
(22, 'VLBp32gTWvEo', '2018-04-25 16:51:08', NULL),
(23, 'Q3KlhjdtxE5X', '2018-04-25 16:51:08', NULL),
(24, 'ug5D3pVrNvfS', '2018-04-25 16:51:08', NULL),
(25, '69FbVbv4Jtrz', '2018-04-25 16:51:09', NULL),
(26, '4A6BdJHyvP4a', '2018-04-25 16:51:09', NULL),
(27, '37wvsb5BzymK', '2018-04-25 16:51:09', NULL),
(28, 'c7tZQf926zKq', '2018-04-25 16:51:09', NULL),
(29, 'ockrg4eU33GP', '2018-04-25 16:51:09', NULL),
(30, 'XX4zArPs4tor', '2018-04-25 16:51:09', NULL),
(31, 'pv7r2EHbVvhD', '2018-04-26 00:00:00', NULL),
(32, 'uNT7NpgcBDFD', '2018-04-26 00:00:00', NULL),
(33, 'mS5VtQCZjyJs', '2018-12-11 14:19:16', NULL),
(34, '23rqAv5elJ3G', '2018-12-11 14:19:51', NULL),
(35, 'hcA5B3PLhq6E', '2019-04-28 17:09:59', NULL),
(36, 'FyMYJ2oeGCTX', '2019-04-28 17:09:59', NULL),
(37, 'iit5tHSLatiS', '2019-04-28 17:09:59', NULL),
(38, 'VNEno3E4zaNz', '2019-04-28 17:09:59', NULL),
(39, 'qPEARSh49fob', '2019-04-28 17:09:59', NULL),
(40, '2ZB9mg1l0JXe', '2019-04-28 17:09:59', NULL),
(41, 'B9t6He7qmFXa', '2019-04-28 17:09:59', NULL),
(42, '86FkFVV4TGRg', '2019-04-28 17:09:59', NULL),
(43, 'y4A1Y0u9n2Rt', '2019-04-28 17:09:59', NULL),
(44, 'Tm5xY22MM8eC', '2019-04-28 17:09:59', NULL),
(45, '0YXdrInkjV86F', '2019-04-28 17:09:59', NULL),
(46, '99plgnkjV86', '2019-04-28 17:09:59', NULL),
(47, '0DaShInkjV86', '2019-04-28 17:09:59', NULL),
(48, '0DaShInkjVz1', '2019-07-17 14:48:22', NULL),
(49, 'y4A1Y0u9n2SS', '2019-07-21 15:03:19', NULL),
(50, '0DaShInkjV87', '2019-08-05 09:40:16', NULL),
(51, '0DaShInkjV88', '2019-08-05 09:40:16', NULL),
(53, '2019-09-04a', '2019-09-04 11:00:44', NULL),
(54, '2019-09-05a', '2019-09-05 12:44:33', NULL),
(55, '2019-09-26a', '2019-09-26 12:29:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(155) NOT NULL,
  `email_new` varchar(155) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pin` varchar(255) DEFAULT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `permissions` int(11) NOT NULL,
  `logins` int(11) UNSIGNED NOT NULL,
  `account_owner` tinyint(4) NOT NULL DEFAULT '0',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `company` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `email_verified` tinyint(4) NOT NULL DEFAULT '0',
  `vericode` varchar(15) NOT NULL,
  `active` int(1) NOT NULL,
  `oauth_provider` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `oauth_uid` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gpluslink` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `fb_uid` varchar(255) NOT NULL,
  `un_changed` int(1) NOT NULL,
  `msg_exempt` int(1) NOT NULL DEFAULT '0',
  `last_confirm` datetime DEFAULT NULL,
  `protected` int(1) NOT NULL DEFAULT '0',
  `dev_user` int(1) NOT NULL DEFAULT '0',
  `msg_notification` int(1) NOT NULL DEFAULT '1',
  `force_pr` int(1) NOT NULL DEFAULT '0',
  `twoKey` varchar(16) DEFAULT NULL,
  `twoEnabled` int(1) DEFAULT '0',
  `twoDate` datetime DEFAULT NULL,
  `cloak_allowed` tinyint(1) NOT NULL DEFAULT '0',
  `org` int(11) DEFAULT NULL,
  `account_mgr` int(11) DEFAULT '0',
  `oauth_tos_accepted` tinyint(1) DEFAULT NULL,
  `vericode_expiry` datetime DEFAULT NULL,
  `language` varchar(255) DEFAULT 'en-US',
  `apibld_key` varchar(255) DEFAULT NULL,
  `apibld_ip` varchar(255) DEFAULT NULL,
  `apibld_blocked` tinyint(1) DEFAULT '0',
  `commentmod` tinyint(1) DEFAULT '0',
  `gdpr` int(11) DEFAULT '0',
  `gdpr_date` datetime DEFAULT NULL,
  `ldap` varchar(255) DEFAULT NULL,
  `steam_id` varchar(255) DEFAULT NULL,
  `steam_un` varchar(255) DEFAULT NULL,
  `steam_avatar` varchar(255) DEFAULT NULL,
  `membership` int(11) DEFAULT '0',
  `member_thru` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `email_new`, `username`, `password`, `pin`, `fname`, `lname`, `permissions`, `logins`, `account_owner`, `account_id`, `company`, `join_date`, `last_login`, `email_verified`, `vericode`, `active`, `oauth_provider`, `oauth_uid`, `gender`, `locale`, `gpluslink`, `picture`, `created`, `modified`, `fb_uid`, `un_changed`, `msg_exempt`, `last_confirm`, `protected`, `dev_user`, `msg_notification`, `force_pr`, `twoKey`, `twoEnabled`, `twoDate`, `cloak_allowed`, `org`, `account_mgr`, `oauth_tos_accepted`, `vericode_expiry`, `language`, `apibld_key`, `apibld_ip`, `apibld_blocked`, `commentmod`, `gdpr`, `gdpr_date`, `ldap`, `steam_id`, `steam_un`, `steam_avatar`, `membership`, `member_thru`) VALUES
(1, 'bob@aol.com', NULL, 'admin', '$2y$12$1v06jm2KMOXuuo3qP7erTuTIJFOnzhpds1Moa8BadnUUeX0RV3ex.', NULL, 'The', 'Admin', 1, 45, 1, 0, 'UserSpice', '2016-01-01 00:00:00', '2019-10-03 14:19:14', 1, 'uLoZ4Ff7HRh7GGJ', 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '1899-11-30 00:00:00', '', 0, 1, '2017-10-08 15:24:37', 1, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-04-28 20:47:15', 'en-US', 'IW0AP-1WTSI-VN5D4-876A2-C59CA', 'anothermaker1.duckdns.org', 0, 0, 9, '2019-08-26 09:37:07', NULL, NULL, NULL, NULL, 0, NULL),
(2, 'mudmin@gmail.com', NULL, 'user', '$2y$12$1MYh/PYXghuVHqGU7mytuel6AUgT00Xyn3UnjaFwf9qahMARegwly', NULL, 'Sample', 'User', 1, 1, 1, 0, 'none', '2016-01-02 00:00:00', '2019-08-12 09:04:14', 1, '4I8NpUVr7Je7UeY', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-04-29 14:01:36', 'en-US', 'B3H58-6HTWH-QQ5D4-876A2-C61C9', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(5, 'Bob@aol.com', NULL, 'Danny', '$2y$12$1WIm8EkVS6yPwy9gcxAgrO4riA9z6SfoAjJb1dzi.mdA8T7eVblhy', NULL, 'Dan', 'Hoover', 1, 1, 1, 0, '', '2019-08-13 10:44:44', '2019-08-13 10:45:12', 1, 'CBhnpD24c7RhOzQ', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-08-13 10:44:44', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(6, 'Bob2@aol.com', NULL, 'Danny2', '$2y$12$6axhM.4jtjMs5j2b/Wh57OdSNH9AmPaA6lbFj7qY11A8a4hChl3cu', NULL, 'Dan', 'Hoover', 1, 0, 1, 0, '', '2019-08-13 11:05:27', '0000-00-00 00:00:00', 1, 'N2GSFIP0Q8iOEx6', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-08-13 11:05:27', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(7, 'test@aol.com', NULL, 'test', '$2y$12$QW5.l1HBZR71Q0jacf2Dney2YiT7KrnpnQZ5uea/7Qs7vucAnzgDO', NULL, 'Test', 'Test', 1, 0, 1, 0, '', '2019-09-25 06:53:27', '0000-00-00 00:00:00', 1, 'HVRAHQgD26Vcylt', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-09-25 06:53:27', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(8, 'rfdsfsd@aol.com', NULL, 'fdsfsdfsd', '$2y$12$skaoTM4Tw3V2QmDyfxF45OKqWDNdj4QEKEDv3u0BIockIkrzSwv6m', NULL, 'Fsdfsddfs', 'Fsd', 1, 0, 1, 0, '', '2019-09-25 09:30:38', '0000-00-00 00:00:00', 1, '9UzG9cptonDamU2', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-09-25 09:30:38', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(9, 'Guy@aol.com', NULL, 'testguy8', '$2y$12$7bhEeUV2J1e.Lx7kHA7.pu5TFFrQcwDDEJJe0bxltrFQ4H5.H.87K', NULL, 'Testguy8', 'Test', 1, 0, 1, 0, '', '2019-09-25 09:32:11', '0000-00-00 00:00:00', 1, 'S2hNQeYJKwIMkI', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-09-25 09:32:11', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL),
(10, 'testguy0@aol.com', NULL, 'testguy0', '$2y$12$08AXBDeIVi3B9P2V/oVjH.yqnZhX64YcDtZbLrQQCcsnvXIcGafFS', NULL, 'Test', 'Test', 1, 1, 1, 0, '', '2019-09-25 09:32:57', '2019-09-25 09:33:04', 1, '4SriEqIanQID08q', 1, '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, 0, NULL, 0, 0, 1, 0, NULL, 0, NULL, 0, NULL, 0, 1, '2019-09-25 09:32:57', 'en-US', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(10) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `timestamp` varchar(15) NOT NULL,
  `user_id` int(10) NOT NULL,
  `session` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `ip`, `timestamp`, `user_id`, `session`) VALUES
(1, '::1', '1556545269', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE `users_session` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `uagent` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_permission_matches`
--

CREATE TABLE `user_permission_matches` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_permission_matches`
--

INSERT INTO `user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(100, 1, 1),
(101, 1, 2),
(102, 2, 1),
(103, 3, 1),
(104, 4, 1),
(105, 5, 1),
(106, 6, 1),
(107, 7, 1),
(108, 8, 1),
(109, 9, 1),
(110, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `us_announcements`
--

CREATE TABLE `us_announcements` (
  `id` int(11) NOT NULL,
  `dismissed` int(11) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `ignore` varchar(50) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_announcements`
--

INSERT INTO `us_announcements` (`id`, `dismissed`, `link`, `title`, `message`, `ignore`, `class`) VALUES
(1, 3, 'https://www.userspice.com/updates', 'New Version', 'December 11, 2018 - Thank you for trying UserSpice Beta!', '4.5.0', 'warning'),
(2, 15, '#', 'New Version!', 'April 28, 2019 - UserSpice 4.4.11 Released. SECURITY RELEASE - Fixes jQuery vulnerability.', '4.4.11', 'danger');

-- --------------------------------------------------------

--
-- Table structure for table `us_comments_plugin`
--

CREATE TABLE `us_comments_plugin` (
  `id` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `page` int(11) DEFAULT NULL,
  `comment` text,
  `deleted` tinyint(1) DEFAULT '0',
  `approved` tinyint(1) DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_fingerprints`
--

CREATE TABLE `us_fingerprints` (
  `kFingerprintID` int(11) UNSIGNED NOT NULL,
  `fkUserID` int(11) NOT NULL,
  `Fingerprint` varchar(32) NOT NULL,
  `Fingerprint_Expiry` datetime NOT NULL,
  `Fingerprint_Added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_fingerprint_assets`
--

CREATE TABLE `us_fingerprint_assets` (
  `kFingerprintAssetID` int(11) UNSIGNED NOT NULL,
  `fkFingerprintID` int(11) NOT NULL,
  `IP_Address` varchar(255) NOT NULL,
  `User_Browser` varchar(255) NOT NULL,
  `User_OS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_forms`
--

CREATE TABLE `us_forms` (
  `id` int(11) NOT NULL,
  `form` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_forms`
--

INSERT INTO `us_forms` (`id`, `form`) VALUES
(1, 'test1'),
(2, 'test2'),
(3, 'menus');

-- --------------------------------------------------------

--
-- Table structure for table `us_form_validation`
--

CREATE TABLE `us_form_validation` (
  `id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_form_validation`
--

INSERT INTO `us_form_validation` (`id`, `value`, `description`, `params`) VALUES
(1, 'min', 'Minimum # of Characters', 'number'),
(2, 'max', 'Maximum # of Characters', 'number'),
(3, 'is_numeric', 'Must be a number', 'true'),
(4, 'valid_email', 'Must be a valid email address', 'true'),
(5, '<', 'Must be a number less than', 'number'),
(6, '>', 'Must be a number greater than', 'number'),
(7, '<=', 'Must be a number less than or equal to', 'number'),
(8, '>=', 'Must be a number greater than or equal to', 'number'),
(9, '!=', 'Must not be equal to', 'text'),
(10, '==', 'Must be equal to', 'text'),
(11, 'is_integer', 'Must be an integer', 'true'),
(12, 'is_timezone', 'Must be a valid timezone name', 'true'),
(13, 'is_datetime', 'Must be a valid DateTime', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `us_form_views`
--

CREATE TABLE `us_form_views` (
  `id` int(11) NOT NULL,
  `form_name` varchar(255) NOT NULL,
  `view_name` varchar(255) NOT NULL,
  `fields` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_gdpr`
--

CREATE TABLE `us_gdpr` (
  `id` int(11) NOT NULL,
  `popup` text,
  `detail` text,
  `confirm` text,
  `btn_accept` varchar(255) DEFAULT NULL,
  `btn_more` varchar(255) DEFAULT NULL,
  `btn_delete` varchar(255) DEFAULT NULL,
  `btn_confirm_no` varchar(255) DEFAULT NULL,
  `btn_confirm_yes` varchar(255) DEFAULT NULL,
  `delete` tinyint(1) DEFAULT '0',
  `created_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_gdpr`
--

INSERT INTO `us_gdpr` (`id`, `popup`, `detail`, `confirm`, `btn_accept`, `btn_more`, `btn_delete`, `btn_confirm_no`, `btn_confirm_yes`, `delete`, `created_on`) VALUES
(1, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-06 06:18:36'),
(2, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing123.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-23 12:43:40'),
(3, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing1234.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-23 13:35:16');
INSERT INTO `us_gdpr` (`id`, `popup`, `detail`, `confirm`, `btn_accept`, `btn_more`, `btn_delete`, `btn_confirm_no`, `btn_confirm_yes`, `delete`, `created_on`) VALUES
(4, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing12345.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-23 15:02:12'),
(5, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing123456.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-23 15:06:02'),
(6, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing1234567.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-26 09:25:38');
INSERT INTO `us_gdpr` (`id`, `popup`, `detail`, `confirm`, `btn_accept`, `btn_more`, `btn_delete`, `btn_confirm_no`, `btn_confirm_yes`, `delete`, `created_on`) VALUES
(7, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing12345678.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-26 09:26:09'),
(8, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing123456789.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-26 09:26:49'),
(9, 'We use cookies and collect personal information in accordance with our policy to provide you with the best possible user experience. Testing123456789.', '1. Introduction&lt;br&gt;\r\nThis information sheet serves to inform you about our website&rsquo;s (&ldquo;Website&rdquo;) Cookie Policy so that you may better understand the use of cookies during your navigation and provide your consent thereto.\r\n&lt;br&gt;&lt;br&gt;\r\nIt is understood that by continuing to navigate on this Website you are consenting to the use of cookies, as specifically indicated in the notice on the front page (&ldquo;Homepage&rdquo;) reporting the existence of our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n2. Who is the controller of your data?&lt;br&gt;\r\nWhen this policy mentions &ldquo;Company&rdquo;, &ldquo;we,&rdquo; &ldquo;us,&rdquo; &ldquo;our&rdquo; or &ldquo;Data Controller&rdquo;, it refers to the website you are visiting right now.\r\n&lt;br&gt;&lt;br&gt;\r\n3. What are cookies?&lt;br&gt;\r\nCookies are small files which are stored on your computer, they hold a modest amount of data specific to you and allows a server to deliver a page tailored to you on your computer, hard drive, smartphone or tablet (hereinafter referred to as, &ldquo;Device&rdquo;). Later on, if you return to our Website, it can read and recognize the cookies. Primarily, they are used to operate or improve the way our Website works as well as to provide business and marketing information to the Website owner.\r\n&lt;br&gt;&lt;br&gt;\r\n4. Authorization for the use of cookies on our Website&lt;br&gt;\r\nIn accordance with the notice of cookie usage appearing on our Website&rsquo;s homepage and our Cookie Policy you agree that, when browsing our Website, you consent to the use of cookies described herein, except to the extent that you have modified your browser settings to disable their use. This includes but is not limited to browsing our Website to complete any of the following actions: closing the cookie notice on the Homepage, scrolling through the Website, clicking on any element of the Website, etc.\r\n&lt;br&gt;&lt;br&gt;\r\n5. What categories of your data do we collect and use?&lt;br&gt;\r\nWhen you visit the Website (you as a &quot;User&quot;) we collect the categories of personal data as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nPersonal data collected  during your signup and automatically from our Website.\r\n&lt;br&gt;&lt;br&gt;\r\nInformation about your visits to and use of the Website, such as information about the device and browser you are using, your IP address or domain names of the computers connected to the Websites, uniform resource identifiers for requests made, the time of request, the method used to submit the request to the server, the size of the archive obtained as a response, the numerical code indicating the status of the response given by the server (correct, error, etc.) and other parameters relative to the operating system and the computer environment used, the date and time that you visited, the duration of your visit, the referral source and website navigation paths of your visit and your interactions on the Website including the Services and offers you are interested in. Please note that we may associate this information with your account. If you delete your account, this information will no longer be linked to you in our database.\r\n&lt;br&gt;&lt;br&gt;\r\nPlease see the following clause of this Policy for further information on the purposes for which we collect and use this information.\r\n&lt;br&gt;&lt;br&gt;\r\n6. Types of cookies used on our Website&lt;br&gt;&lt;br&gt;\r\n6.1. Types of cookies according to the managing entity&lt;br&gt;\r\n\r\nDepending on what entity manages the computer or domain from which the cookies are sent and processed, there exist the following types of cookies:\r\n&lt;br&gt;\r\nFirst party cookies: these are sent to your Device from a computer or domain managed by us and from which the service you requested is provided.&lt;br&gt;&lt;br&gt;\r\nThird party cookies: these are sent to your Device from a computer or domain that is not managed by us, but by a separate entity that processes data obtained through cookies.&lt;br&gt;&lt;br&gt;\r\n6.2. Types of cookies according to the length of time you stay connected: &lt;br&gt;\r\n\r\nDepending on the amount of time you remain active on your Device, these are the following types of cookies:\r\n&lt;br&gt;&lt;br&gt;\r\nSession cookies: these are designed to receive and store data while you access the Website. These cookies do not remain stored on your Device when you exit the session or browser.&lt;br&gt;&lt;br&gt;\r\nPersistent cookies: these types of cookies remain stored on your Device and can be accessed and processed after you exit the Website as well as when you navigate on it for a pre-determined period of time. The cookie remains on the hard drive until it reaches its expiration date. The maximum time we use persistent cookies on our Website is 2 years. At this point the browser would purge the cookie from the hard drive.&lt;br&gt;&lt;br&gt;\r\n6.3. Types of cookies according to their purpose&lt;br&gt;\r\n\r\nCookies can be grouped as follows:\r\n&lt;br&gt;&lt;br&gt;\r\nTechnical cookies: these cookies are strictly necessary for the operation of our Website and are essential for browsing and allow the use of various features. Without them, you cannot use the search function, compare tool or book other available services on our Website.&lt;br&gt;&lt;br&gt;\r\nPersonalization cookies: these are used to make navigating our Website easier, as well as to remember your selections and offer more personalized services. In some cases, we may allow advertisers or other third parties to place cookies on our Website to provide personalized content and services. In any case, your use of our Website serves as your acceptance of the use of this type of cookie. If cookies are blocked, we cannot guarantee the functioning of such services.&lt;br&gt;&lt;br&gt;\r\nAnalytical cookies for statistical purposes and measuring traffic: these cookies gather information about your use of our Website, the pages you visit and any errors that may occur during navigation. We also use these cookies to recognize the place of origin for visits to our Website. These cookies do not gather information that may personally identify you. All information is collected in an anonymous manner and is used to improve the functioning of our Website through statistical information. Therefore, these cookies do not contain personal data. In some cases, some of these cookies are managed on our behalf by third parties, but may not be used by them for purposes other than those mentioned above.&lt;br&gt;&lt;br&gt;\r\nAdvertising and re-marketing cookies: these cookies are used to gather information so that ads are more interesting to you, as well as to display other advertising campaigns along with advertisements on the Website or on those of third parties. Most of these cookies are &ldquo;third party cookies&rdquo; which are not managed by us and, because of the way they work, cannot be accessed by us, nor are we responsible for their management or purpose.\r\n&lt;br&gt;&lt;br&gt;\r\nTo that end, we can also use the services of a third party in order to collect data and/or publish ads when you visit our Website. These companies often use anonymous and aggregated information (not including, for example, your name, address, email address or telephone number) regarding visits to this Website and others in order to publish ads about goods and services of interest to you.&lt;br&gt;&lt;br&gt;\r\nSocial cookies: these cookies allow you to share our Website and click &ldquo;Like&rdquo; on social networks like Facebook, Twitter, Google, and YouTube, etc. They also allow you interact with each distinct platform&rsquo;s contents. The way these cookies are used and the information gathered is governed by the privacy policy of each social platform, which you can find on the list below in Paragraph 5 of this Policy.&lt;br&gt;&lt;br&gt;\r\n\r\n7. List of cookies used on this Website&lt;br&gt;\r\nDefault Browser/Login Cookie&lt;br&gt;\r\n\r\nWe are not responsible for the contents and accuracy of third party cookie policies contained in our Cookie Policy.\r\n&lt;br&gt;&lt;br&gt;\r\n8. Why do we collect your data?&lt;br&gt;\r\nA. To create and maintain the contractual relation established for the provision of the Service requested by you in all its phases and by way of any possible integration and modification.&lt;br&gt;\r\nTo provide a requested service&lt;br&gt;&lt;br&gt;\r\nB. To meet the legal, regulatory and compliance requirements and to respond to requests by government or law enforcement authorities conducting an investigation.&lt;br&gt;&lt;br&gt;\r\nTo comply with the law&lt;br&gt;\r\nC. To carry out anonymous, aggregation and statistical analyses so that we can see how our Website, products and services are being used and how our Website is performing.&lt;br&gt;&lt;br&gt;\r\nTo pursue our legitimate interest(i.e. improving our Website, its features and our products and services)&lt;br&gt;&lt;br&gt;\r\n\r\nD. To tailor and personalize online marketing notifications and advertising for you based on the information on your use of our Website, products and services and other sites collected through cookies.&lt;br&gt;\r\nWhere you give your consent (i.e. through the cookie banner or by your browser\'s settings)&lt;br&gt;&lt;br&gt;\r\n9. How long do we retain your data?&lt;br&gt;\r\nWe retain your personal data for as long as is required to achieve the purposes and fulfill the activities as set out in this Cookies Policy, otherwise communicated to you or for as long as is permitted by applicable law. Further information about the retention period is available here:\r\n&lt;br&gt;&lt;br&gt;\r\nData collected-retention period&lt;br&gt;\r\nTechnical cookies-Max 3 years from the date of browsing on our websites&lt;br&gt;\r\nNon-technical cookies-Max 1 year	from the date of browsing on our websites&lt;br&gt;\r\n&lt;br&gt;&lt;br&gt;\r\n10. Cookie management&lt;br&gt;\r\nYou must keep in mind that if your Device does not have cookies enabled, your experience on the Website may be limited, thereby impeding the navigation and use of our services.&lt;br&gt;\r\n\r\n10.1.- How do I disable/enable cookies?&lt;br&gt;\r\n\r\nThere are a number of ways to manage cookies. By modifying your browser settings, you can opt to disable cookies or receive a notification before accepting them. You can also erase all cookies installed in your browser&rsquo;s cookie folder. Keep in mind that each browser has a different procedure for managing and configuring cookies. Here&rsquo;s how you manage cookies in the various major browsers:&lt;br&gt;&lt;br&gt;\r\n\r\nHere&rsquo;s how you manage cookies in the various major browsers:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;https://support.microsoft.com/en-us/kb/278835&quot;&gt;MICROSOFT INTERNET EXPLORER/EDGE&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.google.com/chrome/answer/95647?hl=en-GB&quot;&gt;GOOGLE CHROME&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;https://support.mozilla.org/en-US/kb/enable-and-disable-cookies-website-preferences?redirectlocale=en-US&amp;amp;redirectslug=Enabling+and+disabling+cookies&quot;&gt;MOZILLA FIREFOX&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.apple.com/support/?path=Safari/5.0/en/9277.html&quot;&gt;APPLE SAFARI&lt;/a&gt;&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;\r\n&lt;br&gt;\r\nIf you use another browser, please read its help menu for more information.\r\n&lt;br&gt;\r\nIf you would like information about managing cookies on your tablet or smartphone, please read the related documentation or help archives online.&lt;br&gt;&lt;br&gt;\r\n\r\n10.2.- How are third party cookies enabled/disabled?&lt;br&gt;\r\n\r\nWe do not install third party cookies. They are installed by our partners or other third parties when you visit our Website. Therefore, we suggest that you consult our partners&rsquo; Websites for more information on managing any third party cookies that are installed. However, we invite you to visit the following website http://www.youronlinechoices.com/ where you can find useful information about the use of cookies as well as the measures you can take to protect your privacy on the internet.\r\n&lt;br&gt;&lt;br&gt;\r\n11. What are your data protection rights and how can you exercise them?&lt;br&gt;\r\nYou can exercise the rights provided by the Regulation EU 2016/679 (Articles 15-22), including the right to:&lt;br&gt;\r\n\r\nRight of access - To receive confirmation of the existence of your personal data, access its content and obtain a copy.&lt;br&gt;&lt;br&gt;\r\nRight of rectification - To update, rectify and/or correct your personal data.&lt;br&gt;&lt;br&gt;\r\nRight to erasure/right to be forgotten and right to restriction - To request the erasure of your data or restriction of your data which has been processed in violation of the law, including whose storage is not necessary in relation to the purposes for which the data was collected or otherwise processed; where we have made your personal data public, you have also the right to request the erasure of your personal data and to take reasonable steps, including technical measures, to inform other data controllers which are processing the personal data that you have requested the erasure by such controllers of any links to, or copy or replication of, those personal data.&lt;br&gt;&lt;br&gt;\r\nRight to data portability - To receive a copy of your personal data you provided to us for a contract or with your consent in a structured, commonly used and machine-readable format (e.g. data relating to your purchases) and to ask us to transfer that personal data to another data controller.&lt;br&gt;&lt;br&gt;\r\nRight to withdraw your consent - Wherever we rely on your consent, you will always be able to withdraw that consent, although we may have other legal grounds for processing your data for other purposes.&lt;br&gt;&lt;br&gt;\r\nRight to object, at any time\r\nYou have the right to object at any time to the processing of your personal data in some circumstances (in particular, where we don&rsquo;t have to process the data to meet a contractual or other legal requirement, or where we are using your data for direct marketing.&lt;br&gt;&lt;br&gt;\r\nYou can exercise the above rights at any time by:&lt;br&gt;&lt;br&gt;', 'Are you absolutely SURE you want to delete your account. This cannot be undone!', 'Accept', 'More Info', 'Delete My Account', 'No! I Changed My Mind.', 'Yes, Please Delete My Account', 0, '2019-08-26 09:27:11');

-- --------------------------------------------------------

--
-- Table structure for table `us_ip_blacklist`
--

CREATE TABLE `us_ip_blacklist` (
  `id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `last_user` int(11) NOT NULL DEFAULT '0',
  `reason` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_ip_blacklist`
--

INSERT INTO `us_ip_blacklist` (`id`, `ip`, `last_user`, `reason`) VALUES
(3, '192.168.0.21', 1, 0),
(4, '192.168.0.22', 1, 0),
(10, '192.168.0.222', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_ip_list`
--

CREATE TABLE `us_ip_list` (
  `id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_ip_list`
--

INSERT INTO `us_ip_list` (`id`, `ip`, `user_id`, `timestamp`) VALUES
(1, '::1', 1, '2019-09-25 13:50:19');

-- --------------------------------------------------------

--
-- Table structure for table `us_ip_whitelist`
--

CREATE TABLE `us_ip_whitelist` (
  `id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_ip_whitelist`
--

INSERT INTO `us_ip_whitelist` (`id`, `ip`) VALUES
(2, '192.168.0.21'),
(3, '192.168.0.23');

-- --------------------------------------------------------

--
-- Table structure for table `us_management`
--

CREATE TABLE `us_management` (
  `id` int(11) NOT NULL,
  `page` varchar(255) NOT NULL,
  `view` varchar(255) NOT NULL,
  `feature` varchar(255) NOT NULL,
  `access` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_management`
--

INSERT INTO `us_management` (`id`, `page`, `view`, `feature`, `access`) VALUES
(1, '_admin_manage_ip.php', 'ip', 'IP Whitelist/Blacklist', ''),
(2, '_admin_messages.php', 'messages', 'Messages', ''),
(3, '_admin_nav.php', 'nav', 'Navigation', ''),
(4, '_admin_nav_item.php', 'nav_item', 'Navigation', ''),
(5, '_admin_notifications.php', 'notifications', 'Notifications', ''),
(6, '_admin_page.php', 'page', 'Page Management', ''),
(7, '_admin_pages.php', 'pages', 'Page Management', ''),
(10, '_admin_security_logs.php', 'security_logs', 'Security Logs', ''),
(11, '_admin_sessions.php', 'sessions', 'Session Management', ''),
(12, '_admin_templates.php', 'templates', 'Templates', ''),
(13, '_admin_tools_check_updates.php', 'updates', 'Check Updates', '');

-- --------------------------------------------------------

--
-- Table structure for table `us_plugins`
--

CREATE TABLE `us_plugins` (
  `id` int(11) NOT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updates` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_plugins`
--

INSERT INTO `us_plugins` (`id`, `plugin`, `status`, `updates`) VALUES
(3, 'performancechecker', 'active', NULL),
(8, 'notifications', 'installed', NULL),
(13, 'gdpr', 'active', NULL),
(14, 'apibuilder', 'active', NULL),
(17, 'comments', 'installed', NULL),
(18, 'dbman', 'installed', NULL),
(20, 'facebook_login', 'installed', NULL),
(21, 'fileman', 'installed', NULL),
(22, 'formbuilder', 'installed', NULL),
(23, 'google_login', 'installed', NULL),
(24, 'langcheck', 'installed', NULL),
(25, 'ldap_login', 'installed', NULL),
(26, 'localhostlogin', 'installed', NULL),
(27, 'meekro', 'installed', NULL),
(28, 'messages', 'installed', NULL),
(29, 'mqtt', 'installed', NULL),
(30, 'steam_login', 'installed', NULL),
(31, 'stripe', 'installed', NULL),
(32, 'sysinfo', 'installed', NULL),
(34, 'membership', 'active', NULL),
(35, 'documentation', 'active', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `us_plugin_hooks`
--

CREATE TABLE `us_plugin_hooks` (
  `id` int(11) UNSIGNED NOT NULL,
  `page` varchar(255) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `hook` varchar(255) NOT NULL,
  `disabled` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_plugin_hooks`
--

INSERT INTO `us_plugin_hooks` (`id`, `page`, `folder`, `position`, `hook`, `disabled`) VALUES
(12, 'account.php', 'apibuilder', 'bottom', 'hooks/accountbottom.php', 0),
(13, 'account.php', 'apibuilder', 'bottom', 'hooks/accountbottom.php', 0),
(14, 'account.php', 'apibuilder', 'bottom', 'hooks/accountbottom.php', 0),
(15, 'account.php', 'apibuilder', 'bottom', 'hooks/accountbottom.php', 0),
(16, 'account.php', 'apibuilder', 'bottom', 'hooks/accountbottom.php', 0),
(17, 'login.php', 'facebook_login', 'body', 'hooks/loginbody.php', 0),
(18, 'join.php', 'facebook_login', 'body', 'hooks/loginbody.php', 0),
(19, 'login.php', 'google_login', 'body', 'hooks/loginbody.php', 0),
(20, 'join.php', 'google_login', 'body', 'hooks/loginbody.php', 0),
(21, 'login.php', 'ldap_login', 'body', 'hooks/redir.php', 0),
(22, 'join.php', 'ldap_login', 'body', 'hooks/redir.php', 0),
(23, 'user_settings.php', 'ldap_login', 'body', 'hooks/user_settings.php', 0),
(24, 'login.php', 'localhostlogin', 'bottom', 'hooks/loginbottom.php', 0),
(25, 'login.php', 'steam_login', 'body', 'hooks/loginbody.php', 0),
(26, 'account.php', 'steam_login', 'body', 'hooks/link_button_account.php', 0),
(27, 'account.php', 'steam_login', 'bottom', 'hooks/accountbottom.php', 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_saas_levels`
--

CREATE TABLE `us_saas_levels` (
  `id` int(11) NOT NULL,
  `level` varchar(255) NOT NULL,
  `users` int(11) NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_saas_orgs`
--

CREATE TABLE `us_saas_orgs` (
  `id` int(11) NOT NULL,
  `org` varchar(255) NOT NULL,
  `owner` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `us_user_sessions`
--

CREATE TABLE `us_user_sessions` (
  `kUserSessionID` int(11) UNSIGNED NOT NULL,
  `fkUserID` int(11) UNSIGNED NOT NULL,
  `UserFingerprint` varchar(255) NOT NULL,
  `UserSessionIP` varchar(255) NOT NULL,
  `UserSessionOS` varchar(255) NOT NULL,
  `UserSessionBrowser` varchar(255) NOT NULL,
  `UserSessionStarted` datetime NOT NULL,
  `UserSessionLastUsed` datetime DEFAULT NULL,
  `UserSessionLastPage` varchar(255) NOT NULL,
  `UserSessionEnded` tinyint(1) NOT NULL DEFAULT '0',
  `UserSessionEnded_Time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit`
--
ALTER TABLE `audit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crons`
--
ALTER TABLE `crons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crons_logs`
--
ALTER TABLE `crons_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documentation`
--
ALTER TABLE `documentation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups_menus`
--
ALTER TABLE `groups_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `keys`
--
ALTER TABLE `keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs_exempt`
--
ALTER TABLE `logs_exempt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `logs_exempt_type` (`name`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus_form`
--
ALTER TABLE `menus_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_threads`
--
ALTER TABLE `message_threads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission_page_matches`
--
ALTER TABLE `permission_page_matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plg_api_fails`
--
ALTER TABLE `plg_api_fails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plg_api_pool`
--
ALTER TABLE `plg_api_pool`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plg_api_settings`
--
ALTER TABLE `plg_api_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stripe_transactions`
--
ALTER TABLE `stripe_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test1`
--
ALTER TABLE `test1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test1_form`
--
ALTER TABLE `test1_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test2`
--
ALTER TABLE `test2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test2_form`
--
ALTER TABLE `test2_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EMAIL` (`email`) USING BTREE;

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_session`
--
ALTER TABLE `users_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_permission_matches`
--
ALTER TABLE `user_permission_matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_announcements`
--
ALTER TABLE `us_announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_comments_plugin`
--
ALTER TABLE `us_comments_plugin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_fingerprints`
--
ALTER TABLE `us_fingerprints`
  ADD PRIMARY KEY (`kFingerprintID`);

--
-- Indexes for table `us_fingerprint_assets`
--
ALTER TABLE `us_fingerprint_assets`
  ADD PRIMARY KEY (`kFingerprintAssetID`);

--
-- Indexes for table `us_forms`
--
ALTER TABLE `us_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_form_validation`
--
ALTER TABLE `us_form_validation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_form_views`
--
ALTER TABLE `us_form_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_gdpr`
--
ALTER TABLE `us_gdpr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_ip_blacklist`
--
ALTER TABLE `us_ip_blacklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_ip_list`
--
ALTER TABLE `us_ip_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_ip_whitelist`
--
ALTER TABLE `us_ip_whitelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_management`
--
ALTER TABLE `us_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_plugins`
--
ALTER TABLE `us_plugins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_plugin_hooks`
--
ALTER TABLE `us_plugin_hooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_saas_levels`
--
ALTER TABLE `us_saas_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_saas_orgs`
--
ALTER TABLE `us_saas_orgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_user_sessions`
--
ALTER TABLE `us_user_sessions`
  ADD PRIMARY KEY (`kUserSessionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit`
--
ALTER TABLE `audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `crons`
--
ALTER TABLE `crons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `crons_logs`
--
ALTER TABLE `crons_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documentation`
--
ALTER TABLE `documentation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `groups_menus`
--
ALTER TABLE `groups_menus`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `keys`
--
ALTER TABLE `keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=419;

--
-- AUTO_INCREMENT for table `logs_exempt`
--
ALTER TABLE `logs_exempt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `menus_form`
--
ALTER TABLE `menus_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `message_threads`
--
ALTER TABLE `message_threads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permission_page_matches`
--
ALTER TABLE `permission_page_matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `plg_api_fails`
--
ALTER TABLE `plg_api_fails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plg_api_pool`
--
ALTER TABLE `plg_api_pool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `plg_api_settings`
--
ALTER TABLE `plg_api_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stripe_transactions`
--
ALTER TABLE `stripe_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test1`
--
ALTER TABLE `test1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `test1_form`
--
ALTER TABLE `test1_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `test2`
--
ALTER TABLE `test2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test2_form`
--
ALTER TABLE `test2_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_session`
--
ALTER TABLE `users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_permission_matches`
--
ALTER TABLE `user_permission_matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `us_announcements`
--
ALTER TABLE `us_announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `us_comments_plugin`
--
ALTER TABLE `us_comments_plugin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_fingerprints`
--
ALTER TABLE `us_fingerprints`
  MODIFY `kFingerprintID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_fingerprint_assets`
--
ALTER TABLE `us_fingerprint_assets`
  MODIFY `kFingerprintAssetID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_forms`
--
ALTER TABLE `us_forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `us_form_validation`
--
ALTER TABLE `us_form_validation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `us_form_views`
--
ALTER TABLE `us_form_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_gdpr`
--
ALTER TABLE `us_gdpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `us_ip_blacklist`
--
ALTER TABLE `us_ip_blacklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `us_ip_list`
--
ALTER TABLE `us_ip_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `us_ip_whitelist`
--
ALTER TABLE `us_ip_whitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `us_management`
--
ALTER TABLE `us_management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `us_plugins`
--
ALTER TABLE `us_plugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `us_plugin_hooks`
--
ALTER TABLE `us_plugin_hooks`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `us_saas_levels`
--
ALTER TABLE `us_saas_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_saas_orgs`
--
ALTER TABLE `us_saas_orgs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_user_sessions`
--
ALTER TABLE `us_user_sessions`
  MODIFY `kUserSessionID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
