<?php

//UserSpice User-Related functions
//Do not deactivate!

//Check if a user ID exists in the DB
if (!function_exists('userIdExists')) {
    function userIdExists(int $id)
    {
        $db = DB::getInstance();
        $query = $db->query('SELECT * FROM users WHERE id = ?', [$id]);
        $num_returns = $query->count();
        if ($num_returns == 1) {
            return true;
        } else {
            return false;
        }
    }
}

//Retrieve information for all users
if (!function_exists('fetchAllUsers')) {
    function fetchAllUsers(string $orderBy = null, bool $desc = false, bool $disabled = true)
    {
        $db = DB::getInstance();
        $q = 'SELECT * FROM users';
        if (!$disabled) {
            $q .= ' WHERE permissions=1';
        }
        if ($orderBy !== null) {
            if ($desc === true) {
                $q .= " ORDER BY $orderBy DESC";
            } else {
                $q .= " ORDER BY $orderBy";
            }
        }
        $query = $db->query($q);
        $results = $query->results();

        return $results;
    }
}

//Retrieve complete user information by username, token or ID
if (!function_exists('fetchUserDetails')) {
    function fetchUserDetails($username = null, string $token = null, $id = null)
    {
        $db = DB::getInstance();
        $column = $data = $results = null;

        if ($username !== null) {
            $column = 'username';
            $data = (string) $username;
        } elseif ((int) $id !== null) {
            $column = 'id';
            $data = (int) $id;
        }

        if ($column !== null && $data !== null) {
            $query = $db->query("SELECT * FROM users WHERE $column = ? LIMIT 1", [$data]);
            if ($query->count() == 1) {
                $results = $query->first();
            }
        }

        return $results;
    }
}

//Delete a defined array of users
if (!function_exists('deleteUsers')) {
    function deleteUsers($users = [])
    {
        global $abs_us_root, $us_url_root;
        $db = DB::getInstance();
        $i = 0;
        foreach ($users as $id) {
            if ((int) $id !== null) {
                $query1 = $db->query('DELETE FROM users WHERE id = ?', [(int) $id]);
                $query2 = $db->query('DELETE FROM user_permission_matches WHERE user_id = ?', [(int) $id]);
                if (file_exists($abs_us_root.$us_url_root.'usersc/scripts/after_user_deletion.php')) {
                    include $abs_us_root.$us_url_root.'usersc/scripts/after_user_deletion.php';
                }
                ++$i;
            }
        }

        return $i;
    }
}

if (!function_exists('echouser')) {
    function echouser($id, $echoType = null)
    {
        $db = DB::getInstance();

        $id = (int) $id;

        if ($echoType !== null) {
            $echoType = (int) $echoType;
        } else {
            $settingsQ = $db->query('SELECT echouser FROM settings');
            $settings = $settingsQ->first();
            $echoType = $settings->echouser;
        }

        if ($echoType == 0) {
            $query = $db->query('SELECT fname,lname FROM users WHERE id = ? LIMIT 1', [$id]);
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();
                echo $results->fname.' '.$results->lname;
            } else {
                echo 'Unknown';
            }
        }

        if ($echoType == 1) {
            $query = $db->query('SELECT username FROM users WHERE id = ? LIMIT 1', [$id]);
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();
                echo ucfirst($results->username);
            } else {
                echo '-';
            }
        }

        if ($echoType == 2) {
            $query = $db->query('SELECT username,fname,lname FROM users WHERE id = ? LIMIT 1', [$id]);
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();
                echo ucfirst($results->username).' ('.$results->fname.' '.$results->lname.')';
            } else {
                echo 'Unknown';
            }
        }

        if ($echoType == 3) {
            $query = $db->query('SELECT username,fname FROM users WHERE id = ? LIMIT 1', [$id]);
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();
                echo ucfirst($results->username).' ('.$results->fname.')';
            } else {
                echo 'Unknown';
            }
        }
        if ($echoType == 4) {
            $query = $db->query('SELECT fname,lname FROM users WHERE id = ? LIMIT 1', [$id]);
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();
                echo ucfirst($results->fname).' '.substr(ucfirst($results->lname), 0, 1);
            } else {
                echo 'Unknown';
            }
        }
    }
}

if (!function_exists('echousername')) {
    function echousername($id)
    {
        if ((int) $id === null) {
            return 'Unknown';
        }

        $db = DB::getInstance();
        $query = $db->query('SELECT username FROM users WHERE id = ? LIMIT 1', [$id]);
        $count = $query->count();
        if ($count > 0) {
            $results = $query->first();

            return $results->username;
        } else {
            return 'Unknown';
        }
    }
}

if (!function_exists('updateUser')) {
    //Update User
    function updateUser(string $column, $id, $value)
    {
        if ((int) $id !== null) {
            $id = (int) $id;
        } else {
            return null;
        }

        $db = DB::getInstance();
        $result = $db->query("UPDATE users SET $column = ? WHERE id = ?", [$value, $id]);

        return $result;
    }
}

if (!function_exists('fetchUserName')) {
    //Fetchs CONCAT of Fname Lname
    function fetchUserName($username = null, $token = null, $id = null)
    {
        $column = $data = $results = null;

        if ((string) $username != null) {
            $column = 'username';
            $data = (string) $username;
        } elseif ((int) $id != null) {
            $column = 'id';
            $data = (int) $id;
        }

        if (!is_null($column) && !is_null($data)) {
            $db = DB::getInstance();
            $query = $db->query("SELECT CONCAT(fname,' ',lname) AS name FROM users WHERE $column = $data LIMIT 1");
            $count = $query->count();
            if ($count > 0) {
                $results = $query->first();

                $results = $results->name;
            } else {
                $results = 'Unknown';
            }
        }

        return $results;
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin()
    {
        global $user;
        if (($user->isLoggedIn() && hasPerm([2], $user->data()->id)) || (isset($_SESSION['cloak_from']) && hasPerm([2], $_SESSION['cloak_from']))) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('name_from_id')) {
    function name_from_id($id)
    {
        $db = DB::getInstance();
        $query = $db->query('SELECT username FROM users WHERE id = ? LIMIT 1', [$id]);
        $count = $query->count();
        if ($count > 0) {
            $results = $query->first();

            return ucfirst($results->username);
        } else {
            return '-';
        }
    }
}
