;<?php die();?>
demo = 1