This "plugin" is where we store files for plugins that have been rolled into the core. There is nothing to manage here.
