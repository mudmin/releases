<?php
// Load Rate Limits and shared health score function
require_once $abs_us_root . $us_url_root . 'users/includes/rate_limits.php';
require_once $abs_us_root . $us_url_root . 'users/includes/rate_limit_health.php';
if (file_exists($abs_us_root . $us_url_root . 'usersc/includes/totp_requirements.php')) {
    include $abs_us_root . $us_url_root . 'usersc/includes/totp_requirements.php';
} else {
    include $abs_us_root . $us_url_root . 'users/includes/totp_requirements.php';
}

$secondWrite = Input::get('secondWrite');
if($secondWrite == "true"){
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Ensure $rateLimits is defined (set by rate_limits.php include)
if (!isset($rateLimits)) {
    $rateLimits = [];
}

// Check for default rate limits
$using_default_rate_limits = false;
if (isset($rateLimits['login_attempt']['ip_max']) && $rateLimits['login_attempt']['ip_max'] >= 10000) {
    $using_default_rate_limits = true;
}

// Rate limit health score (shared with rate limits page)
$rl_ip_config = ClientIP::config();
$rl_proxy_enabled = $rl_ip_config['enabled'];
if ($rl_ip_config['source'] === 'file') {
    $rl_proxy_count = count($rl_ip_config['trusted_proxies']);
} else {
    $rl_proxy_count = $db->query("SELECT COUNT(*) as count FROM us_rate_limit_proxy_settings WHERE enabled = 1")->first()->count ?? 0;
}
$mod_remoteip_active = function_exists('apache_get_modules') && in_array('mod_remoteip', apache_get_modules());
$upstream_resolved = false;
if (!$mod_remoteip_active && $rl_proxy_enabled) {
    $rl_remote_addr = Server::get('REMOTE_ADDR');
    if ($rl_remote_addr !== '') {
        foreach ($rl_ip_config['trusted_headers'] as $rl_header => $rl_priority) {
            $rl_server_key = 'HTTP_' . strtoupper(str_replace('-', '_', $rl_header));
            if (!empty($_SERVER[$rl_server_key])) {
                $rl_entries = explode(',', $_SERVER[$rl_server_key]);
                if (trim(end($rl_entries)) === $rl_remote_addr) {
                    $upstream_resolved = true;
                    break;
                }
            }
        }
    }
}
$rate_limit_health = calculateRateLimitHealth($rateLimits, $using_default_rate_limits, $rl_proxy_enabled, $rl_proxy_count);
$rl_health_color = $rate_limit_health >= 80 ? 'success' : ($rate_limit_health >= 60 ? 'warning' : 'danger');

// Get current versions and track info
$versionsQ = $db->query("SELECT * FROM us_versions WHERE id = 1");
$versions = $versionsQ->first();

$current_track = $settings->bleeding_edge;
$track_names = [0 => 'Stable', 1 => 'Bleeding Edge', 2 => 'Experimental'];
$track_colors = [0 => 'success', 1 => 'warning', 2 => 'danger'];

// Get PHP version info
$phpver = phpversion();
$parts = explode('.', $phpver);
$major_minor_version = $parts[0] . '.' . $parts[1];

//check if PHP version is known to have issues
$is_bad_php = ($db->query("SELECT version FROM us_php_known_bad WHERE `version` = ?", [$phpver])->count() > 0) ? true : false;

$eol_checkQ = $db->query("SELECT eol_date FROM us_php_eol WHERE release_version = ?", [$major_minor_version]);
$eol_checkC = $eol_checkQ->count();

$php_status = 'success';
$php_badge = '';
if ($eol_checkC > 0) {
    $eol_check = $eol_checkQ->first();
    $eol_date = strtotime($eol_check->eol_date);
    $today = strtotime(date("Y-m-d"));

    if ($today > $eol_date) {
        $php_status = 'danger';
        $php_badge = '<span class="badge bg-danger ms-2">EOL</span>';
    } elseif ($today > strtotime("-3 months", $eol_date)) {
        $php_status = 'warning';
        $php_badge = '<span class="badge bg-warning ms-2">EOL&nbsp;Soon</span>';
    }
}

// Passkey RP ID evaluation
$expected_rpid = fetchExpectedRPID();
$defined_rpid  = defined('PASSKEY_RP_ID') ? constant('PASSKEY_RP_ID') : null;
$rpid_status   = 'success';
$rpid_badge    = '<span class="badge bg-success">OK</span>';
$rpid_message  = '';
$show_write_button = false;

if ($defined_rpid === null) {
    $rpid_status  = 'danger';
    $rpid_badge   = '<span class="badge bg-danger ms-2">Not&nbsp;Defined</span>';
    $rpid_message = 'Passkeys cannot function until you define PASSKEY_RP_ID.';
    $show_write_button = true;
} elseif (is_array($defined_rpid)) {
    /** @var array<mixed> $defined_rpid */
    if (!in_array($expected_rpid, $defined_rpid, true)) {
        $rpid_status  = 'danger';
        $rpid_badge   = '<span class="badge bg-danger ms-2">Mismatch</span>';
        $rpid_message = 'Current host ' . $expected_rpid . ' is not present in your RP ID array.';
        $show_write_button = true;
    } elseif (count($defined_rpid) > 1) {
        $rpid_status  = 'warning';
        $rpid_badge   = '<span class="badge bg-warning ms-2">Multiple</span>';
        $rpid_message = 'Your RP ID array contains multiple domains. Ensure each entry is required.';
    }
} else {
    if ($defined_rpid !== $expected_rpid) {
        $rpid_status  = 'danger';
        $rpid_badge   = '<span class="badge bg-danger ms-2">Mismatch</span>';
        $rpid_message = 'Defined RP ID (' . $defined_rpid . ') does not match current host (' . $expected_rpid . ').';
        $show_write_button = true;
    }
}

// Resolve EXTRA_CURL_SECURITY once so PHPStan can reason about the value
$extra_curl_security_enabled = defined('EXTRA_CURL_SECURITY') && constant('EXTRA_CURL_SECURITY') === true;

// Backup files generated by the security dashboard fixers. Used by the unified
// dismiss/delete handler, the recommendation cards, and the modal generator.
$backup_configs = [
    'root'    => ['path' => 'z_us_root.BACKUP.php',                        'label' => 'z_us_root.php'],
    'init'    => ['path' => 'users/init.BACKUP.php',                       'label' => 'users/init.php'],
    'headers' => ['path' => 'usersc/includes/security_headers.BACKUP.php', 'label' => 'usersc/includes/security_headers.php'],
    'curl'    => ['path' => 'users/init.CURL_BACKUP.php',                  'label' => 'users/init.php (extra cURL security)'],
];

// Check OAuth providers
$oauthProviders = 0;
$oauthFiles = ['facebook.php', 'google.php', 'github.php', 'twitter.php', 'linkedin.php'];
foreach ($oauthFiles as $file) {
    if (file_exists($abs_us_root . $us_url_root . 'users/classes/oauth/' . $file)) {
        $oauthProviders++;
    }
}

// Check password strength rule enforcement
$pw_enforce_rules = 1;
$pwQ = $db->query("SELECT enforce_rules FROM us_password_strength");
if ($pwQ->count() > 0) {
    $pw_enforce_rules = (int)$pwQ->first()->enforce_rules;
}

// Check email configuration
$email_configured = false;
$emailQ = $db->query("SELECT * FROM email WHERE id = 1");
if ($emailQ->count() > 0) {
    $email = $emailQ->first();
    $email_configured = (!empty($email->smtp_server) || !empty($email->email_login));
}

// Check security headers
function check_security_headers()
{
    // Dynamically verify that the outgoing response actually contains the headers

    $expected = [
        'x-frame-options'           => false,
        'x-content-type-options'    => false,
        'x-xss-protection'          => false,
        'strict-transport-security' => false,
        'referrer-policy'           => false,
    ];

    // headers_list() returns headers queued to be sent for this request
    foreach (headers_list() as $headerLine) {
        [$name, $value] = array_pad(explode(':', $headerLine, 2), 2, null);
        $name = strtolower(trim($name));
        if (isset($expected[$name])) {
            $expected[$name] = true;
        }
    }

    return $expected;
}

/**
 * Returns the site’s Content-Security-Policy status.
 *
 * @return array [
 * 'enforced'    => string|null, // the CSP header value if present
 * 'report_only' => string|null  // the CSP-RO header value if present
 * ]
 */
function detectCSP(): array
{
    $enforced    = null;
    $reportOnly  = null;

    foreach (headers_list() as $h) {
        if (stripos($h, 'Content-Security-Policy:') === 0) {
            $enforced = trim(substr($h, 24));              // 24 = strlen('Content-Security-Policy:')
        } elseif (stripos($h, 'Content-Security-Policy-Report-Only:') === 0) {
            $reportOnly = trim(substr($h, 34));            // 34 = strlen('Content-Security-Policy-Report-Only:')
        }
    }

    return ['enforced' => $enforced ?: null, 'report_only' => $reportOnly ?: null];
}
$cspInfo      = detectCSP();
$cspConfigured = !empty($cspInfo['enforced']) || !empty($cspInfo['report_only']);
$security_headers = check_security_headers();
$headers_configured = count(array_filter($security_headers));

// Handle write_rpid request
if (!empty($_POST) && isset($_POST['write_rpid'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }
    $result = writeRpidToInit($expected_rpid);
    if ($result) {
        logger($user->data()->id, 'Security', 'Updated PASSKEY_RP_ID to ' . $expected_rpid);
        usSuccess('PASSKEY_RP_ID written to users/init.php');
    } else {
        usError('Could not write PASSKEY_RP_ID automatically. Please edit users/init.php manually.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security&secondWrite=true");
}

// Function to write or update RP ID in users/init.php
function writeRpidToInit(string $rpid): bool
{
    global $abs_us_root, $us_url_root;
    $initFile = $abs_us_root . $us_url_root . 'users/init.php';

    if (!is_writable($initFile)) {
        return false;
    }

    $contents = file_get_contents($initFile);
    if ($contents === false) {
        return false;
    }

    $defineStatement = "define('PASSKEY_RP_ID', '" . addslashes($rpid) . "');";

    if (preg_match('/define\s*\(\s*["\']PASSKEY_RP_ID["\']\s*,/i', $contents)) {
        // Replace existing definition (first occurrence only)
        $newContents = preg_replace(
            '/define\s*\(\s*["\']PASSKEY_RP_ID["\']\s*,\s*[^;]*;?/i',
            $defineStatement,
            $contents,
            1
        );
    } else {
        // Insert after autoloader require
        $pattern = '/require_once\s*["\']classes\/class\.autoloader\.php["\']\s*;/i';
        if (preg_match($pattern, $contents)) {
            $newContents = preg_replace(
                $pattern,
                "$0\n\n// Passkey Relying Party ID\n{$defineStatement}",
                $contents,
                1
            );
        } else {
            // Fallback: append to the end of the file
            $newContents = $contents . "\n\n// Passkey Relying Party ID\n{$defineStatement}\n";
        }
    }

    $result = file_put_contents($initFile, $newContents) !== false;

    // Invalidate opcache so the new definition is picked up on next request
    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($initFile, true);
    }

    return $result;
}

// TOTP Configuration Checks
if (!function_exists('totp_is_crypto_available')) {
    require_once $abs_us_root . $us_url_root . 'users/helpers/encryption.php';
}

$min_totp_php_version = '8.2.0';
$totpKeyFile = $abs_us_root . $us_url_root . 'usersc/includes/totp_key.php';
$totp_status = ['level' => 'success', 'messages' => []];

// 1. Check PHP Version
$phpver_ok = version_compare(phpversion(), $min_totp_php_version, '>=');
if (!$phpver_ok) {
    $totp_status['level'] = 'danger';
    $totp_status['messages'][] = "TOTP requires PHP version {$min_totp_php_version} or higher. Your version is " . phpversion() . ".";
}

// 2. Check for Crypto Backend (Sodium or OpenSSL)
$crypto_ok = totp_is_crypto_available();
if (!$crypto_ok && $phpver_ok) {
    $totp_status['level'] = 'danger';
    $totp_status['messages'][] = "No suitable encryption backend found. The 'sodium' extension or OpenSSL with AES-256-GCM support is required.";
}

// 3. Check Key File and Directory
$key_file_exists = file_exists($totpKeyFile);
$key_dir_writable = is_writable(dirname($totpKeyFile));
$key_valid = false;
$key_readable = true;
$key_engine_info = '';

if ($key_file_exists) {
    // totp_key_file_status() checks readability before including the file, so a
    // permissions problem is reported as such instead of fataling (a bare
    // include of an unreadable file is an uncatchable E_COMPILE_ERROR) or being
    // silently mislabelled "invalid" by an @-suppressed include.
    $key_status = totp_key_file_status($totpKeyFile);
    $key_readable = ($key_status['state'] !== 'unreadable');

    if ($key_status['state'] === 'ok') {
        $key_valid = true;
        try {
            $currentEngine = totp_get_active_crypto_engine();
            $storedEngine = defined('TOTP_CRYPTO_ENGINE') ? TOTP_CRYPTO_ENGINE : 'unknown';
            $key_engine_info = "Key created with '{$storedEngine}'. Current server engine is '{$currentEngine}'.";
            if ($currentEngine !== $storedEngine && $storedEngine !== 'unknown') {
                $totp_status['messages'][] = ['text' => "Your server's crypto engine has changed. Existing TOTP secrets will be automatically re-encrypted on next use.", 'level' => 'info'];
            }
        } catch (Throwable $e) {
            $totp_status['level'] = 'danger';
            $totp_status['messages'][] = "Crypto engine error: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $totp_status['level'] = 'danger';
        $detail = htmlspecialchars($key_status['message']);
        if ($key_status['fix'] !== '') {
            $detail .= '<br>' . htmlspecialchars($key_status['fix']);
        }
        if ($key_status['command'] !== '') {
            $detail .= '<br><code>' . htmlspecialchars($key_status['command']) . '</code>';
        }
        $totp_status['messages'][] = $detail;
    }
} else {
    if ($settings->totp > 0) {
        $totp_status['level'] = 'warning';
        $totp_status['messages'][] = "TOTP is enabled, but the encryption key file is missing.";
    }
}

// Handle TOTP key generation request
if (!empty($_POST) && isset($_POST['generate_totp_key'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }
    if (!$key_file_exists && $key_dir_writable) {
        try {
            totp_init_encryption($totpKeyFile, false);
            logger($user->data()->id, 'Security', 'Generated new TOTP encryption key.');
            usSuccess('Successfully generated TOTP encryption key file.');
        } catch (RuntimeException $e) {
            usError('Could not generate the TOTP key file automatically.');
        }
    } else {
        usError('Cannot generate key file. It may already exist or the directory is not writable.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security#totp-config-card");
}


// Security toggles handler
if (!empty($_POST) && isset($_POST['toggle_security_setting'])) {
    if (!Token::check(Input::get('csrf'))) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }
    $setting = Input::get('setting');
    $current_val = $settings->$setting;

    // no_passwords now has 3 states (0, 1, 2), so it shouldn't be toggled from here
    // Redirect to general settings page instead
    if ($setting == 'no_passwords') {
        usError("Password login settings have multiple options. Please use the General Settings page to configure this setting.");
        Redirect::to($us_url_root . 'users/admin.php?view=general');
    }

    $new_val = ($current_val == 1) ? 0 : 1;

    // Some settings have special considerations
    $message = "Setting {$setting} updated.";
    if ($setting == 'force_ssl' && $new_val == 1) {
        $message = "Force HTTPS enabled. Ensure your SSL certificate is valid and properly configured.";
    }

    $db->update('settings', 1, [$setting => $new_val]);
    usSuccess($message);
    logger($user->data()->id, 'Security', "Toggled {$setting} to {$new_val}");
    Redirect::to($us_url_root . 'users/admin.php?view=security');
}

// Function to fix $_SERVER usage in z_us_root.php (only DOCUMENT_ROOT and PHP_SELF)
function fixServerVariableUsageRoot($file_path, $backup_path): bool {
    if (!file_exists($file_path) || !is_writable($file_path)) {
        return false;
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return false;
    }

    // Create backup first
    if (file_put_contents($backup_path, $contents) === false) {
        return false;
    }

    // Only replace DOCUMENT_ROOT and PHP_SELF
    $newContents = preg_replace(
        '/\$_SERVER\s*\[\s*[\'"]DOCUMENT_ROOT[\'"]\s*\]/',
        "Server::get('DOCUMENT_ROOT')",
        $contents
    );
    $newContents = preg_replace(
        '/\$_SERVER\s*\[\s*[\'"]PHP_SELF[\'"]\s*\]/',
        "Server::get('PHP_SELF')",
        $newContents
    );

    if ($newContents === $contents) {
        // No changes made, remove backup
        @unlink($backup_path);
        return false;
    }

    $result = file_put_contents($file_path, $newContents) !== false;

    // Invalidate opcache so the changes are picked up on next request
    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($file_path, true);
    }

    return $result;
}

// Function to fix $_SERVER usage in users/init.php and add missing definitions
function fixServerVariableUsageInit($file_path, $backup_path): bool {
    if (!file_exists($file_path) || !is_writable($file_path)) {
        return false;
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return false;
    }

    // Create backup first
    if (file_put_contents($backup_path, $contents) === false) {
        return false;
    }

    $newContents = $contents;

    // Replace $_SERVER['DOCUMENT_ROOT'] and $_SERVER['PHP_SELF']
    $newContents = preg_replace(
        '/\$_SERVER\s*\[\s*[\'"]DOCUMENT_ROOT[\'"]\s*\]/',
        "Server::get('DOCUMENT_ROOT')",
        $newContents
    );
    $newContents = preg_replace(
        '/\$_SERVER\s*\[\s*[\'"]PHP_SELF[\'"]\s*\]/',
        "Server::get('PHP_SELF')",
        $newContents
    );

    // Add missing definitions after <?php
    $additions = [];

    // Check for USERSPICE_ACTIVE_LOGGING
    if (strpos($newContents, 'USERSPICE_ACTIVE_LOGGING') === false) {
        $additions[] = "define('USERSPICE_ACTIVE_LOGGING', false);";
    }

    // Check for $noPHPInfo
    if (strpos($newContents, '$noPHPInfo') === false) {
        $additions[] = '$noPHPInfo = false;';
    }

    // Insert additions after <?php if any
    if (!empty($additions)) {
        $additionsText = "\n" . implode("\n", $additions);
        $newContents = preg_replace('/^<\?php\s*/', "<?php" . $additionsText . "\n", $newContents, 1);
    }

    // Add $userspice_nonce before loader.php if missing
    if (strpos($newContents, '$userspice_nonce') === false) {
        $newContents = preg_replace(
            '/(require_once\s+\$abs_us_root\s*\.\s*\$us_url_root\s*\.\s*[\'"]users\/includes\/loader\.php[\'"]\s*;)/',
            "\$userspice_nonce = base64_encode(random_bytes(16));\n$1",
            $newContents
        );
    }

    // Add $system_messages_justify before loader.php if missing
    if (strpos($newContents, '$system_messages_justify') === false) {
        $newContents = preg_replace(
            '/(require_once\s+\$abs_us_root\s*\.\s*\$us_url_root\s*\.\s*[\'"]users\/includes\/loader\.php[\'"]\s*;)/',
            "\$system_messages_justify = \"right\";\n$1",
            $newContents
        );
    }

    // Add EXTRA_CURL_SECURITY before loader.php if missing
    if (strpos($newContents, 'EXTRA_CURL_SECURITY') === false) {
        $newContents = preg_replace(
            '/(require_once\s+\$abs_us_root\s*\.\s*\$us_url_root\s*\.\s*[\'"]users\/includes\/loader\.php[\'"]\s*;)/',
            "// Forces SSL verification in cURL requests to UserSpice API\n// Will most likely break on localhost or self-signed certificates\ndefine('EXTRA_CURL_SECURITY', false);\n$1",
            $newContents
        );
    }

    if ($newContents === $contents) {
        // No changes made, remove backup
        @unlink($backup_path);
        return false;
    }

    $result = file_put_contents($file_path, $newContents) !== false;

    // Invalidate opcache so the changes are picked up on next request
    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($file_path, true);
    }

    return $result;
}

// Handle fix $_SERVER request for z_us_root.php
if (!empty($_POST) && isset($_POST['fix_server_root'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'z_us_root.php';
    $backup_path = $abs_us_root . $us_url_root . 'z_us_root.BACKUP.php';

    if (fixServerVariableUsageRoot($file_path, $backup_path)) {
        logger($user->data()->id, 'Security', 'Fixed $_SERVER usage in z_us_root.php (backup created)');
        usSuccess('Successfully replaced $_SERVER with Server::get() in z_us_root.php. A backup was created at z_us_root.BACKUP.php');
    } else {
        usError('Could not fix the file automatically. The file may not be writable or no changes were needed.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle fix $_SERVER request for users/init.php
if (!empty($_POST) && isset($_POST['fix_server_init'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'users/init.php';
    $backup_path = $abs_us_root . $us_url_root . 'users/init.BACKUP.php';

    if (fixServerVariableUsageInit($file_path, $backup_path)) {
        logger($user->data()->id, 'Security', 'Fixed $_SERVER usage in users/init.php (backup created)');
        usSuccess('Successfully updated users/init.php. A backup was created at users/init.BACKUP.php');
    } else {
        usError('Could not fix the file automatically. The file may not be writable or no changes were needed.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle dismiss (rename to .SAVE.php) or delete for any registered backup file
if (!empty($_POST) && isset($_POST['handle_backup'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $backup_id = $_POST['backup_id'] ?? '';
    $action    = $_POST['backup_action'] ?? '';

    if (!isset($backup_configs[$backup_id]) || !in_array($action, ['dismiss', 'delete'], true)) {
        usError('Invalid backup action.');
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $cfg         = $backup_configs[$backup_id];
    $backup_path = $abs_us_root . $us_url_root . $cfg['path'];

    // nosemgrep: php.lang.security.injection.tainted-filename.tainted-filename -- $backup_path is built from $cfg['path'], a hardcoded literal in $backup_configs; $backup_id is only an array key, validated by isset() above. Not a tainted filename.
    if (!file_exists($backup_path)) {
        usError('Backup file not found.');
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    if ($action === 'delete') {
        // nosemgrep: php.lang.security.injection.tainted-filename.tainted-filename -- $backup_path is built from $cfg['path'], a hardcoded literal in $backup_configs; $backup_id is only an array key, validated by isset() above. Not a tainted filename.
        if (@unlink($backup_path)) {
            logger($user->data()->id, 'Security', "Deleted backup file: {$cfg['path']}");
            usSuccess("Backup file <code>" . htmlspecialchars($cfg['path']) . "</code> has been deleted.");
        } else {
            usError('Could not delete the backup file. Check file permissions.');
        }
    } else { // dismiss
        $save_path = preg_replace('/\.php$/', '.SAVE.php', $backup_path);
        if (@rename($backup_path, $save_path)) {
            logger($user->data()->id, 'Security', "Dismissed backup file: {$cfg['path']} (renamed)");
            usSuccess("Backup dismissed. The file has been renamed to <code>" . htmlspecialchars(basename($save_path)) . "</code>.");
        } else {
            usError('Could not dismiss the backup file.');
        }
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle fix $_SERVER request for security_headers.php
if (!empty($_POST) && isset($_POST['fix_server_headers'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'usersc/includes/security_headers.php';
    $backup_path = $abs_us_root . $us_url_root . 'usersc/includes/security_headers.BACKUP.php';

    if (fixServerVariableUsageHeaders($file_path, $backup_path)) {
        logger($user->data()->id, 'Security', 'Fixed $_SERVER usage in security_headers.php (backup created)');
        usSuccess('Successfully replaced $_SERVER with Server::get() in security_headers.php. A backup was created at usersc/includes/security_headers.BACKUP.php');
    } else {
        usError('Could not fix the file automatically. The file may not be writable or no changes were needed.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle "fully deprecate" request - rename .php files in usersc/includes/deprecated/
// so the helpers.php loader (which globs *.php) stops including them. Files are
// renamed, not deleted, so the change is fully reversible.
if (!empty($_POST) && isset($_POST['deprecate_files'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $deprecatedDir = $abs_us_root . $us_url_root . 'usersc/includes/deprecated/';
    $phpFiles      = glob($deprecatedDir . '*.php') ?: [];
    $stamp         = date('Y-m-d');
    $renamed       = 0;
    $failed        = 0;

    foreach ($phpFiles as $phpFile) {
        $target = $phpFile . '_dep_on_' . $stamp;
        $suffix = 1;
        while (file_exists($target)) { // avoid clobbering a same-day re-run
            $target = $phpFile . '_dep_on_' . $stamp . '_' . $suffix;
            $suffix++;
        }
        if (@rename($phpFile, $target)) {
            $renamed++;
        } else {
            $failed++;
        }
    }

    if ($renamed > 0) {
        logger($user->data()->id, 'Security', "Fully deprecated {$renamed} file(s) in usersc/includes/deprecated/");
        usSuccess("{$renamed} deprecated file(s) renamed to .php_dep_on_{$stamp} and will no longer be loaded.");
    }
    if ($failed > 0) {
        usError("{$failed} file(s) in usersc/includes/deprecated/ could not be renamed. Check file permissions.");
    }
    if ($renamed === 0 && $failed === 0) {
        usError('No .php files were found in usersc/includes/deprecated/.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle adding session.cookie_samesite to init.php
if (!empty($_POST) && isset($_POST['fix_cookie_samesite'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'users/init.php';
    $backup_path = $abs_us_root . $us_url_root . 'users/init.BACKUP.php';
    if (file_exists($file_path) && is_writable($file_path)) {
        $contents = file_get_contents($file_path);
        if ($contents !== false && strpos($contents, 'session.cookie_samesite') === false) {
            // Create backup before making changes
            if (file_put_contents($backup_path, $contents) === false) {
                usError('Could not create backup of users/init.php. Aborting.');
                Redirect::to($us_url_root . "users/admin.php?view=security");
            }
            // Insert after require_once 'classes/class.autoloader.php';
            $anchor = "require_once 'classes/class.autoloader.php';";
            if (strpos($contents, $anchor) !== false) {
                $newContents = str_replace(
                    $anchor,
                    $anchor . "\nini_set('session.cookie_samesite', 'Lax');",
                    $contents
                );
                if (file_put_contents($file_path, $newContents) !== false) {
                    if (function_exists('opcache_invalidate')) {
                        opcache_invalidate($file_path, true);
                    }
                    logger($user->data()->id, 'Security', 'Added session.cookie_samesite to users/init.php (backup created)');
                    usSuccess("Added <code>ini_set('session.cookie_samesite', 'Lax')</code> to users/init.php. A backup was saved to users/init.BACKUP.php");
                } else {
                    usError('Could not write to users/init.php. Check file permissions.');
                }
            } else {
                usError('Could not find the expected anchor point in users/init.php. Please add <code>ini_set(\'session.cookie_samesite\', \'Lax\');</code> manually.');
            }
        } else {
            usSuccess('session.cookie_samesite is already set in users/init.php');
        }
    } else {
        usError('users/init.php not found or not writable.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle adding session.cookie_secure to init.php
if (!empty($_POST) && isset($_POST['fix_cookie_secure'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'users/init.php';
    $backup_path = $abs_us_root . $us_url_root . 'users/init.BACKUP.php';
    if (file_exists($file_path) && is_writable($file_path)) {
        $contents = file_get_contents($file_path);
        if ($contents !== false && strpos($contents, 'session.cookie_secure') === false) {
            // Create backup before making changes
            if (file_put_contents($backup_path, $contents) === false) {
                usError('Could not create backup of users/init.php. Aborting.');
                Redirect::to($us_url_root . "users/admin.php?view=security");
            }
            // Insert before session_start();
            $anchor = "session_start();";
            $secure_block = "if (Server::get('HTTPS') !== '' && Server::get('HTTPS') !== 'off') {\n\tini_set('session.cookie_secure', 1);\n}\n";
            if (strpos($contents, $anchor) !== false) {
                $newContents = str_replace(
                    $anchor,
                    $secure_block . $anchor,
                    $contents
                );
                if (file_put_contents($file_path, $newContents) !== false) {
                    if (function_exists('opcache_invalidate')) {
                        opcache_invalidate($file_path, true);
                    }
                    logger($user->data()->id, 'Security', 'Added session.cookie_secure to users/init.php (backup created)');
                    usSuccess("Added secure cookie detection to users/init.php. A backup was saved to users/init.BACKUP.php");
                } else {
                    usError('Could not write to users/init.php. Check file permissions.');
                }
            } else {
                usError('Could not find <code>session_start();</code> in users/init.php. Please add the secure cookie block manually.');
            }
        } else {
            usSuccess('session.cookie_secure is already set in users/init.php');
        }
    } else {
        usError('users/init.php not found or not writable.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Function to enable EXTRA_CURL_SECURITY in users/init.php
function enableExtraCurlSecurity($file_path, $backup_path): bool {
    if (!file_exists($file_path) || !is_writable($file_path)) {
        return false;
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return false;
    }

    // Check if already defined as true
    if (preg_match("/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*true\s*\)/", $contents)) {
        return false; // Already enabled
    }

    // Create backup first
    if (file_put_contents($backup_path, $contents) === false) {
        return false;
    }

    // If defined as false, change to true
    if (preg_match("/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*false\s*\)/", $contents)) {
        $newContents = preg_replace(
            "/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*false\s*\)/",
            "define('EXTRA_CURL_SECURITY', true)",
            $contents
        );
    } elseif (strpos($contents, 'EXTRA_CURL_SECURITY') !== false) {
        // Defined with a non-standard value (e.g. TRUE, 1, 0) — replace the entire define statement
        $newContents = preg_replace(
            "/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*[^)]*\)/",
            "define('EXTRA_CURL_SECURITY', true)",
            $contents
        );
    } else {
        // Not defined at all, add it before loader.php
        $newContents = preg_replace(
            '/(require_once\s+\$abs_us_root\s*\.\s*\$us_url_root\s*\.\s*[\'"]users\/includes\/loader\.php[\'"]\s*;)/',
            "// Forces SSL verification in cURL requests to UserSpice API\n// Will most likely break on localhost or self-signed certificates\ndefine('EXTRA_CURL_SECURITY', true);\n$1",
            $contents
        );
    }

    if ($newContents === $contents) {
        @unlink($backup_path);
        return false;
    }

    $result = file_put_contents($file_path, $newContents) !== false;

    // Invalidate opcache so the changes are picked up on next request
    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($file_path, true);
    }

    return $result;
}

// Function to disable EXTRA_CURL_SECURITY in users/init.php
function disableExtraCurlSecurity($file_path, $backup_path): bool {
    if (!file_exists($file_path) || !is_writable($file_path)) {
        return false;
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return false;
    }

    // Check if already defined as false or not defined
    if (!preg_match("/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*true\s*\)/", $contents)) {
        return false; // Already disabled or not defined
    }

    // Create backup first
    if (file_put_contents($backup_path, $contents) === false) {
        return false;
    }

    // Change true to false
    $newContents = preg_replace(
        "/define\s*\(\s*['\"]EXTRA_CURL_SECURITY['\"]\s*,\s*true\s*\)/",
        "define('EXTRA_CURL_SECURITY', false)",
        $contents
    );

    if ($newContents === $contents) {
        @unlink($backup_path);
        return false;
    }

    $result = file_put_contents($file_path, $newContents) !== false;

    // Invalidate opcache so the changes are picked up on next request
    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($file_path, true);
    }

    return $result;
}

// Handle enable EXTRA_CURL_SECURITY request
if (!empty($_POST) && isset($_POST['enable_curl_security'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'users/init.php';
    $backup_path = $abs_us_root . $us_url_root . 'users/init.CURL_BACKUP.php';

    if (enableExtraCurlSecurity($file_path, $backup_path)) {
        logger($user->data()->id, 'Security', 'Enabled EXTRA_CURL_SECURITY in users/init.php (backup created)');
        usSuccess('Successfully enabled EXTRA_CURL_SECURITY. A backup was created at users/init.CURL_BACKUP.php');
    } else {
        usError('Could not enable the setting automatically. The file may not be writable or no changes were needed.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle disable EXTRA_CURL_SECURITY request (for localhost)
if (!empty($_POST) && isset($_POST['disable_curl_security'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    // Verify user typed YES
    $confirmation = trim($_POST['disable_curl_confirm'] ?? '');
    if (strtoupper($confirmation) !== 'YES') {
        usError('You must type YES to confirm disabling extra cURL security.');
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }

    $file_path = $abs_us_root . $us_url_root . 'users/init.php';
    $backup_path = $abs_us_root . $us_url_root . 'users/init.CURL_BACKUP.php';

    if (disableExtraCurlSecurity($file_path, $backup_path)) {
        logger($user->data()->id, 'Security', 'Disabled EXTRA_CURL_SECURITY in users/init.php (backup created)');
        usSuccess('Successfully disabled EXTRA_CURL_SECURITY. A backup was created at users/init.CURL_BACKUP.php');
    } else {
        usError('Could not disable the setting automatically. The file may not be writable or no changes were needed.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle delete default README.md
if (!empty($_POST) && isset($_POST['delete_default_readme'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }
    $readme_path = $abs_us_root . $us_url_root . 'README.md';
    if (file_exists($readme_path) && @unlink($readme_path)) {
        logger($user->data()->id, 'Security', 'Deleted default README.md from site root');
        usSuccess('README.md has been deleted.');
    } else {
        usError('Could not delete README.md. Check file permissions.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Handle delete default SECURITY.md
if (!empty($_POST) && isset($_POST['delete_default_securitymd'])) {
    if (!Token::check($_POST['csrf'])) {
        usError("Token failed");
        Redirect::to($us_url_root . "users/admin.php?view=security");
    }
    $security_path = $abs_us_root . $us_url_root . 'SECURITY.md';
    if (file_exists($security_path) && @unlink($security_path)) {
        logger($user->data()->id, 'Security', 'Deleted default SECURITY.md from site root');
        usSuccess('SECURITY.md has been deleted.');
    } else {
        usError('Could not delete SECURITY.md. Check file permissions.');
    }
    Redirect::to($us_url_root . "users/admin.php?view=security");
}

// Check for $_SERVER usage in users/init.php - only fixable if it's exactly DOCUMENT_ROOT and PHP_SELF
function checkServerVariableUsageInit($file_path) {
    if (!file_exists($file_path)) {
        return ['found' => false, 'error' => 'File not found', 'fixable' => false];
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return ['found' => false, 'error' => 'Could not read file', 'fixable' => false];
    }

    // Remove comments to avoid false positives
    $contentsNoComments = preg_replace('#//.*$#m', '', $contents);
    $contentsNoComments = preg_replace('#/\*.*?\*/#s', '', $contentsNoComments);

    // Find all $_SERVER usages
    preg_match_all('/\$_SERVER\s*\[\s*[\'"]([^\'"]+)[\'"]\s*\]/', $contentsNoComments, $matches);

    if (empty($matches[1])) {
        return ['found' => false, 'error' => null, 'fixable' => false];
    }

    // Check if all usages are only DOCUMENT_ROOT or PHP_SELF
    $allowed = ['DOCUMENT_ROOT', 'PHP_SELF'];
    $allAllowed = true;
    foreach ($matches[1] as $key) {
        if (!in_array($key, $allowed)) {
            $allAllowed = false;
            break;
        }
    }

    return [
        'found' => true,
        'error' => null,
        'fixable' => $allAllowed,
        'keys_found' => array_unique($matches[1])
    ];
}

// Special check for z_us_root.php - only fixable if it's exactly DOCUMENT_ROOT and PHP_SELF
function checkServerVariableUsageRoot($file_path) {
    if (!file_exists($file_path)) {
        return ['found' => false, 'error' => 'File not found', 'fixable' => false];
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return ['found' => false, 'error' => 'Could not read file', 'fixable' => false];
    }

    // Remove comments to avoid false positives
    $contentsNoComments = preg_replace('#//.*$#m', '', $contents);
    $contentsNoComments = preg_replace('#/\*.*?\*/#s', '', $contentsNoComments);

    // Find all $_SERVER usages
    preg_match_all('/\$_SERVER\s*\[\s*[\'"]([^\'"]+)[\'"]\s*\]/', $contentsNoComments, $matches);

    if (empty($matches[1])) {
        return ['found' => false, 'error' => null, 'fixable' => false];
    }

    // Check if all usages are only DOCUMENT_ROOT or PHP_SELF
    $allowed = ['DOCUMENT_ROOT', 'PHP_SELF'];
    $allAllowed = true;
    foreach ($matches[1] as $key) {
        if (!in_array($key, $allowed)) {
            $allAllowed = false;
            break;
        }
    }

    return [
        'found' => true,
        'error' => null,
        'fixable' => $allAllowed,
        'keys_found' => array_unique($matches[1])
    ];
}

// Check for raw $_SERVER usage in security_headers.php - only fixable if the exact default line is present
function checkServerVariableUsageHeaders($file_path) {
    if (!file_exists($file_path)) {
        return ['found' => false, 'error' => 'File not found', 'fixable' => false];
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return ['found' => false, 'error' => 'Could not read file', 'fixable' => false];
    }

    // Check for the exact default line that uses raw $_SERVER
    $exactMatch = '$protocol = (!empty($_SERVER[\'HTTPS\']) && $_SERVER[\'HTTPS\'] !== \'off\' || $_SERVER[\'SERVER_PORT\'] == 443) ? "https://" : "http://";';

    if (strpos($contents, $exactMatch) !== false) {
        return ['found' => true, 'error' => null, 'fixable' => true];
    }

    // Check if there are any $_SERVER usages at all (outside comments)
    $contentsNoComments = preg_replace('#//.*$#m', '', $contents);
    $contentsNoComments = preg_replace('#/\*.*?\*/#s', '', $contentsNoComments);

    if (preg_match('/\$_SERVER\s*\[/', $contentsNoComments)) {
        return ['found' => true, 'error' => null, 'fixable' => false];
    }

    return ['found' => false, 'error' => null, 'fixable' => false];
}

// Function to fix $_SERVER usage in security_headers.php
function fixServerVariableUsageHeaders($file_path, $backup_path): bool {
    if (!file_exists($file_path) || !is_writable($file_path)) {
        return false;
    }
    $contents = file_get_contents($file_path);
    if ($contents === false) {
        return false;
    }

    $oldLine = '$protocol = (!empty($_SERVER[\'HTTPS\']) && $_SERVER[\'HTTPS\'] !== \'off\' || $_SERVER[\'SERVER_PORT\'] == 443) ? "https://" : "http://";';
    $newLine = '$protocol = (Server::get(\'HTTPS\') !== \'\' || Server::get(\'SERVER_PORT\') == 443) ? "https://" : "http://";';

    if (strpos($contents, $oldLine) === false) {
        return false;
    }

    // Create backup first
    if (file_put_contents($backup_path, $contents) === false) {
        return false;
    }

    $newContents = str_replace($oldLine, $newLine, $contents);

    if ($newContents === $contents) {
        @unlink($backup_path);
        return false;
    }

    $result = file_put_contents($file_path, $newContents) !== false;

    if ($result && function_exists('opcache_invalidate')) {
        opcache_invalidate($file_path, true);
    }

    return $result;
}

$server_var_init = checkServerVariableUsageInit($abs_us_root . $us_url_root . 'users/init.php');
$server_var_root = checkServerVariableUsageRoot($abs_us_root . $us_url_root . 'z_us_root.php');
$server_var_headers = checkServerVariableUsageHeaders($abs_us_root . $us_url_root . 'usersc/includes/security_headers.php');

// Check for backup files
$root_backup_exists = file_exists($abs_us_root . $us_url_root . 'z_us_root.BACKUP.php');
$init_backup_exists = file_exists($abs_us_root . $us_url_root . 'users/init.BACKUP.php');
$headers_backup_exists = file_exists($abs_us_root . $us_url_root . 'usersc/includes/security_headers.BACKUP.php');
$curl_backup_exists = file_exists($abs_us_root . $us_url_root . 'users/init.CURL_BACKUP.php');

// Check for default README.md and SECURITY.md in site root
$default_readme_hash = 'db72debef0da47edfceffb6eadd9b01b';
$default_security_hash = '41c3422e56e62772dcba551514a5acec';
$readme_path = $abs_us_root . $us_url_root . 'README.md';
$security_md_path = $abs_us_root . $us_url_root . 'SECURITY.md';
$has_default_readme = file_exists($readme_path) && md5_file($readme_path) === $default_readme_hash;
$has_default_security = file_exists($security_md_path) && md5_file($security_md_path) === $default_security_hash;

// Check for session cookie security settings in init.php
$init_file_path = $abs_us_root . $us_url_root . 'users/init.php';
$init_has_samesite = false;
$init_has_cookie_secure = false;
$proxy_enabled = $rl_proxy_enabled;
if (file_exists($init_file_path)) {
    $init_contents = file_get_contents($init_file_path);
    if ($init_contents !== false) {
        $init_has_samesite = (strpos($init_contents, 'session.cookie_samesite') !== false);
        $init_has_cookie_secure = (strpos($init_contents, 'session.cookie_secure') !== false);
    }
}

// Calculate overall security score
function calculateSecurityScore($settings, $php_status, $rpid_status, $email_configured, $headers_configured, $is_updated, $using_default_rate_limits, $server_var_init, $server_var_root, $server_var_headers, $init_has_samesite = true, $init_has_cookie_secure = true, $extra_curl_security_enabled = true, $deprecated_files_present = false, $cloak_cred_mgmt_enabled = false)
{
    $score = 100; // Start at 100 and deduct for missing items
    $max_score = 100;

    // HTTPS (15 points) - Deduct if not using HTTPS
    if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') $score -= 15;

    // Session cookie SameSite (5 points) - Deduct if missing
    if (!$init_has_samesite) $score -= 5;

    // Session cookie Secure flag (5 points) - Deduct if missing (only when not behind proxy)
    if (!$init_has_cookie_secure) $score -= 5;

    // PHP Version (10 points) - Deduct based on PHP status
    if ($php_status === 'danger') $score -= 10;
    elseif ($php_status === 'warning') $score -= 5;

    // UserSpice Up to Date (10 points) - Deduct if outdated
    if (!$is_updated) $score -= 10;

    // Email configured (10 points) - Deduct if not configured
    if (!$email_configured) $score -= 10;

    // Rate limiting customized (10 points) - Deduct if using defaults
    if ($using_default_rate_limits) {
        $score -= 10;
    }

    // Force SSL setting (10 points) - Deduct if not forced
    if (!$settings->force_ssl) $score -= 10;

    // Passkey configuration (10 points) - Deduct based on status
    if ($rpid_status === 'danger') $score -= 10;
    elseif ($rpid_status === 'warning') $score -= 5;

    // TOTP enabled (5 points) - Deduct if disabled
    if ($settings->totp == 0) $score -= 5;

    // Passkeys enabled (5 points) - Deduct if disabled
    if (!$settings->passkeys) $score -= 5;

    // Email login availability is intentionally NOT scored. Whether to allow
    // login by email address is a usability choice, not a hardening step, so it
    // is surfaced as an informational recommendation instead of a deduction.

    // Security headers (10 points) - Deduct 2 points per missing header
    $score -= ((5 - $headers_configured) * 2);

    // Extra cURL security (3 points) - Deduct if not enabled
    if (!$extra_curl_security_enabled) $score -= 3;

    // $_SERVER usage in critical files (5 points each)
    if ($server_var_init['found']) $score -= 5;
    if ($server_var_root['found']) $score -= 5;
    if ($server_var_headers['found']) $score -= 5;

    // Deprecated files still active (10 points) - .php files left in
    // usersc/includes/deprecated/ are still auto-loaded by helpers.php
    if ($deprecated_files_present) $score -= 10;

    // Cloaked admins allowed to manage another user's passkeys/TOTP (5 points) -
    // a deliberate relaxation of step-up protection, off by default.
    if ($cloak_cred_mgmt_enabled) $score -= 5;

    return max($score, 0); // Don't go below 0
}

$is_updated = version_compare($user_spice_ver, $versions->release_version ?? "", '>=');
// Detect leftover .php files in usersc/includes/deprecated/ - these are still
// auto-loaded by helpers.php and represent deprecated code running in production.
$deprecated_php_files     = glob($abs_us_root . $us_url_root . 'usersc/includes/deprecated/*.php') ?: [];
$deprecated_files_present = !empty($deprecated_php_files);

// Cloak credential-management policy (usersc/includes/custom_cloak_policy.php).
// Off by default; when a site owner opts in, a cloaked admin can manage the
// impersonated user's passkeys/TOTP. Surface it as a deliberate relaxation.
$cloak_passkey_mgmt      = function_exists('cloakCanManage') && cloakCanManage('passkeys');
$cloak_totp_mgmt         = function_exists('cloakCanManage') && cloakCanManage('totp');
$cloak_cred_mgmt_enabled = $cloak_passkey_mgmt || $cloak_totp_mgmt;

$security_score = calculateSecurityScore($settings, $php_status, $rpid_status, $email_configured, $headers_configured, $is_updated, $using_default_rate_limits, $server_var_init, $server_var_root, $server_var_headers, $init_has_samesite, $init_has_cookie_secure, $extra_curl_security_enabled, $deprecated_files_present, $cloak_cred_mgmt_enabled);
$score_color = $security_score >= 75 ? 'success' : ($security_score >= 60 ? 'warning' : 'danger');

// Detect updates that were skipped/overridden but never acknowledged. The
// confirm_skipped column is added by the 2026-06-16a migration; guard against it
// being absent (new view deployed before the migration runs) by checking
// $db->error() rather than assuming the column exists.
$skipped_unconfirmed = 0;
$skippedQ = $db->query("SELECT COUNT(*) AS c FROM updates WHERE update_skipped IS NOT NULL AND (confirm_skipped IS NULL OR confirm_skipped = 0)");
if (!$db->error()) {
    $skipped_unconfirmed = (int)($skippedQ->first()->c ?? 0);
}

// Build dynamic recommendations
$recommendations = [];

if (!$is_updated) {
    $recommendations[] = [
        'title' => 'Update UserSpice',
        'text' => "Your UserSpice version ({$user_spice_ver}) is outdated. Update to the latest version ({$versions->release_version}) for the newest features and security patches.",
        'link_text' => 'Go to Updates',
        'link_url' => $us_url_root . 'users/admin.php?view=updates'
    ];
}

// Skipped/overridden updates that haven't been acknowledged (recommendation only -
// no score impact).
if ($skipped_unconfirmed > 0) {
    $recommendations[] = [
        'title' => 'Review Skipped Updates',
        'text' => 'You have ' . $skipped_unconfirmed . ' update' . ($skipped_unconfirmed === 1 ? '' : 's') . ' that ' . ($skipped_unconfirmed === 1 ? 'was' : 'were') . ' skipped or overridden instead of applied. Skipped updates can leave your site missing schema changes or security fixes. Review ' . ($skipped_unconfirmed === 1 ? 'it' : 'them') . ' and confirm you intend to skip ' . ($skipped_unconfirmed === 1 ? 'it' : 'them') . '.',
        'link_text' => 'Review Updates',
        'link_url' => $us_url_root . 'users/admin.php?view=updates',
        'level' => 'warning',
        'icon' => 'fa-forward'
    ];
}

if ($php_status !== 'success') {
    $rec_text = $php_status == 'danger'
        ? "Your PHP version ({$phpver}) is past its End-Of-Life and is no longer receiving security updates. This is a critical risk."
        : "Your PHP version ({$phpver}) is approaching its End-Of-Life. Plan to upgrade your server environment soon.";
    $recommendations[] = [
        'title' => 'Upgrade PHP Version',
        'text' => $rec_text,
        'link_text' => 'View PHP Info',
        'link_url' => $us_url_root . 'users/admin.php?view=phpinfo'
    ];
}

if (!$settings->force_ssl) {
    $recommendations[] = [
        'title' => 'Enable Force HTTPS',
        'text' => 'Your site is accessible via insecure HTTP. Forcing all traffic to HTTPS is essential for protecting user data.',
        'link_text' => 'Enable Now',
        'link_url' => '#',
        'modal' => 'confirm-force_ssl'
    ];
}

// Force-SSL is on but no canonical host is pinned: the HTTP->HTTPS redirect is
// built from the request Host header, which on permissive servers enables a
// host-header open redirect. Optional, deployment-dependent hardening -
// informational only, no score impact.
$canonical_host_pinned = defined('US_CANONICAL_HOST') && US_CANONICAL_HOST !== '';
if ($settings->force_ssl == 1 && !$canonical_host_pinned) {
    $recommendations[] = [
        'title' => 'Pin a Canonical Host for HTTPS Redirects',
        'text'  => 'Force HTTPS is enabled, but no canonical host is pinned, so the HTTP&rarr;HTTPS redirect is built from the request <code>Host</code> header. On servers that forward arbitrary Host headers to PHP, this can be abused to redirect visitors to another domain. To harden it, define <code>US_CANONICAL_HOST</code> in <code>users/init.php</code> &mdash; e.g. <code>define(\'US_CANONICAL_HOST\', \'example.com\');</code>. This is optional and does not affect your security score.',
        'link_text' => 'Learn More',
        'link_url'  => '#',
        'level' => 'info',
        'icon'  => 'fa-link'
    ];
}

if (!$email_configured) {
    $recommendations[] = [
        'title' => 'Configure Email Settings',
        'text' => 'Email is not configured, which prevents critical functions like password resets and user notifications from working.',
        'link_text' => 'Configure Email',
        'link_url' => $us_url_root . 'users/admin.php?view=email'
    ];
}

if ($rpid_status !== 'success') {
    $recommendations[] = [
        'title' => 'Correct Passkey Configuration',
        'text' => 'The Passkey Relying Party ID (RP ID) is not configured correctly. This must be resolved for Passkeys to function. ' . $rpid_message,
        'link_text' => 'Review Configuration',
        'link_url' => '#passkey-config-card'
    ];
}

if ($headers_configured < 5) {
    $recommendations[] = [
        'title' => 'Add Missing Security Headers',
        'text' => "Your site is missing " . (5 - $headers_configured) . "/5 recommended security headers, which help protect against common attacks like clickjacking and XSS.",
        'link_text' => 'View Header Status',
        'link_url' => '#security-headers-card'
    ];
}

if ($using_default_rate_limits) {
    $recommendations[] = [
        'title' => 'Customize Your Rate Limits',
        'text' => 'Your site is using the default, insecure rate limits. Customizing these is crucial for protecting your site against brute-force attacks and other automated abuse.',
        'link_text' => 'Configure Rate Limits',
        'link_url' => $us_url_root . 'users/admin.php?view=rate_limits&autoconfig=1'
    ];
}

if ($settings->totp == 0) {
    $recommendations[] = [
        'title' => 'Enable Two-Factor Authentication (TOTP)',
        'text' => 'Two-factor authentication adds a critical layer of security to user accounts, requiring a code from an authenticator app to log in.',
        'link_text' => 'Enable TOTP',
        'link_url' => $us_url_root . 'users/admin.php?view=general&highlight=totp'
    ];
}

if (!$settings->passkeys) {
    $recommendations[] = [
        'title' => 'Enable Passkeys',
        'text' => 'Passkeys offer a modern, secure, and passwordless login method that is resistant to phishing. Enable this option for your users.',
        'link_text' => 'Enable Passkeys',
        'link_url' => $us_url_root . 'users/admin.php?view=general&highlight=passkeys'
    ];
}

// Email login is optional and does NOT affect the security score - surface it as
// an informational nudge only.
if ($settings->email_login == 0) {
    $recommendations[] = [
        'title' => 'Consider Enabling Email Login',
        'text' => 'Email login is currently disabled, so users must sign in with their username. Enabling it also lets users log in with their email address, which many find more convenient. This is optional and does not affect your security score.',
        'link_text' => 'Enable Now',
        'link_url' => '#',
        'modal' => 'confirm-email_login',
        'level' => 'info',
        'icon' => 'fa-envelope-open-text'
    ];
}

// Cloaked admins allowed to manage another user's passkeys/TOTP. Off by
// default; flagged when a site owner opts in via the usersc policy file.
if ($cloak_cred_mgmt_enabled) {
    if ($cloak_passkey_mgmt && $cloak_totp_mgmt) {
        $cloak_factors = 'passkeys and two-factor (TOTP) authentication';
    } elseif ($cloak_passkey_mgmt) {
        $cloak_factors = 'passkeys';
    } else {
        $cloak_factors = 'two-factor (TOTP) authentication';
    }
    $recommendations[] = [
        'title' => 'Cloaked Admins Can Manage User Credentials',
        'text' => 'Your site allows an admin who is cloaked into another user to manage that user\'s ' . $cloak_factors . '. This is off by default because it lets an admin enrol a credential under another user\'s identity. If this is intentional, you can ignore this. To restore the secure default, set the relevant flag to <code>false</code> in <code>usersc/includes/custom_cloak_policy.php</code>.',
        'link_text' => 'Review Policy File',
        'link_url' => '#',
        'level' => 'warning',
        'icon' => 'fa-user-secret'
    ];
}

// Recommend enforcing password rules when passwords are allowed but rules aren't enforced
if ($pw_enforce_rules == 0 && $settings->no_passwords == 0) {
    $recommendations[] = [
        'title' => 'Enforce Strong Password Rules',
        'text' => 'Password logins are enabled but <code>Enforce Password Rules</code> is off. Without enforcement, users can bypass the meter and choose weak passwords. Turn this on so the rules you configure actually apply on submit.',
        'link_text' => 'Enforce Rules',
        'link_url' => $us_url_root . 'users/admin.php?view=reg&highlight=enforce_rules'
    ];
}

if ($settings->debug > 0) {
    $debug_level = $settings->debug == 1 ? 'for Admins' : 'globally';
    $recommendations[] = [
        'title' => 'Disable Debug Mode',
        'text' => "Debug mode is currently active {$debug_level}. While useful for development, it can expose sensitive information and should be disabled on a live site.",
        'link_text' => 'Disable Debug Mode',
        'link_url' => $us_url_root . 'users/admin.php?view=general&highlight=debug'
    ];
}

if (!$extra_curl_security_enabled) {
    $recommendations[] = [
        'title' => 'Enable Extra cURL Security',
        'text' => 'Extra cURL security is not enabled. This setting forces SSL certificate verification for all outbound HTTPS connections, protecting against man-in-the-middle attacks. <strong>Note:</strong> This may cause issues on localhost or with self-signed certificates.',
        'link_text' => 'Enable Now',
        'link_url' => '#',
        'modal' => 'confirm-enable_curl_security'
    ];
}

// Show recommendation to manage CURL backup if it exists and EXTRA_CURL_SECURITY is now enabled
if ($curl_backup_exists && $extra_curl_security_enabled) {
    $recommendations[] = [
        'title' => 'Manage cURL Security Backup',
        'text' => 'A backup file <code>users/init.CURL_BACKUP.php</code> exists from enabling extra cURL security. Since your site is working correctly, you can keep or delete this backup.',
        'link_text' => 'Manage Backup',
        'link_url' => '#',
        'modal' => 'confirm-backup_curl',
        'level' => 'warning',
        'icon' => 'fa-archive'
    ];
}

// Show warning if localhost AND EXTRA_CURL_SECURITY is enabled - may cause connection issues
if (isLocalhost() && $extra_curl_security_enabled) {
    $recommendations[] = [
        'title' => 'Localhost with Extra cURL Security',
        'text' => 'You are running on localhost with <code>EXTRA_CURL_SECURITY</code> enabled. If you experience issues connecting to download updates, use Spice Shaker, or perform backups, you can disable this feature.',
        'link_text' => 'Disable Now',
        'link_url' => '#',
        'modal' => 'confirm-disable_curl_security',
        'level' => 'warning',
        'icon' => 'fa-info-circle'
    ];
}

if ($server_var_init['found']) {
    if ($server_var_init['fixable']) {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from users/init.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>users/init.php</code> for <code>' . implode('</code> and <code>', $server_var_init['keys_found']) . '</code>. Use <code>Server::get()</code> instead for improved security.',
            'link_text' => 'Fix Now',
            'link_url' => '#',
            'modal' => 'confirm-fix_server_init'
        ];
    } else {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from users/init.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>users/init.php</code>. The file contains usages beyond DOCUMENT_ROOT and PHP_SELF that cannot be automatically fixed. Please update the file manually to use <code>Server::get()</code>.',
            'link_text' => 'Learn More',
            'link_url' => '#system-security-card'
        ];
    }
}

// Show recommendation to manage backup if it exists and init.php is now clean
if ($init_backup_exists && !$server_var_init['found']) {
    $recommendations[] = [
        'title' => 'Manage users/init.php Backup',
        'text' => 'A backup file <code>users/init.BACKUP.php</code> exists from a previous fix. Since your site is working correctly, you can keep or delete this backup.',
        'link_text' => 'Manage Backup',
        'link_url' => '#',
        'modal' => 'confirm-backup_init',
        'level' => 'warning',
        'icon' => 'fa-archive'
    ];
}

if ($server_var_root['found']) {
    if ($server_var_root['fixable']) {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from z_us_root.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>z_us_root.php</code> for <code>' . implode('</code> and <code>', $server_var_root['keys_found']) . '</code>. Use <code>Server::get()</code> instead for improved security.',
            'link_text' => 'Fix Now',
            'link_url' => '#',
            'modal' => 'confirm-fix_server_root'
        ];
    } else {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from z_us_root.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>z_us_root.php</code>. The file contains usages beyond DOCUMENT_ROOT and PHP_SELF that cannot be automatically fixed. Please update the file manually to use <code>Server::get()</code>.',
            'link_text' => 'Learn More',
            'link_url' => '#system-security-card'
        ];
    }
}

// Show recommendation to manage backup if it exists and z_us_root is now clean
if ($root_backup_exists && !$server_var_root['found']) {
    $recommendations[] = [
        'title' => 'Manage z_us_root.php Backup',
        'text' => 'A backup file <code>z_us_root.BACKUP.php</code> exists from a previous fix. Since your site is working correctly, you can keep or delete this backup.',
        'link_text' => 'Manage Backup',
        'link_url' => '#',
        'modal' => 'confirm-backup_root',
        'level' => 'warning',
        'icon' => 'fa-archive'
    ];
}

if ($server_var_headers['found']) {
    if ($server_var_headers['fixable']) {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from security_headers.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>usersc/includes/security_headers.php</code> for <code>HTTPS</code> and <code>SERVER_PORT</code>. Use <code>Server::get()</code> instead for sanitized access and CLI compatibility.',
            'link_text' => 'Fix Now',
            'link_url' => '#',
            'modal' => 'confirm-fix_server_headers'
        ];
    } else {
        $recommendations[] = [
            'title' => 'Remove $_SERVER from security_headers.php',
            'text' => 'Direct use of <code>$_SERVER</code> was detected in <code>usersc/includes/security_headers.php</code>. The file has been modified from its default and cannot be automatically fixed. Please update the file manually to use <code>Server::get()</code>.',
            'link_text' => 'View Header Status',
            'link_url' => '#security-headers-card'
        ];
    }
}

// Show recommendation to manage backup if it exists and security_headers.php is now clean
if ($headers_backup_exists && !$server_var_headers['found']) {
    $recommendations[] = [
        'title' => 'Manage security_headers.php Backup',
        'text' => 'A backup file <code>usersc/includes/security_headers.BACKUP.php</code> exists from a previous fix. Since your site is working correctly, you can keep or delete this backup.',
        'link_text' => 'Manage Backup',
        'link_url' => '#',
        'modal' => 'confirm-backup_headers',
        'level' => 'warning',
        'icon' => 'fa-archive'
    ];
}

// Check if custom_login_script.php handles redirect-after-login
$customLoginScript = $abs_us_root . $us_url_root . 'usersc/scripts/custom_login_script.php';
if (file_exists($customLoginScript)) {
    $scriptContent = file_get_contents($customLoginScript);
    // Look for actual code usage of $dest (not just in comments)
    // Match patterns like: if($dest, if ($dest, !empty($dest), isset($dest), Redirect::sanitized($dest)
    $hasDestCode = preg_match('/(?:if\s*\(\s*(?:isset\s*\(\s*)?\$dest|!empty\s*\(\s*\$dest|Redirect::sanitized\s*\(\s*\$dest)/', $scriptContent);
    if (!$hasDestCode) {
        $recommendations[] = [
            'title' => 'Enable Redirect-After-Login',
            'text' => 'Your <code>custom_login_script.php</code> doesn\'t handle post-login redirects. Users who visit a protected page while logged out won\'t be redirected back after login. Add <code>$dest</code> handling to improve UX.',
            'link_text' => 'View Example',
            'link_url' => '#',
            'modal' => 'dest-redirect-example',
            'level' => 'info',
            'icon' => 'fa-lightbulb'
        ];
    }
}

// Session cookie SameSite recommendation
if (!$init_has_samesite) {
    $recommendations[] = [
        'title' => 'Add SameSite Cookie Attribute',
        'text' => 'Your <code>users/init.php</code> is missing <code>session.cookie_samesite</code>. Setting this to <code>Lax</code> helps protect against cross-site request forgery (CSRF) attacks.',
        'link_text' => 'Fix Now',
        'link_url' => '#',
        'modal' => 'confirm-fix_cookie_samesite',
        'level' => 'warning',
        'icon' => 'fa-cookie-bite'
    ];
}

// Session cookie Secure flag recommendation (only when NOT behind a proxy)
if (!$init_has_cookie_secure && !$proxy_enabled) {
    $recommendations[] = [
        'title' => 'Add Secure Cookie Flag',
        'text' => 'Your <code>users/init.php</code> is missing <code>session.cookie_secure</code>. This flag ensures session cookies are only sent over HTTPS connections, preventing them from being intercepted over plain HTTP.',
        'link_text' => 'Fix Now',
        'link_url' => '#',
        'modal' => 'confirm-fix_cookie_secure',
        'level' => 'warning',
        'icon' => 'fa-lock'
    ];
}

// Default README.md in site root
if ($has_default_readme) {
    $recommendations[] = [
        'title' => 'Remove or Customize README.md',
        'text' => 'Your site root contains the default UserSpice <code>README.md</code>. This exposes information about your framework and version to anyone who visits it. Consider deleting or customizing it.',
        'link_text' => 'Delete Now',
        'link_url' => '#',
        'modal' => 'confirm-delete_readme',
        'level' => 'info',
        'icon' => 'fa-file-alt'
    ];
}

// Default SECURITY.md in site root
if ($has_default_security) {
    $recommendations[] = [
        'title' => 'Remove or Customize SECURITY.md',
        'text' => 'Your site root contains the default UserSpice <code>SECURITY.md</code>. This exposes information about your framework to anyone who visits it. Consider deleting or customizing it.',
        'link_text' => 'Delete Now',
        'link_url' => '#',
        'modal' => 'confirm-delete_securitymd',
        'level' => 'info',
        'icon' => 'fa-file-alt'
    ];
}

// Leftover .php files in usersc/includes/deprecated/ are still auto-loaded
if ($deprecated_files_present) {
    $dep_count = count($deprecated_php_files);
    $recommendations[] = [
        'title' => 'Fully Deprecate Old Files',
        'text' => '<code>usersc/includes/deprecated/</code> contains ' . $dep_count . ' <code>.php</code> file' . ($dep_count === 1 ? '' : 's') . ' that ' . ($dep_count === 1 ? 'is' : 'are') . ' still auto-loaded on every page request. If nothing on your site uses these deprecated functions, fully deprecate them - each file is renamed (not deleted) so it is no longer loaded.',
        'link_text' => 'Fully Deprecate',
        'link_url' => '#',
        'modal' => 'confirm-deprecate_files',
        'level' => 'warning',
        'icon' => 'fa-box-archive'
    ];
}

?>

<style nonce="<?=htmlspecialchars($userspice_nonce ?? '')?>">
    .quick-action-btn {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 1rem;
        border: 1px solid #dee2e6;
        border-radius: .375rem;
        height: 100%;
        transition: all 0.2s ease-in-out;
        text-decoration: none;
        color: inherit;
    }

    .quick-action-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        text-decoration: none;
        color: inherit;
    }

    .quick-action-btn .icon {
        font-size: 2rem;
        margin-bottom: 0.5rem;
    }

    .quick-action-btn .status {
        font-size: 0.8rem;
        font-weight: bold;
    }

    .security-metric {
        text-align: center;
        padding: 1rem;
    }

    .security-metric .metric-value {
        font-size: 2rem;
        font-weight: bold;
        margin-bottom: 0.25rem;
    }

    .security-metric .metric-label {
        font-size: 0.9rem;
        color: #6c757d;
    }

    .rate-limit-item {
        border-left: 3px solid #007bff;
        padding-left: 0.75rem;
        margin-bottom: 0.75rem;
    }

    .rate-limit-value {
        font-family: 'Courier New', monospace;
        font-weight: bold;
        color: #0d6efd;
    }

    .recommendation-item {
        display: flex;
        align-items: center;
        padding: 1rem;
        border-bottom: 1px solid #dee2e6;
    }

    .recommendation-item:last-child {
        border-bottom: none;
    }

    .recommendation-icon {
        font-size: 1.5rem;
        margin-right: 1rem;
        width: 30px;
        text-align: center;
    }
</style>

<div class="row">
    <div class="col-12">
        <h2 class="mb-3">
            <i class="fas fa-shield-alt me-2"></i>Security Dashboard
            <span class="badge bg-<?= $score_color ?> ms-2"><?= $security_score ?>% Recommendations Met</span>
        </h2>
        <p class="mb-4">Monitor and manage your UserSpice security configuration. Use the quick actions below to toggle key features and review detailed information in the cards that follow.</p>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-tachometer-alt me-2"></i>Security Overview</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6 col-md-3">
                        <div class="security-metric">
                            <div class="metric-value text-<?= $score_color ?>"><?= $security_score ?>%</div>
                            <div class="metric-label">Recommendations Met</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="security-metric">
                            <div class="metric-value text-<?= isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'success' : 'danger' ?>">
                                <?= isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'HTTPS' : 'HTTP' ?>
                            </div>
                            <div class="metric-label">Connection</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="security-metric">
                            <div class="metric-value text-<?= $php_status ?>"><?= $major_minor_version ?></div>
                            <div class="metric-label">PHP Version</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="security-metric">
                            <div class="metric-value text-<?= $headers_configured > 2 ? 'success' : ($headers_configured > 0 ? 'warning' : 'danger') ?>"><?= $headers_configured ?>/5</div>
                            <div class="metric-label">Security Headers</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6 col-md-3">
                        <a href="#" class="quick-action-btn" data-bs-toggle="modal" data-bs-target="#confirm-force_ssl">
                            <i class="icon fas fa-lock <?= $settings->force_ssl ? 'text-success' : 'text-danger' ?>"></i>
                            <span>Force HTTPS</span>
                            <span class="status <?= $settings->force_ssl ? 'text-success' : 'text-danger' ?>"><?= $settings->force_ssl ? 'ENABLED' : 'DISABLED' ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="#" class="quick-action-btn" data-bs-toggle="modal" data-bs-target="#confirm-email_login">
                            <i class="icon fas fa-envelope-open-text <?= $settings->email_login > 0 ? 'text-success' : 'text-danger' ?>"></i>
                            <span>Email Logins</span>
                            <span class="status <?= $settings->email_login > 0 ? 'text-success' : 'text-danger' ?>"><?= $settings->email_login > 0 ? 'ENABLED' : 'DISABLED' ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="<?= $us_url_root ?>users/admin.php?view=general" class="quick-action-btn">
                            <i class="icon fas fa-key <?= $settings->no_passwords == 0 ? 'text-success' : ($settings->no_passwords == 2 ? 'text-warning' : 'text-danger') ?>"></i>
                            <span>Password Logins</span>
                            <span class="status <?= $settings->no_passwords == 0 ? 'text-success' : ($settings->no_passwords == 2 ? 'text-warning' : 'text-danger') ?>"><?= $settings->no_passwords == 0 ? 'ENABLED' : ($settings->no_passwords == 2 ? 'LOCALHOST' : 'DISABLED') ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="<?= $us_url_root ?>users/admin.php?view=general&highlight=totp" class="quick-action-btn">
                            <i class="icon fas fa-mobile-alt <?= $settings->totp > 0 ? 'text-success' : 'text-warning' ?>"></i>
                            <span>Two-Factor Auth</span>
                            <span class="status <?= $settings->totp > 0 ? 'text-success' : 'text-warning' ?>">
                                <?= $settings->totp == 2 ? 'REQUIRED' : ($settings->totp == 1 ? 'OPTIONAL' : 'DISABLED') ?>
                            </span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="<?= $us_url_root ?>users/admin.php?view=general&highlight=passkeys" class="quick-action-btn">
                            <i class="icon fas fa-fingerprint <?= $settings->passkeys ? 'text-success' : 'text-warning' ?>"></i>
                            <span>Passkeys</span>
                            <span class="status <?= $settings->passkeys ? 'text-success' : 'text-warning' ?>"><?= $settings->passkeys ? 'ENABLED' : 'DISABLED' ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="<?= $us_url_root ?>users/admin.php?view=updates" class="quick-action-btn">
                            <i class="icon fas fa-sync-alt <?= $is_updated ? 'text-success' : 'text-danger' ?>"></i>
                            <span>Update Status</span>
                            <span class="status <?= $is_updated ? 'text-success' : 'text-danger' ?>"><?= $is_updated ? 'UP TO DATE' : 'UPDATE AVAILABLE' ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="#" class="quick-action-btn" data-bs-toggle="modal" data-bs-target="#confirm-site_offline">
                            <i class="icon fas fa-tools <?= $settings->site_offline ? 'text-warning' : 'text-success' ?>"></i>
                            <span>Maintenance Mode</span>
                            <span class="status <?= $settings->site_offline ? 'text-warning' : 'text-success' ?>"><?= $settings->site_offline ? 'ACTIVE' : 'INACTIVE' ?></span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="<?= $us_url_root ?>users/admin.php?view=general&highlight=debug" class="quick-action-btn">
                            <i class="icon fas fa-bug <?= $settings->debug > 0 ? 'text-warning' : 'text-success' ?>"></i>
                            <span>Debug Mode</span>
                            <span class="status <?= $settings->debug > 0 ? 'text-warning' : 'text-success' ?>">
                                <?= $settings->debug == 2 ? 'GLOBAL' : ($settings->debug == 1 ? 'ADMIN' : 'OFF') ?>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Actionable Security Recommendations</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recommendations)) : ?>
                    <div class="text-center text-body-secondary p-4">
                        <i class="fas fa-check-circle fa-3x mb-3 text-success"></i>
                        <h6 class="text-success">All Recommendations Met!</h6>
                        <p class="mb-0">There are no outstanding security recommendations. Great job!</p>
                    </div>
                <?php else : ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recommendations as $rec) :
                            $level = $rec['level'] ?? 'danger';
                            $icon = $rec['icon'] ?? 'fa-exclamation-circle';
                        ?>
                            <div class="list-group-item d-flex flex-column flex-md-row align-items-md-center">
                                <div class="me-3 mb-2 mb-md-0 text-<?= $level ?>"><i class="fas <?= $icon ?> fa-2x"></i></div>
                                <div class="flex-grow-1">
                                    <strong class="mb-1"><?= $rec['title'] ?></strong>
                                    <p class="mb-0 text-body-secondary small"><?= $rec['text'] ?></p>
                                </div>
                                <div class="mt-2 mt-md-0 ms-md-3">
                                    <a href="<?= $rec['link_url'] ?>" class="btn btn-sm btn-outline-primary" <?= isset($rec['modal']) ? 'data-bs-toggle="modal" data-bs-target="#' . $rec['modal'] . '"' : '' ?>>
                                        <i class="fas fa-arrow-right me-1"></i><?= $rec['link_text'] ?>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 col-md-6">

        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-sign-in-alt me-2"></i>Authentication Methods
                </h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-8"><strong>Username/Password:</strong></div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $settings->no_passwords == 0 ? 'success' : ($settings->no_passwords == 2 ? 'warning' : 'danger') ?>">
                            <?= $settings->no_passwords == 0 ? 'Enabled' : ($settings->no_passwords == 2 ? 'Localhost Only' : 'Disabled') ?>
                        </span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-8"><strong>Email Magic Links/Codes:</strong></div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $settings->email_login > 0 ? 'success' : 'secondary' ?>">
                            <?= $settings->email_login > 0 ? 'Enabled' : 'Disabled' ?>
                        </span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-8"><strong>Passkeys (WebAuthn):</strong></div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $settings->passkeys ? 'success' : 'secondary' ?>">
                            <?= $settings->passkeys ? 'Enabled' : 'Disabled' ?>
                        </span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-8"><strong>Two-Factor (TOTP):</strong></div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $settings->totp == 2 ? 'danger' : ($settings->totp == 1 ? 'success' : 'secondary') ?>">
                            <?= $settings->totp == 2 ? 'Required' : ($settings->totp == 1 ? 'Optional' : 'Disabled') ?>
                        </span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8"><strong>OAuth Providers:</strong></div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $oauthProviders > 0 ? 'success' : 'secondary' ?>">
                            <?= $oauthProviders ?> Available
                        </span>
                    </div>
                </div>
                <hr>
                <p class="small mb-0">
                    <strong>Security Recommendation:</strong> Enable multiple authentication methods for redundancy.
                    If disabling password logins, ensure at least one alternative method is properly configured and tested.
                </p>
            </div>
            <div class="card-footer">
                <a href="<?= $us_url_root ?>users/admin.php?view=general" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-cog me-1"></i>Configure Authentication
                </a>
            </div>
        </div>

        <div class="card mb-4 border-<?= $rpid_status ?>" id="passkey-config-card">
            <div class="card-header bg-<?= $rpid_status ?> text-white">
                <h5 class="card-title mb-0">
                    <i class="fas fa-fingerprint me-2"></i>Passkey Configuration
                </h5>
            </div>
            <div class="card-body">
                <p><strong>Expected RP&nbsp;ID:</strong> <code><?= $expected_rpid ?></code></p>
                <?php if ($defined_rpid === null) : ?>
                    <p><strong>Configured RP&nbsp;ID:</strong> <span class="text-danger">Not defined</span> <?= $rpid_badge ?></p>
                <?php else : ?>
                    <p><strong>Configured RP&nbsp;ID:</strong> <code><?= is_array($defined_rpid) ? implode(', ', $defined_rpid) : $defined_rpid ?></code> <?= $rpid_badge ?></p>
                <?php endif; ?>

                <?php if ($rpid_message) : ?>
                    <div class="alert alert-<?= $rpid_status ?> mb-3 p-2 small"><?= $rpid_message ?></div>
                <?php endif; ?>

                <p class="small text-body-secondary mb-2">The <strong>Relying Party ID (RP ID)</strong> is a critical security component. It must be the exact domain your users use to access the site, as it prevents phishing by tying a passkey to a specific domain.</p>

                <?php if ($show_write_button) : ?>
                    <form method="post" class="my-3">
                        <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                        <input type="hidden" name="write_rpid" value="1">
                        <button type="submit" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-save me-1"></i>Write <code><?= $expected_rpid ?></code> to <code>users/init.php</code>
                        </button>
                    </form>
                <?php endif; ?>

                <h5>Understanding Your RP ID</h5>
                <p><strong>String vs. Array:</strong> For most sites, a single domain string (e.g., <code>'www.example.com'</code>) is all you need. An array can be used for advanced cases, like allowing passkeys to work across subdomains (e.g., <code>['login.example.com', 'app.example.com']</code>).</p>
                <div class="alert alert-warning p-2 small">
                    <i class="fas fa-exclamation-triangle me-2"></i><strong>Changing Domains:</strong> If you change your site's domain, existing passkeys will <strong>stop working</strong>. To migrate domains, you must first update the RP ID to be an array containing both the <strong>old and new</strong> domains. Once users have logged into the new domain, you can later remove the old one.
                </div>
            </div>
            <div class="card-footer">
                <a href="<?= $us_url_root ?>users/admin.php?view=general&highlight=passkeys" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-cog me-1"></i>Configure Passkey Settings
                </a>
            </div>
        </div>

        <div class="card mb-4" id="system-security-card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-server me-2"></i>System Security Status
                </h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>UserSpice Version:</strong></div>
                    <div class="col-sm-6 text-end"><span class="badge bg-<?= $is_updated ? 'success' : 'danger' ?>"><?= $user_spice_ver ?></span></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Update Track:</strong></div>
                    <div class="col-sm-6 text-end"><span class="badge bg-<?= $track_colors[$current_track] ?>"><?= $track_names[$current_track] ?></span></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Current UserSpice Release:</strong></div>
                    <div class="col-sm-6 text-end"><?= $versions->release_version; ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Current UserSpice Bleeding Edge Version</strong></div>
                    <div class="col-sm-6 text-end"><?= $versions->bleeding_edge; ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Current UserSpice Experimental Version</strong></div>
                    <div class="col-sm-6 text-end"><?= $versions->experimental; ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>PHP Version:</strong></div>
                    <div class="col-sm-6 text-end">
                        <span class="text-<?= $php_status ?>"><?= $phpver ?></span>
                        <?= $php_badge ?>
                        <?php if ($is_bad_php) : ?><span class="badge bg-danger ms-2">Known Issues</span><?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>HTTPS Connection:</strong></div>
                    <div class="col-sm-6 text-end">
                        <?php if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') : ?>
                            <span class="badge bg-success">Active</span>
                        <?php else : ?>
                            <span class="badge bg-danger">Inactive</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Email Configuration:</strong></div>
                    <div class="col-sm-6 text-end">
                        <span class="badge bg-<?= $email_configured ? 'success' : 'warning' ?>">
                            <?= $email_configured ? 'Configured' : 'Not Configured' ?>
                        </span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-6"><strong>Security Headers:</strong></div>
                    <div class="col-sm-6 text-end">
                        <span class="badge bg-<?= $headers_configured > 2 ? 'success' : ($headers_configured > 0 ? 'warning' : 'danger') ?>">
                            <?= $headers_configured ?> of 5
                        </span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <strong>Extra cURL Security:</strong>
                        <a class="nounderline no-disable" data-toggle="tooltip" title="When enabled, forces cURL to verify SSL certificates when making outbound HTTPS connections. May break on localhost or with self-signed certificates."><i class="fa fa-question-circle offset-circle font-info"></i></a>
                    </div>
                    <div class="col-sm-6 text-end">
                        <?php if ($extra_curl_security_enabled) : ?>
                            <span class="badge bg-success">Enabled</span>
                        <?php else : ?>
                            <span class="badge bg-warning">Disabled</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (!$extra_curl_security_enabled) : ?>
                <div class="row mt-2">
                    <div class="col-12">
                        <div class="alert alert-info p-2 small mb-0">
                            <i class="fas fa-info-circle me-1"></i>
                            To enable extra cURL security, set <code>define('EXTRA_CURL_SECURITY', true);</code> at the bottom of your <code>users/init.php</code> file.
                            This forces SSL certificate verification for all outbound cURL connections to the UserSpice API.
                            <strong>Note:</strong> This may cause issues on localhost or with self-signed certificates.
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <a href="<?= $us_url_root ?>users/admin.php?view=updates" class="btn btn-sm btn-outline-primary me-2">
                    <i class="fas fa-sync-alt me-1"></i>Check Updates
                </a>
                <?php if (in_array($user->data()->id, $master_account) && hasPerm(2)) : ?>
                    <a href="<?= $us_url_root ?>users/admin.php?view=phpinfo" class="btn btn-sm btn-outline-info">
                        <i class="fas fa-info-circle me-1"></i>PHP Info
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>Security Alerts
                </h5>
            </div>
            <div class="card-body">
                <?php
                $alerts = [];

                // Critical alerts
                if ($php_status == 'danger' || $is_bad_php) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-exclamation-circle',
                        'title' => 'Critical PHP Issue',
                        'message' => "PHP version {$phpver} is insecure or has known issues. Upgrade immediately."
                    ];
                }

                if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-lock-open',
                        'title' => 'Insecure Connection',
                        'message' => 'Site is not using HTTPS. This is a major security risk.'
                    ];
                }

                if ($rpid_status === 'danger') {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-fingerprint',
                        'title' => 'Passkey Configuration Error',
                        'message' => $rpid_message
                    ];
                }

                if ($using_default_rate_limits) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-traffic-light',
                        'title' => 'Insecure Default Rate Limits',
                        'message' => 'Your site is using default rate limits which are too permissive for a production environment. This poses a security risk.'
                    ];
                }

                if (($settings->cron_ip ?? '') === '' && $db->query("SELECT id FROM crons WHERE active = 1")->count() > 0) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-clock',
                        'title' => 'Cron Jobs Open to Anyone',
                        'message' => 'You have active cron jobs but no Cron IP set, so anyone can trigger them by visiting users/cron/cron.php. Set the Cron Job IP in General Settings.'
                    ];
                }

                $envKeyPath = function_exists('spiceEnvPath') ? realpath(spiceEnvPath()) : false;
                if ($envKeyPath && strpos($envKeyPath, rtrim(realpath($abs_us_root), '/') . '/') === 0) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-key',
                        'title' => 'Encryption Key Inside Web Root',
                        'message' => 'Your encryption key file (' . safeReturn(basename($envKeyPath)) . ') is inside your web root and may be downloadable. Move it to the folder above your web root, or define ENV_PATH in users/init.php to point to its new location.'
                    ];
                }

                // Warning alerts
                if (!$is_updated) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-sync-alt',
                        'title' => 'Update Available',
                        'message' => "Your UserSpice version ($user_spice_ver) is outdated. The latest is " . $versions->release_version . "."
                    ];
                }

                if ($php_status == 'warning') {
                    $alerts[] = [
                        'level' => 'warning',
                        'icon' => 'fas fa-clock',
                        'title' => 'PHP Version Warning',
                        'message' => "PHP version {$phpver} is approaching end-of-life. Plan to upgrade soon."
                    ];
                }

                if (!$email_configured) {
                    $alerts[] = [
                        'level' => 'warning',
                        'icon' => 'fas fa-envelope',
                        'title' => 'Email Not Configured',
                        'message' => 'Email settings are not configured. This affects password resets and notifications.'
                    ];
                }

                if ($settings->no_passwords == 1 && $settings->email_login == 0 && !$settings->passkeys && $oauthProviders == 0) {
                    $alerts[] = [
                        'level' => 'danger',
                        'icon' => 'fas fa-key',
                        'title' => 'No Login Methods Available',
                        'message' => 'Password logins are disabled but no alternative authentication methods are configured!'
                    ];
                }
                if ($settings->no_passwords == 2 && $settings->email_login == 0 && !$settings->passkeys && $oauthProviders == 0) {
                    $alerts[] = [
                        'level' => 'warning',
                        'icon' => 'fas fa-key',
                        'title' => 'Limited Login Methods',
                        'message' => 'Password logins are only available from localhost. Remote users have no alternative authentication methods configured!'
                    ];
                }

                if ($headers_configured == 0) {
                    $alerts[] = [
                        'level' => 'warning',
                        'icon' => 'fas fa-shield-alt',
                        'title' => 'Missing Security Headers',
                        'message' => 'No security headers detected. Configure them in your web server.'
                    ];
                }

                if ($settings->debug > 1) {
                    $alerts[] = [
                        'level' => 'warning',
                        'icon' => 'fas fa-bug',
                        'title' => 'Debug Mode Active',
                        'message' => 'Debug mode is enabled for all users. This should only be temporary.'
                    ];
                }

                if($user_spice_ver == "5.9.3" || $user_spice_ver == "5.9.4") {
                    $alerts[] = [
                        'level' => 'success',
                        'icon' => 'fas fa-exclamation-triangle',
                        'title' => 'New Rate Limiting Dashboard',
                        'message' => 'Check out the new Rate Limiting Dashboard for better control over your site\'s security. <a href="' . $us_url_root . 'users/admin.php?view=rate_limits">Learn more</a>'
                    ];
                }

                // Only nudge about the Server class when raw $_SERVER usage is
                // actually present in a core file. As an unconditional push this
                // tip permanently suppressed the "All Clear!" state.
                if ($server_var_init['found'] || $server_var_root['found'] || $server_var_headers['found']) {
                    $alerts[] = [
                        'level' => 'info',
                        'icon' => 'fas fa-info-circle',
                        'title' => 'New Server Class',
                        'message' => 'Our new Server class provides various methods for sanitizing things that were traditionally fetched with $_SERVER. Consider using <code>Server::get("HTTP_HOST")</code> in place of <code>$_SERVER["HTTP_HOST"]</code> for improved security.'
                    ];
                }


                if (empty($alerts)) : ?>
                    <div class="text-center text-body-secondary p-3">
                        <i class="fas fa-check-circle fa-3x mb-3 text-success"></i>
                        <h6 class="text-success">All Clear!</h6>
                        <p class="mb-0">No outstanding security alerts detected. Your security configuration looks good.</p>
                    </div>
                <?php else : ?>
                    <div style="max-height: 300px; overflow-y: auto;">
                        <?php foreach ($alerts as $alert) : ?>
                            <div class="alert alert-<?= $alert['level'] ?> py-2 mb-2">
                                <i class="<?= $alert['icon'] ?> me-2"></i>
                                <strong><?= $alert['title'] ?>:</strong> <?= $alert['message'] ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (!empty($alerts)) : ?>
                <div class="card-footer">
                    <small class="text-body-secondary">
                        <i class="fas fa-info-circle me-1"></i>
                        Review and address these alerts to improve your security posture.
                    </small>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-12 col-md-6">

        <div class="card mb-4" id="totp-config-card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-mobile-alt me-2"></i>Two-Factor Authentication (TOTP)
                </h5>
            </div>
            <div class="card-body">
                <p class="small mb-3">Time-based One-Time Passwords (TOTP) add a critical layer of security by requiring a second factor of authentication (a code from an app like Google Authenticator) to log in.</p>
                <h6>Configuration Status:</h6>
                <ul class="list-group list-group-flush mb-3">
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                        PHP Version (<?= $min_totp_php_version ?>+ Required)
                        <?php if ($phpver_ok) : ?>
                            <span class="badge bg-success"><i class="fas fa-check me-1"></i>Supported</span>
                        <?php else : ?>
                            <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Unsupported</span>
                        <?php endif; ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                        Encryption Backend
                        <?php if ($crypto_ok) : ?>
                            <span class="badge bg-success"><i class="fas fa-check me-1"></i>Ready (<?= totp_get_active_crypto_engine() ?>)</span>
                        <?php else : ?>
                            <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Unavailable</span>
                        <?php endif; ?>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                        Encryption Key File
                        <?php if ($key_file_exists && $key_valid) : ?>
                            <span class="badge bg-success"><i class="fas fa-check me-1"></i>Found & Valid</span>
                        <?php elseif ($key_file_exists && !$key_readable) : ?>
                            <span class="badge bg-danger"><i class="fas fa-lock me-1"></i>Unreadable</span>
                        <?php elseif ($key_file_exists && !$key_valid) : ?>
                            <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Invalid</span>
                        <?php else : ?>
                            <span class="badge bg-warning text-dark"><i class="fas fa-exclamation-triangle me-1"></i>Missing</span>
                        <?php endif; ?>
                    </li>
                </ul>
                <?php foreach ($totp_status['messages'] as $msg) : ?>
                    <?php if (is_array($msg)) : ?>
                        <div class="alert alert-<?= $msg['level'] ?> p-2 small"><?= $msg['text'] ?></div>
                    <?php else : ?>
                        <div class="alert alert-<?= $totp_status['level'] ?> p-2 small"><?= $msg ?></div>
                    <?php endif; ?>
                <?php endforeach; ?>

                <?php if (!$key_file_exists && $key_dir_writable && $crypto_ok && $phpver_ok) : ?>
                    <div class="alert alert-info p-2 small">
                        The encryption key file is missing. UserSpice can create it for you now.
                    </div>
                    <form method="post" class="my-3">
                        <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                        <button type="submit" name="generate_totp_key" value="1" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-key me-1"></i>Generate TOTP Encryption Key
                        </button>
                    </form>
                <?php elseif (!$key_file_exists && !$key_dir_writable) : ?>
                    <div class="alert alert-danger p-2 small">
                        <strong>Action Required:</strong> The key file is missing and the directory <code>usersc/includes/</code> is <strong>not writable</strong>. Please create an empty, writable file named <code>totp_key.php</code> in this directory and try again, or adjust folder permissions.
                    </div>
                <?php endif; ?>
                <hr>
                <h5>TOTP Enforcement by Login Method</h5>
                <p class="small text-body-secondary">
                    You can control which authentication methods will trigger a TOTP check for users who have it enabled. To customize these settings, copy the file from
                    <code>users/includes/totp_requirements.php</code> to <code>usersc/includes/totp_requirements.php</code> and edit the values to either <code>true</code> (enforce TOTP) or <code>false</code> (skip TOTP).
                </p>
                <div class="alert alert-warning p-2 small">
                    <strong><i class="fas fa-exclamation-triangle me-1"></i>Plugin Requirement:</strong> For OAuth plugins (e.g., Google, Facebook) to be properly controlled by this feature, you must be using the latest version of those plugins. Older versions will default to the behavior set for the 'password' login method.
                </div>
                <h6>Current Enforcement Status:</h6>
                <div class="row">
                    <?php
                    $login_methods = $totp_requirements['login_methods'] ?? [];
                    $half = ceil(count($login_methods) / 2);
                    $i = 0;
                    ?>
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <?php foreach ($login_methods as $method => $is_enforced) : ?>
                                <?php if ($i < $half) : ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-1">
                                        <span class="text-capitalize"><?= htmlspecialchars($method) ?></span>
                                        <span class="badge bg-<?= $is_enforced ? 'success' : 'secondary' ?>"><?= $is_enforced ? 'Enforced' : 'Skipped' ?></span>
                                    </li>
                                <?php endif; ?>
                            <?php $i++;
                            endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-group list-group-flush">
                            <?php $i = 0; ?>
                            <?php foreach ($login_methods as $method => $is_enforced) : ?>
                                <?php if ($i >= $half) : ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-1">
                                        <span class="text-capitalize"><?= htmlspecialchars($method) ?></span>
                                        <span class="badge bg-<?= $is_enforced ? 'success' : 'secondary' ?>"><?= $is_enforced ? 'Enforced' : 'Skipped' ?></span>
                                    </li>
                                <?php endif; ?>
                            <?php $i++;
                            endforeach; ?>
                        </ul>
                    </div>
                </div>
                <h5>How TOTP Encryption Works</h5>
                <p class="small text-body-secondary">For enhanced security, UserSpice encrypts all TOTP secrets before storing them in the database. This protection relies on a unique encryption key.</p>
                <div class="alert alert-secondary p-2 small">
                    <p class="mb-1"><strong>The Encryption Key File:</strong> A file is generated at <code>usersc/includes/totp_key.php</code> containing a unique, secret key (<code>TOTP_ENC_KEY</code>). This file is critical for TOTP functionality.</p>
                    <ul class="mb-0">
                        <li><strong>Do not share this file.</strong> Treat it like a password.</li>
                        <li><strong>Exclude it from Git.</strong> Add <code>usersc/includes/totp_key.php</code> to your <code>.gitignore</code> file to prevent it from being committed to a public repository.</li>
                    </ul>
                </div>
                <div class="alert alert-info p-2 small">
                    <p class="mb-1"><strong>Advanced Security (using .env):</strong> For the best security posture, especially in a production environment, you should not store secrets in files within your web root. After generating the key, consider moving the <code>define('TOTP_ENC_KEY', '...');</code> line from <code>totp_key.php</code> into your environment configuration (e.g., a <code>.env</code> file or server environment variables). Once you have confirmed it works, you can safely delete the <code>usersc/includes/totp_key.php</code> file.</p>
                </div>
            </div>
            <div class="card-footer">
                <a href="<?= $us_url_root ?>users/admin.php?view=general&highlight=totp" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-cog me-1"></i>Configure TOTP Settings
                </a>
            </div>
        </div>

        <div class="card mb-4" id="rate-limiting-card">
            <div class="card-header">
                <h5 class="card-title mb-0 d-flex align-items-center">
                    <i class="fas fa-traffic-light me-2"></i>Rate Limiting & Protection
                    <span class="badge bg-<?= $rl_health_color ?> ms-2"><?= $rate_limit_health ?>%</span>
                </h5>
            </div>
            <div class="card-body">
                <p class="small mb-3">Rate limiting protects against brute-force attacks and abuse. Key limits are shown below:</p>
                <div class="rate-limit-item">
                    <div><strong>Login Attempts (by IP)</strong></div>
                    <div class="small text-body-secondary">Maximum failed login attempts from a single IP address</div>
                    <div class="rate-limit-value"><?= $rateLimits['login_attempt']['ip_max'] ?? 'N/A' ?> attempts / <?= ($rateLimits['login_attempt']['ip_window'] ?? 0) / 60 ?> minutes</div>
                </div>
                <div class="rate-limit-item">
                    <div><strong>Login Attempts (by User)</strong></div>
                    <div class="small text-body-secondary">Maximum failed login attempts for a single account</div>
                    <div class="rate-limit-value"><?= $rateLimits['login_attempt']['user_max'] ?? 'N/A' ?> attempts / <?= ($rateLimits['login_attempt']['user_window'] ?? 0) / 60 ?> minutes</div>
                </div>
                <div class="rate-limit-item">
                    <div><strong>Password Reset Requests</strong></div>
                    <div class="small text-body-secondary">Maximum password reset requests from a single IP</div>
                    <div class="rate-limit-value"><?= $rateLimits['password_reset_request']['ip_max'] ?? 'N/A' ?> requests / <?= ($rateLimits['password_reset_request']['ip_window'] ?? 0) / 60 ?> minutes</div>
                </div>
                <div class="rate-limit-item">
                    <div><strong>Registration Attempts</strong></div>
                    <div class="small text-body-secondary">Maximum registration attempts from a single IP</div>
                    <div class="rate-limit-value"><?= $rateLimits['registration_attempt']['ip_max'] ?? 'N/A' ?> attempts / <?= ($rateLimits['registration_attempt']['ip_window'] ?? 0) / 60 ?> minutes</div>
                </div>
                <div class="rate-limit-item">
                    <div><strong>Client IP Resolution</strong></div>
                    <div class="small text-body-secondary">How UserSpice determines the visitor's IP address</div>
                    <div class="rate-limit-value">
                        <?php if (!$rl_proxy_enabled): ?>
                            Direct connection (REMOTE_ADDR)
                        <?php elseif ($rl_ip_config['source'] === 'file'): ?>
                            Proxy headers &mdash; managed by <code>usersc/includes/trusted_proxies.php</code>
                        <?php else: ?>
                            Proxy headers &mdash; database settings (<?= $rl_proxy_count ?> trusted source<?= $rl_proxy_count == 1 ? '' : 's' ?>)
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
                <?php if ($rl_proxy_enabled && ($mod_remoteip_active || $upstream_resolved)): ?>
                    <div class="alert alert-warning p-2">
                        <strong><i class="fas fa-exclamation-triangle me-1"></i>Both proxy layers appear to be enabled.</strong><br>
                        <p class="mb-0">
                            <?php if ($mod_remoteip_active): ?>
                                Apache's <code>mod_remoteip</code> is active, so REMOTE_ADDR already contains the real client address before PHP runs.
                            <?php else: ?>
                                On this request, REMOTE_ADDR already matches the trusted forwarded header, which usually means the web server (<code>mod_remoteip</code>, nginx <code>real_ip</code>, or similar) resolved the client address before PHP ran.
                            <?php endif; ?>
                            With the "Behind Reverse Proxy" setting also enabled, the trusted proxy check compares against the already-resolved client address and always falls back. Disable one layer: keep the web server module and turn off "Behind Reverse Proxy", or remove the module and let UserSpice resolve the address.
                        </p>
                    </div>
                <?php endif; ?>
                <?php if ($using_default_rate_limits) : ?>
                    <div class="alert alert-danger p-2">
                        <strong>Warning: Default Rate Limits are Insecure!</strong><br>
                        <p class="mb-1">Your current rate limits are set to the default, extremely permissive values. These are not suitable for a production environment and should be customized immediately to protect against brute-force attacks.</p>
                        <p class="mb-0 small"><a href="<?= $us_url_root ?>users/admin.php?view=rate_limits&autoconfig=1">Use the Auto-Configure tool</a> to quickly set recommended values for your site.</p>
                    </div>
                <?php else : ?>
                    <div class="alert alert-success p-2">
                        <strong><i class="fas fa-check-circle me-1"></i>Rate Limits Customized</strong><br>
                        <p class="mb-0">Your rate limits appear to be customized from the insecure defaults. <a href="<?= $us_url_root ?>users/admin.php?view=rate_limits">Review them periodically</a> to ensure they meet your site's specific security needs.</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <a href="<?= $us_url_root ?>users/admin.php?view=rate_limits&autoconfig=1" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-list me-1"></i>Manage Rate Limits
                </a>
            </div>
        </div>

        <div class="card mb-4" id="security-headers-card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-globe me-2"></i>Security Headers
                </h5>
            </div>
            <div class="card-body">
                <p class="small mb-3">
                    Security headers protect against common web vulnerabilities.
                    Configure these in your web-server vhost or <code>.htaccess</code>.
                </p>
                <?php foreach ($security_headers as $header => $enabled) : ?>
                    <div class="row mb-2 align-items-center">
                        <div class="col-8">
                            <strong><?= htmlspecialchars($header) ?></strong>
                            <?php
                            $descriptions = [
                                'x-frame-options'           => 'Prevents clickjacking attacks',
                                'x-content-type-options'    => 'Stops MIME-type sniffing',
                                'x-xss-protection'          => 'Legacy XSS filter (obsolete)',
                                'strict-transport-security' => 'Forces HTTPS (HSTS)',
                                'referrer-policy'           => 'Controls referrer leakage',
                            ];
                            ?>
                            <div class="small text-body-secondary"><?= $descriptions[strtolower($header)] ?? '' ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <span class="badge bg-<?= $enabled ? 'success' : 'danger' ?>">
                                <?= $enabled ? 'Set' : 'Missing' ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="row mb-3 align-items-center">
                    <div class="col-8">
                        <strong>Content Security Policy</strong>
                        <div class="small text-body-secondary">Defines what sources the browser may load.</div>
                    </div>
                    <div class="col-4 text-end">
                        <span class="badge bg-<?= $cspConfigured ? 'success' : 'danger' ?>">
                            <?= $cspConfigured ? 'Enabled' : 'Missing' ?>
                        </span>
                    </div>
                </div>
                <?php if (!$cspConfigured) : ?>
                    <div class="alert alert-warning small">
                        <strong>No CSP detected.</strong> UserSpice cannot safely auto-generate
                        one, because every site loads different scripts, images, and
                        third-party assets.
                        <br>Begin with
                        <code>Content-Security-Policy-Report-Only</code>, review the violations,
                        then enforce the policy once you’re confident nothing breaks.
                    </div>
                <?php else : ?>
                    <p class="small mb-3">
                        <?= $cspInfo['enforced']
                            ? 'Your policy is enforced.'
                            : 'Policy is currently in <code>report-only</code> mode.' ?>
                    </p>
                <?php endif; ?>
                <div class="alert alert-info p-2">
                    <strong>Example <code>.htaccess</code> snippet:</strong>
                    <pre class="mt-2 mb-0" style="font-size: .8rem;"><code>Header always set X-Frame-Options "SAMEORIGIN"
Header always set X-Content-Type-Options "nosniff"
Header always set Strict-Transport-Security "max-age=31536000"
Header always set Referrer-Policy "no-referrer-when-downgrade"</code></pre>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
function generate_confirmation_modal($id, $title, $message, $setting_name, $settings)
{
    $current_val = $settings->$setting_name;
    // For 'no_passwords', the logic is inverted: 1 means passwords are disabled, 0 means enabled
    $is_inverted = ($setting_name === 'no_passwords');
    $action_text = $is_inverted
        ? ($current_val ? "Enable" : "Disable")  // if no_passwords=1, we enable passwords; if 0, we disable
        : ($current_val ? "Disable" : "Enable"); // normal logic for other settings
    $btn_class = $current_val ? 'danger' : 'success';
?>
    <div class="modal fade" id="confirm-<?= $id ?>" tabindex="-1" aria-labelledby="confirm-<?= $id ?>-label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirm-<?= $id ?>-label">Confirm: <?= $action_text ?> <?= $title ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-<?= $btn_class == 'danger' ? 'warning' : 'info' ?>" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?= $message ?>
                    </div>
                    <p><strong>Are you sure you want to <?= strtolower($action_text) ?> this feature?</strong></p>
                    <?php if ($setting_name == 'no_passwords' && !$current_val) : ?>
                        <div class="alert alert-danger">
                            <strong>Warning:</strong> Before disabling password logins, ensure you have tested alternative login methods.
                            If you disable passwords without working alternatives, you may lock yourself out of the system.
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <form action="" method="post">
                        <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                        <input type="hidden" name="setting" value="<?= $setting_name ?>">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="toggle_security_setting" class="btn btn-<?= $btn_class ?>">
                            <i class="fas fa-<?= $current_val ? 'times' : 'check' ?> me-1"></i><?= $action_text ?> Now
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php }

generate_confirmation_modal(
    'force_ssl',
    'Force HTTPS',
    'This will redirect all insecure (HTTP) requests to secure (HTTPS) connections. Ensure your SSL certificate is valid and properly configured before enabling this feature.',
    'force_ssl',
    $settings
);

generate_confirmation_modal(
    'email_login',
    'Email Logins',
    'This allows users to log in without a password by clicking a link or entering a code sent to their email. Your email configuration must be working properly for this feature to function.',
    'email_login',
    $settings
);

generate_confirmation_modal(
    'no_passwords',
    'Password Logins',
    'This will completely disable username/password authentication. Users will only be able to log in via configured alternative methods (OAuth, Passkeys, Email Magic Links).',
    'no_passwords',
    $settings
);

generate_confirmation_modal(
    'site_offline',
    'Maintenance Mode',
    'This will make your site inaccessible to all non-administrative users. They will see a maintenance page instead of your normal site content.',
    'site_offline',
    $settings
);
?>

<?php if ($server_var_init['found'] && $server_var_init['fixable']) : ?>
<div class="modal fade" id="confirm-fix_server_init" tabindex="-1" aria-labelledby="confirm-fix_server_init-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-fix_server_init-label">Fix $_SERVER Usage in users/init.php</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will replace <code>$_SERVER['DOCUMENT_ROOT']</code> and <code>$_SERVER['PHP_SELF']</code> with <code>Server::get('DOCUMENT_ROOT')</code> and <code>Server::get('PHP_SELF')</code>.
                </div>
                <p>The <code>Server</code> class provides sanitized access to server variables, helping prevent header injection and other security vulnerabilities.</p>
                <p>Additionally, the following will be added if missing:</p>
                <ul class="small">
                    <li><code>define('USERSPICE_ACTIVE_LOGGING', false);</code> after <code>&lt;?php</code></li>
                    <li><code>$noPHPInfo = false;</code> after <code>&lt;?php</code></li>
                    <li><code>$userspice_nonce = base64_encode(random_bytes(16));</code> before loader.php</li>
                    <li><code>$system_messages_justify = "right";</code> before loader.php</li>
                    <li><code>define('EXTRA_CURL_SECURITY', false);</code> before loader.php</li>
                </ul>

                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>users/init.BACKUP.php</code> before any changes are made.
                </div>

                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="fix_server_init" class="btn btn-primary">
                        <i class="fas fa-wrench me-1"></i>Fix Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
function generate_backup_modal($id, $cfg)
{
    $backup_basename = basename($cfg['path']);
    $save_basename   = preg_replace('/\.php$/', '.SAVE.php', $backup_basename);
?>
    <div class="modal fade" id="confirm-backup_<?= htmlspecialchars($id) ?>" tabindex="-1" aria-labelledby="confirm-backup_<?= htmlspecialchars($id) ?>-label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirm-backup_<?= htmlspecialchars($id) ?>-label">Manage Backup File</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        Your site is working correctly with the updated <code><?= htmlspecialchars($cfg['label']) ?></code>.
                    </div>
                    <p>The backup file <code><?= htmlspecialchars($cfg['path']) ?></code> can be:</p>
                    <ul>
                        <li><strong>Kept &amp; ignored:</strong> renamed to <code><?= htmlspecialchars($save_basename) ?></code> so it won't appear in future checks.</li>
                        <li><strong>Deleted:</strong> permanently removed from your server.</li>
                    </ul>
                </div>
                <div class="modal-footer d-flex flex-wrap gap-2 justify-content-end">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form action="" method="post" class="d-inline m-0">
                        <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                        <input type="hidden" name="backup_id" value="<?= htmlspecialchars($id) ?>">
                        <input type="hidden" name="backup_action" value="dismiss">
                        <button type="submit" name="handle_backup" value="1" class="btn btn-success">
                            <i class="fas fa-archive me-1"></i>Keep &amp; Ignore
                        </button>
                    </form>
                    <form action="" method="post" class="d-inline m-0">
                        <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                        <input type="hidden" name="backup_id" value="<?= htmlspecialchars($id) ?>">
                        <input type="hidden" name="backup_action" value="delete">
                        <button type="submit" name="handle_backup" value="1" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i>Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
}

if ($init_backup_exists)    generate_backup_modal('init',    $backup_configs['init']);
if ($root_backup_exists)    generate_backup_modal('root',    $backup_configs['root']);
if ($headers_backup_exists) generate_backup_modal('headers', $backup_configs['headers']);
if ($curl_backup_exists)    generate_backup_modal('curl',    $backup_configs['curl']);
?>

<?php if ($server_var_root['found'] && $server_var_root['fixable']) : ?>
<div class="modal fade" id="confirm-fix_server_root" tabindex="-1" aria-labelledby="confirm-fix_server_root-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-fix_server_root-label">Fix $_SERVER Usage in z_us_root.php</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will replace <code>$_SERVER['DOCUMENT_ROOT']</code> and <code>$_SERVER['PHP_SELF']</code> with <code>Server::get('DOCUMENT_ROOT')</code> and <code>Server::get('PHP_SELF')</code>.
                </div>
                <p>The <code>Server</code> class provides sanitized access to server variables, helping prevent header injection and other security vulnerabilities.</p>

                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>z_us_root.BACKUP.php</code> before any changes are made.
                </div>

                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="fix_server_root" class="btn btn-primary">
                        <i class="fas fa-wrench me-1"></i>Fix Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($server_var_headers['found'] && $server_var_headers['fixable']) : ?>
<div class="modal fade" id="confirm-fix_server_headers" tabindex="-1" aria-labelledby="confirm-fix_server_headers-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-fix_server_headers-label">Fix $_SERVER Usage in security_headers.php</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will replace raw <code>$_SERVER['HTTPS']</code> and <code>$_SERVER['SERVER_PORT']</code> access with <code>Server::get('HTTPS')</code> and <code>Server::get('SERVER_PORT')</code>.
                </div>
                <p>The <code>Server</code> class provides sanitized access to server variables, helping prevent header injection and ensuring compatibility when running from the CLI.</p>

                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>usersc/includes/security_headers.BACKUP.php</code> before any changes are made.
                </div>

                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="fix_server_headers" class="btn btn-primary">
                        <i class="fas fa-wrench me-1"></i>Fix Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!$extra_curl_security_enabled) : ?>
<div class="modal fade" id="confirm-enable_curl_security" tabindex="-1" aria-labelledby="confirm-enable_curl_security-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-enable_curl_security-label">Enable Extra cURL Security</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will enable <code>EXTRA_CURL_SECURITY</code> in your <code>users/init.php</code> file.
                </div>
                <p>When enabled, this setting forces SSL certificate verification for all outbound cURL connections to the UserSpice API, protecting against man-in-the-middle attacks.</p>

                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Warning:</strong> This may cause issues on localhost or with self-signed certificates. Only enable this on production servers with valid SSL certificates.
                </div>

                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>users/init.CURL_BACKUP.php</code> before any changes are made.
                </div>

                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="enable_curl_security" class="btn btn-primary">
                        <i class="fas fa-lock me-1"></i>Enable Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (isLocalhost() && $extra_curl_security_enabled) : ?>
<div class="modal fade" id="confirm-disable_curl_security" tabindex="-1" aria-labelledby="confirm-disable_curl_security-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-disable_curl_security-label">Disable Extra cURL Security</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    You are running on <strong>localhost</strong> with extra cURL security enabled.
                </div>
                <p>This setting enforces SSL certificate verification for outbound cURL connections. On localhost or development environments with self-signed certificates, this can cause connection failures when:</p>
                <ul>
                    <li>Downloading updates from UserSpice</li>
                    <li>Using Spice Shaker to install addons</li>
                </ul>

                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Note:</strong> You should re-enable this feature when deploying to a production server with valid SSL certificates.
                </div>

                <div class="alert alert-secondary">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>users/init.CURL_BACKUP.php</code> before any changes are made.
                </div>

                <div class="mb-3">
                    <label for="disable_curl_confirm" class="form-label"><strong>Type YES to confirm:</strong></label>
                    <input type="text" class="form-control" id="disable_curl_confirm" name="disable_curl_confirm" placeholder="Type YES to confirm" autocomplete="off" form="disable-curl-form">
                </div>
            </div>
            <div class="modal-footer">
                <form action="" method="post" id="disable-curl-form">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="disable_curl_security" class="btn btn-warning">
                        <i class="fas fa-unlock me-1"></i>Disable Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Redirect-After-Login Example Modal -->
<div class="modal fade" id="dest-redirect-example" tabindex="-1" aria-labelledby="dest-redirect-example-label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dest-redirect-example-label"><i class="fas fa-lightbulb me-2"></i>Redirect-After-Login Feature</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    When users visit a protected page while logged out, <code>securePage()</code> stores their intended destination. After login, you can redirect them back to that page.
                </div>
                <p>Add this code to your <code>usersc/scripts/custom_login_script.php</code>:</p>
                <pre class="bg-dark text-light p-3 rounded"><code>if (isset($dest) && !empty($dest)) {
    // User was redirected to login from a protected page - send them back there
    Redirect::sanitized($dest);
} elseif (hasPerm([2], $user->data()->id)) {
    Redirect::to($us_url_root . 'users/admin.php');
} else {
    Redirect::to($us_url_root . $settings->redirect_uri_after_login);
}</code></pre>
                <p class="text-body-secondary small mb-0"><strong>How it works:</strong> The <code>$dest</code> variable contains the page path (with query string) the user was trying to access. <code>Redirect::sanitized()</code> ensures the redirect is safe (same-origin only).</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php if (!$init_has_samesite): ?>
<div class="modal fade" id="confirm-fix_cookie_samesite" tabindex="-1" aria-labelledby="confirm-fix_cookie_samesite-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-fix_cookie_samesite-label">Add SameSite Cookie Attribute</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will add <code>ini_set('session.cookie_samesite', 'Lax');</code> to your <code>users/init.php</code>.
                </div>
                <p>The <code>SameSite=Lax</code> attribute prevents the browser from sending session cookies with cross-site requests, providing protection against CSRF attacks while still allowing normal navigation links to work.</p>
                <p>This line will be added below <code>require_once 'classes/class.autoloader.php';</code></p>
                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>users/init.BACKUP.php</code> before any changes are made.
                </div>
                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="fix_cookie_samesite" class="btn btn-primary">
                        <i class="fas fa-wrench me-1"></i>Fix Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!$init_has_cookie_secure && !$proxy_enabled): ?>
<div class="modal fade" id="confirm-fix_cookie_secure" tabindex="-1" aria-labelledby="confirm-fix_cookie_secure-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-fix_cookie_secure-label">Add Secure Cookie Flag</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    This will add HTTPS detection and <code>session.cookie_secure</code> to your <code>users/init.php</code>.
                </div>
                <p>The following code will be inserted before <code>session_start();</code>:</p>
                <pre class="bg-dark text-light p-3 rounded"><code>if (Server::get('HTTPS') !== '' && Server::get('HTTPS') !== 'off') {
	ini_set('session.cookie_secure', 1);
}</code></pre>
                <p>When the server detects an HTTPS connection, session cookies will be flagged as secure, preventing them from being sent over plain HTTP.</p>
                <div class="alert alert-warning">
                    <i class="fas fa-save me-2"></i>
                    <strong>Backup:</strong> A copy of your current file will be saved as <code>users/init.BACKUP.php</code> before any changes are made.
                </div>
                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="fix_cookie_secure" class="btn btn-primary">
                        <i class="fas fa-wrench me-1"></i>Fix Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($deprecated_files_present): ?>
<div class="modal fade" id="confirm-deprecate_files" tabindex="-1" aria-labelledby="confirm-deprecate_files-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-deprecate_files-label">Fully Deprecate Old Files</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    Each <code>.php</code> file in <code>usersc/includes/deprecated/</code> will be renamed to <code>&lt;name&gt;.php_dep_on_<?= date('Y-m-d') ?></code>. The helpers loader only includes <code>*.php</code> files, so the renamed files will no longer be loaded.
                </div>
                <p>The files are <strong>renamed, not deleted</strong> - you can reverse this at any time by changing the extension back to <code>.php</code>.</p>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Important:</strong> only proceed if nothing on your site still calls the deprecated functions in these files. If something does, you will see "undefined function" errors.
                </div>
                <p><strong>Are you sure you want to proceed?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="deprecate_files" class="btn btn-primary">
                        <i class="fas fa-box-archive me-1"></i>Fully Deprecate
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($has_default_readme): ?>
<div class="modal fade" id="confirm-delete_readme" tabindex="-1" aria-labelledby="confirm-delete_readme-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-delete_readme-label">Delete Default README.md</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    The default <code>README.md</code> in your site root identifies your site as running UserSpice, which can help attackers target known vulnerabilities.
                </div>
                <p>You can safely delete this file, or replace it with your own content. This action will permanently delete the file.</p>
                <p><strong>Are you sure you want to delete README.md?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_default_readme" class="btn btn-danger">
                        <i class="fas fa-trash me-1"></i>Delete
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($has_default_security): ?>
<div class="modal fade" id="confirm-delete_securitymd" tabindex="-1" aria-labelledby="confirm-delete_securitymd-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirm-delete_securitymd-label">Delete Default SECURITY.md</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    The default <code>SECURITY.md</code> in your site root identifies your site as running UserSpice and exposes your security reporting process.
                </div>
                <p>You can safely delete this file, or replace it with your own content. This action will permanently delete the file.</p>
                <p><strong>Are you sure you want to delete SECURITY.md?</strong></p>
            </div>
            <div class="modal-footer">
                <form action="" method="post">
                    <input type="hidden" name="csrf" value="<?= Token::generate() ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_default_securitymd" class="btn btn-danger">
                        <i class="fas fa-trash me-1"></i>Delete
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>