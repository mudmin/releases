<div class="col-sm-8">
  <div class="page-header float-right">
    <div class="page-title">
      <ol class="breadcrumb text-right">
        <ol class="breadcrumb text-right">
          <li><a href="<?=$us_url_root?>users/admin.php">Dashboard</a></li>
          <li>Manage</li>
          <li class="active">Users</li>
        </ol>
      </ol>
    </div>
  </div>
</div>
</div>
</header>

<div class="content mt-3">
<h2>Title</h2>

</div>
