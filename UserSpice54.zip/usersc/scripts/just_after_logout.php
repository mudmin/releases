<?php
//This is what happens after a user logs out. Where do you want to send them?  What do you want to do?

Redirect::to($us_url_root.'index.php');
?>