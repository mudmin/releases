<?php
$user_spice_ver = '6.0.0';