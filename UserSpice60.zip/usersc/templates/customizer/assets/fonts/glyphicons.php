<style>
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.eot');
  src:
  url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.eot?#iefix') format('embedded-opentype'),
  url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.woff2') format('woff2'),
  url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.woff') format('woff'),
  url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.ttf') format('truetype'),
  url('<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular') format('svg');
}
</style>
