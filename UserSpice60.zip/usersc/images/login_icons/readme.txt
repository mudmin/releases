Put your login override icons in this folder.  OAuth Plugins should be plugin_folder.png
passwordless login should be passwordless.png